##############################
# Pre Check OS Configuration #
##############################
#!/bin/sh

cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/unix
/usr/bin/ansible-playbook playbooks/pre-checkreport.yml

