/bin/mv /tmp/hosts /appdir/ITIO-EE-ImageTeamScripts-Ansible/winpatch/environments/test
