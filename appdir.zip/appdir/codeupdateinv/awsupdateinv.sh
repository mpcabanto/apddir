/bin/mv /tmp/awhosts /appdir/ITIO-EE-ImageTeamScripts-Ansible/unix/environments/dev/
