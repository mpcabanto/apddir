#!/bin/sh

cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/IaCVPC-VM
/usr/bin/ansible-playbook playbooks/ospatch.yml
