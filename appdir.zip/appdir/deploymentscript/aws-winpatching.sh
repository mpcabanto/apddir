##############################
# Ansible deplyment          #
##############################
#!/bin/sh

cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/winpatch
/usr/bin/ansible-playbook playbooks/site.yml
