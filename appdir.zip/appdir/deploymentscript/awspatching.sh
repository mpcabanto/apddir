##############################
# Ansible deplyment          #
##############################
#!/bin/sh

cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/unix
/usr/bin/ansible-playbook playbooks/awsmain.yml

