dynamicDate=$(date +%m%Y)
/bin/cat  <<EOF > /etc/apt/sources.list
deb http://10.46.180.103:8080/ubuntu/$dynamicDate bionic-security main
deb http://10.46.180.103:8080/ubuntu/$dynamicDate bionic-current main
deb http://10.46.180.103:8080/ubuntu/$dynamicDate bionic-updates main
EOF
