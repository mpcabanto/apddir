dynamicDate=$(date +%m%Y)
reposip="10.46.178.x"
reposport="8080"
/bin/cat  <<EOF > /etc/apt/sources.list
deb http://$reposip:$reposport/ubuntu/$dynamicDate focal-current main
deb http://$reposip:$reposport/ubuntu/$dynamicDate focal-updates main
deb http://$reposip:$reposport/ubuntu/$dynamicDate focal-security main
EOF
