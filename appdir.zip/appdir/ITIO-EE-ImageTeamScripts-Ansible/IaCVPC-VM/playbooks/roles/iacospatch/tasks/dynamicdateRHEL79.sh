dynamicDate=$(date +%b-%Y)
/bin/cat  <<EOF > /etc/yum.repos.d/local.repo
[rhel-7-server-internal-repo]
metadata_expire = 86400
baseurl = https://www.rhel.bdo.com.ph/repos/rhel/7/9/$dynamicDate
ui_repoid_vars = releasever basearch
sslverify = 0
name = Red Hat Enterprise Linux 7.9 Server - Internal Repository
#sslclientkey = /etc/pki/entitlement/7982189681505492723-key.pem
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release
enabled = 1
gpgcheck = 0
proxy=_none_
EOF
