dynamicDate=$(date +%m%Y)
/bin/cat  <<EOF > /etc/apt/sources.list
deb http://10.71.178.241:8080/ubuntu/$dynamicDate focal-current main
deb http://10.71.178.241:8080/ubuntu/$dynamicDate focal-updates main
deb http://10.71.178.241:8080/ubuntu/$dynamicDate focal-security main
EOF
