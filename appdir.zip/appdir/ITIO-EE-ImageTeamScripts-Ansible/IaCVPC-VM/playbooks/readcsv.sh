csvFile="iac_infra_ingress.csv"
lengthItems=$((($(xsv count "$csvFile") - 1 ))) # -1 because for loop start at 0

for i in $( seq 0 "$lengthItems" ); do

    row="$(xsv slice -i "$i" "$csvFile")" # real magic happening here

    # Do what you want with your $row here  
    
done
