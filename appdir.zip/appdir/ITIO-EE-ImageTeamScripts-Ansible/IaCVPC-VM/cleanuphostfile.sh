/bin/cat <<EOF > /appdir/ITIO-EE-ImageTeamScripts-Ansible/IaCVPC-VM/environments/dev/hosts
#This should be the ip address of the targer host to be patch and mbss
#You may add multiple of unix environment for any multiple processes

#VPC
[lin]
localhost

#AWS

#Azure

#Do not modify this part as this is the authentication method for any connectivity and process to sucessfully run the script.
# If you want to update the credentials. Please do read the IG or README File.

[lin:vars]
ansible_ssh_common_args='-o StrictHostKeyChecking=no'
ansible_ssh_port=22
ansible_user="{{lin_admin_user}}"
ansible_password="{{lin_admin_password}}"


#vSphere Connection
vuser="{{ v_user }}"
vpass='{{ v_pass }}'



#################################
#ITIO-EE-Platforms-Infra-Image  #
# Mike Cabanto                  #
#################################
EOF


