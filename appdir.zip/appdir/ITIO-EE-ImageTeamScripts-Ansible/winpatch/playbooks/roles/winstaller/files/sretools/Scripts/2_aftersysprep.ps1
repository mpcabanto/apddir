﻿$dbservice = 'SQLSERVERAGENT'
If (Get-Service $dbservice -ErrorAction SilentlyContinue)
{

#echo "w/ Database" for Database Server Drive Settings

}else
{
#echo "w/out Database" - but for Apps Server Drive Settings


#Set Backup Drive and Letter
Set-Disk -Number 3 -IsOffline $False
Set-Disk -Number 3 -IsReadonly $False
Set-Partition -DiskNumber 3 -PartitionNumber 2 -NewDriveLetter H -ErrorAction SilentlyContinue

#Set Logs Drive and Letter
Set-Disk -Number 2 -IsOffline $False
Set-Disk -Number 2 -IsReadonly $False
Set-Partition -DiskNumber 2 -PartitionNumber 2 -NewDriveLetter G -ErrorAction SilentlyContinue

#Set Appdir Drive and Letter
Set-Disk -Number 1 -IsOffline $False
Set-Disk -Number 1 -IsReadonly $False
Set-Partition -DiskNumber 1 -PartitionNumber 2 -NewDriveLetter F -ErrorAction SilentlyContinue

}


Rename-NetAdapter -Name 'Ethernet0' -NewName "BDO" -ErrorAction SilentlyContinue
Rename-NetAdapter -Name 'Ethernet1' -NewName "BACKUP" -ErrorAction SilentlyContinue
Disable-NetAdapterBinding -Name 'Ethernet0' -ComponentID "ms_tcpip6" -ErrorAction SilentlyContinue
Disable-NetAdapterBinding -Name 'Ethernet1' -ComponentID "ms_tcpip6" -ErrorAction SilentlyContinue
Disable-NetAdapterBinding -Name 'BDO' -ComponentID "ms_tcpip6" -ErrorAction SilentlyContinue
Disable-NetAdapterBinding -Name 'BACKUP' -ComponentID "ms_tcpip6" -ErrorAction SilentlyContinue

####### DISABLE NETBIOS (AWS AND VPC only)

If ((Get-ComputerInfo).CsManufacturer -eq "Microsoft Corporation") {

##Manual Disable for Azure Servers

}Else{

$i = 'HKLM:\SYSTEM\CurrentControlSet\Services\netbt\Parameters\interfaces'  
Get-ChildItem $i | ForEach-Object {  
    Set-ItemProperty -Path "$i\$($_.pschildname)" -name NetBiosOptions -value 2

Write-host "COMPLETED: NetBIOS on all NIC Adapters is Disabled" -ForegroundColor Green
Write-Output "COMPLETED: NetBIOS on all NIC Adapters is Disabled" | Out-File -FilePath "c:\sretools\BaselineLogs\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append
}
}
