﻿##### CHANGE HERE
$environment = "UAT"
           


#LOG Folder
$Folder_path = "$home\Downloads"
$currentdate = get-date -UFormat "%Y-%m-%d"
$LOGFolder = "LOG_$currentdate"

$PathDestination = "$Folder_path\$LOGFolder\"
       
        If (Test-Path $PathDestination) {
                                        }
                                        else 
                                        {
                                        New-Item -ItemType Directory $PathDestination | Out-Null
                                        }
       


   

           
#region CHECK BASELINE  ==================================================================  =========================================================================#

#Environment 
$Server_Env = $environment

#Basic Server Details 
Function Get-SystemInfo {
[cmdletbinding()]

$cs = gcim -ClassName Win32_computersystem 
$proc = gcim -ClassName win32_processor | ? deviceID -eq 'CPU0'
$os = gcim -ClassName Win32_OperatingSystem 
$ram = gcim -ClassName Win32_PhysicalMemory
$SytemType =  if (test-path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server')
                    {
                    $i = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
                    if ([string]::IsNullOrEmpty($i)) {"Non-DB"} else  {"DB"}
                    }
                    else
                    {"Non-DB"}

 

      function Physical_HostName() {  
        $Phy_Hostname  =""       
        $computer = $env:ComputerName
        $KeyName = "SOFTWARE\Microsoft\Virtual Machine\Guest\Parameters"            
        $ValueName = "PhysicalHostName"            
            

            try {            
            $BaseKeyObj = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey("LocalMachine", $computer)            
            $KeyObj = $BaseKeyObj.OpenSubKey($KeyName)            
            $Phy_Hostname = $KeyObj.GetValue($ValueName)            
            } catch {            
            $Phy_Hostname = "Unidentified"          
            }  
               
        $Phy_Hostname  
        
        } #end Physical_HostNamefunction


        #Check if VM or Pysical 
        $ComputerSystemInfo = Get-WmiObject -Class Win32_ComputerSystem 
        $Machine_Platform = ""
        $MachineModel = $ComputerSystemInfo.Model
        $SN = (get-wmiobject win32_bios).serialnumber
        $SerialNumber = if ([string]::IsNullOrEmpty($SN)) {} else {"-  $SN"}

        switch -wildcard ($MachineModel) { 

            # Check for VMware Machine Type 
            "*VMware*" { 
                $Machine_Platform="VMware VM / VPC VM"
                $Physical_Machine_HostName=Physical_HostName
                Break 
            } 

            # Check for Oracle VM Machine Type 
            "VirtualBox" { 
                $Machine_Platform="Oracle VM"
                $Physical_Machine_HostName=Physical_HostName
                Break 
            } 
            default { 

                switch ($ComputerSystemInfo.Manufacturer) {

                    # Check for Xen VM Machine Type
                    "Xen" {
                        $Machine_Platform="Xen VM"
                        $Physical_Machine_HostName=Physical_HostName
                        Break
                    }

                    # Check for KVM VM Machine Type
                    "QEMU" {
                        $Machine_Platform="KVM VM / Open Nebula VM"
                        $Physical_Machine_HostName=Physical_HostName
                        Break
                    }
                    # Check for Hyper-V Machine Type 
                    "Microsoft Corporation" { 
                        if (get-service WindowsAzureGuestAgent -ErrorAction SilentlyContinue) {
                            $Machine_Platform="Azure VM"
                            $Physical_Machine_HostName=Physical_HostName
                        }
                        else {
                            $Machine_Platform="Hyper-V VM"
                            $Physical_Machine_HostName=Physical_HostName
                        }
                        Break
                    }
                    # Check for Google Cloud Platform
                    "Google" {
                        $Machine_Platform="Google Cloud VM"
                        $Physical_Machine_HostName=Physical_HostName
                        Break
                    }

                    # Check for AWS Cloud Platform
                    default { 
                        if ((((Get-WmiObject -query "select uuid from Win32_ComputerSystemProduct" | Select-Object UUID).UUID).substring(0, 3) ) -match "EC2") {
                            $Machine_Platform="AWS VM"
                            $Physical_Machine_HostName=Physical_HostName
                        }
                        # Otherwise it is a physical Box 
                        else {
                            $Machine_Platform="Bare Metal - $MachineModel $SerialNumber"
                            $Physical_Machine_HostName=""
                        }
                    } 
                }                  
            } 
        } 

   $OutputObj = New-Object PSObject -Prop (            
        @{            
        Platform=$Machine_Platform
        HostMachine=$Physical_Machine_HostName           
        }) 
            
    
 if ($OutputObj.HostMachine -eq "") {
                         #SystemInfomation
                        $data = [ordered]@{
                        HostName = $cs.Name
                        Domain = $cs.Domain
                        Processor = $proc.Name
                        Memory = $cs.TotalPhysicalMemory/1GB -as [int]
                        NumProcessors = $cs.NumberOfProcessors
                        NumCores = $proc.NumberOfCores
                        NumLogicalProcessors = $cs.NumberOfLogicalProcessors
                        MaxClockSpeed = $proc.MaxClockSpeed
                        Platform = $OutputObj.Platform
                        SystemType = $SytemType
                        }
                        
                        New-Object -TypeName PSObject -Property $data
               
                }
                else {
                        #SystemInfomation
                        $data = [ordered]@{
                        HostName = $cs.Name
                        Domain = $cs.Domain
                        Processor = $proc.Name
                        Memory = $cs.TotalPhysicalMemory/1GB -as [int]
                        NumProcessors = $cs.NumberOfProcessors
                        NumCores = $proc.NumberOfCores
                        NumLogicalProcessors = $cs.NumberOfLogicalProcessors
                        MaxClockSpeed = $proc.MaxClockSpeed
                        Platform = $OutputObj.Platform
                        "Physical Host Machine" = $OutputObj.HostMachine
                        SystemType = $SytemType
                        }

                        New-Object -TypeName PSObject -Property $data
                }

  

}

function Get-OSVersionInfo{
    gcim -Class win32_operatingsystem -ComputerName $computername | Select @{Name="Operating System";Expression= {$_.Caption + ' ' + $_.OSArchitecture}},Version,ServicePackMajorVersion,InstallDate
} 

#Local User
Function Get-LocalUser {
    
    Get-WMIObject Win32_UserAccount -Filter LocalAccount='True' | ? {$_.Name -eq "itowawin"  -or  $_.Name -eq "Administrator" } |
    `Select Name, Description, Disabled, @{n='Status';e={
                                                                    if ($_.Name -eq "Administrator"){
                                                                            if ($_.Disabled -eq "True" -and $_.Description -eq "Built-in account for administering the computer/domain")
                                                                                {"Passed"} else {"Failed"}
                                                                     }                                                     
                                                                    else {
                                                                            if ($_.Description -eq "" -and $_.Disabled -ne "True")
                                                                                {"Passed"} else {"Failed"}
                                                                     }
                                                        }
                                           }
    
    
   $LocalUsers = (Get-WMIObject Win32_UserAccount -Filter LocalAccount='True').Name

                if ($LocalUsers -ccontains "Administrator"){
                        }
                        else {
                                            $data = [ordered]@{
                                                Name = "Administrator"
                                                Description= "Built-in account for administering the computer/domain"
                                                Disabled = "Not Defined"
                                                Status = "Failed" }
                                            New-Object -TypeName PSObject -Property $data      
                        }
                
         
                 
}


#ILO
Function Get-ILO {
    $hostnametrim = $env:computername.Substring($env:computername.ToUpper().indexof("W"))
    $ILOhostname = "ILO$hostnametrim.ho.ad.bdo"
    #Check if HP
    $HPSrv = (gcim -Class Win32_ComputerSystem).Manufacturer 
    $ILOResult = if($HPSrv -like '*HP*') {

         If (Test-Connection $ILOhostname  -Quiet -Count 2){
	                                $data = [ordered]@{
                                        "ILO FQDN" = $ILOhostname
                                        Remarks = "ILO is accessible"
                                        Status = "Passed" }

                                    New-Object -TypeName PSObject -Property $data

	        }
	        Else{
	            	               $data = [ordered]@{
                                        "ILO FQDN" = $ILOhostname
                                        Remarks = "ILO is inaccessible"
                                        Status = "Failed" }

                                    New-Object -TypeName PSObject -Property $data
	        }

    
    }
    else {}

   $ILOResult | ConvertTo-Html -Fragment -PreContent "<h2>HP ILO</h2> <hr>" 

}



#DRIVE

#region == OLD Get-DriveInfo 
<#
Function Get-DriveInfo {
   $vmms = gcim -Class Win32_Service -f "Name='vmms'"
   gcim -Class win32_logicaldisk -filter "DriveType=3" |
   ` select @{n='Drive';e={$_.DeviceID}}, VolumeName, @{n='Size (GB)';e={[math]::round($_.Size/1GB,2)}}, @{n='Free Space (GB)';e={[math]::round($_.Freespace/1GB,2)}}, @{n='Free Space Percentage';e={$a=[math]::Round(($_.Freespace/1gb)/($_.size/1gb)*100,2);$b="%";"$a $b"}}, @{n='Status';
        e={
                if (test-path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"){
                        if ($_.DeviceID -like "C*")
                            {
                                if ($_.VolumeName -eq "System")
                                    {"Passed"} else {"Failed"} 
                            }
                        elseif ($_.DeviceID -like "D*")
                            {
                            if (($_.VolumeName -like  "Database Backup*") -or ($_.VolumeName -like  "Data*"))
                                    {"Passed"} else {"Failed"}  
                            }
                        elseif ($_.DeviceID -like "E*")
                            {
                                if ($_.VolumeName -like  "Database Data*")
                                    {"Passed"} else {"Failed"} 
                            }
                        elseif ($_.DeviceID -like "F*")
                            {
                            if ($_.VolumeName -like "Database Translog*")
                                    {"Passed"} else {"Failed"}  
                            }
                        else
                            {"Failed"} 
                }
                elseif ($vmms -ne $null){
                        if ($_.DeviceID -like "C*")
                            {
                                if ($_.VolumeName -eq "System")
                                    {"Passed"} else {"Failed"} 
                            }
                        elseif ($_.DeviceID -like "D*")
                            {
                            if ($_.VolumeName -eq  "Data")
                                    {"Passed"} else {"Failed"}  
                            }
                        elseif ($_.DeviceID -like "E*")
                            {
                                if ($_.VolumeName -eq  "VM")
                                    {"Passed"} else {"Failed"} 
                            }
                        else
                            {"Failed"}
                }
                else{
                        if ($_.DeviceID -like "C*")
                            {
                                if ($_.VolumeName -eq  "System")
                                    {"Passed"} else {"Failed"} 
                            }
                        elseif ($_.DeviceID -like "D*")
                            {
                            if ($_.VolumeName -eq  "Data")
                                    {"Passed"} else {"Failed"}  
                            }
                        else
                            {"Failed"} 

                }


            

            }
       }

   

}

Function Get-DriveInfo_CLOUD {
   gcim -Class win32_logicaldisk -filter "DriveType=3" |
   ` select @{n='Drive';e={$_.DeviceID}}, VolumeName, @{n='Size (GB)';e={[math]::round($_.Size/1GB,2)}}, @{n='Free Space (GB)';e={[math]::round($_.Freespace/1GB,2)}}, @{n='Free Space Percentage';e={$a=[math]::Round(($_.Freespace/1gb)/($_.size/1gb)*100,2);$b="%";"$a $b"}}, @{n='Status';
        e={
                if (test-path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"){

                        if ($_.DeviceID -like "C*")
                            {
                            if (($_.VolumeName -eq "System") -or ($_.VolumeName -eq ""))
                                    {"Passed"} else {"Failed"} 
                            }
                        elseif ($_.DeviceID -like "D*")
                            {
                            if ($_.VolumeName -eq "Temporary storage for Cloud")
                                    {"Passed"} else {"Failed"}  
                            }
                        elseif ($_.DeviceID -like "F*")
                            {
                            if ($_.VolumeName -eq "dbdata")
                                    {"Passed"} else {"Failed"}  
                            }
                        elseif ($_.DeviceID -like "G*")
                            {
                                if ($_.VolumeName -like  "Log*")
                                    {"Passed"} else {"Failed"} 
                            }
                        elseif ($_.DeviceID -like "H*")
                            {
                            if ($_.VolumeName -like "Backup*")
                                    {"Passed"} else {"Failed"}  
                            }
                        elseif ($_.DeviceID -like "I*")
                            {
                            if ($_.VolumeName -like "*temp*")
                                    {"Passed"} else {"Failed"}  
                            }
                        else
                            {"Failed"} 


                        
                }
            
                else{
                       if ($_.DeviceID -like "C*")
                            {
                            if (($_.VolumeName -eq "System") -or ($_.VolumeName -eq ""))
                                    {"Passed"} else {"Failed"} 
                            }
                        elseif ($_.DeviceID -like "D*")
                            {
                            if ($_.VolumeName -eq "Temporary storage for Cloud")
                                    {"Passed"} else {"Failed"}  
                            }
                        elseif ($_.DeviceID -like "F*")
                            {
                            if ($_.VolumeName -eq "Appdir")
                                    {"Passed"} else {"Failed"}  
                            }
                        elseif ($_.DeviceID -like "G*")
                            {
                                if ($_.VolumeName -like  "Log*")
                                    {"Passed"} else {"Failed"} 
                            }
                        elseif ($_.DeviceID -like "H*")
                            {
                            if ($_.VolumeName -like "Backup*")
                                    {"Passed"} else {"Failed"}  
                            }
                        else
                            {"Failed"} 

                }


            

            }
       } #end @{n='Status';

    

}



Function Get-DriveInfo {
   
   $vmms = gcim -Class Win32_Service -f "Name='vmms'"
   gcim -Class win32_logicaldisk -filter "DriveType=3" |
   ` select @{n='Drive';e={$_.DeviceID}}, VolumeName, @{n='Size (GB)';e={[math]::round($_.Size/1GB,2)}}, @{n='Free Space (GB)';e={[math]::round($_.Freespace/1GB,2)}}, @{n='Free Space Percentage';e={$a=[math]::Round(($_.Freespace/1gb)/($_.size/1gb)*100,2);$b="%";"$a $b"}}, @{n='Status';
        e={
                if (test-path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"){
                        if ($_.DeviceID -like "C*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "D*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "E*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "F*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "G*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "H*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "I*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "J*")
                            {"Passed"}
                        else
                            {"Failed"} 
                }
                elseif ($vmms -ne $null){
                        if ($_.DeviceID -like "C*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "D*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "E*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "F*")
                            {"Passed"}
                        else
                            {"Failed"}
                }
                else{
                         if ($_.DeviceID -like "C*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "D*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "E*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "F*")
                            {"Passed"}
                        else
                            {"Failed"}

                }


            

            }
       }

     

}

Function Get-DriveInfo_CLOUD {
   gcim -Class win32_logicaldisk -filter "DriveType=3" |
   ` select @{n='Drive';e={$_.DeviceID}}, VolumeName, @{n='Size (GB)';e={[math]::round($_.Size/1GB,2)}}, @{n='Free Space (GB)';e={[math]::round($_.Freespace/1GB,2)}}, @{n='Free Space Percentage';e={$a=[math]::Round(($_.Freespace/1gb)/($_.size/1gb)*100,2);$b="%";"$a $b"}}, @{n='Status';
        e={
                if (test-path "HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server"){

                        if ($_.DeviceID -like "C*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "D*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "F*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "G*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "H*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "I*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "J*")
                            {"Passed"}
                        else
                            {"Failed"} 


                        
                }
            
                else{
                       if ($_.DeviceID -like "C*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "D*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "F*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "G*")
                            {"Passed"}
                        elseif ($_.DeviceID -like "H*")
                            {"Passed"}
                        else
                            {"Failed"} 

                }


            

            }
       } #end @{n='Status';

    

}

#>

#endregion == OLD Get-DriveInfo 

Function Get-DriveInfo {
   
   $vmms = gcim -Class Win32_Service -f "Name='vmms'"
   gcim -Class win32_logicaldisk -filter "DriveType=3" |
   ` select @{n='Drive';e={$_.DeviceID}}, VolumeName, @{n='Size (GB)';e={[math]::round($_.Size/1GB,2)}}, @{n='Free Space (GB)';e={[math]::round($_.Freespace/1GB,2)}}, @{n='Free Space Percentage';e={$a=[math]::Round(($_.Freespace/1gb)/($_.size/1gb)*100,2);$b="%";"$a $b"}}, @{n='Status';e={'Passed'}} 
     

}

Function Get-DriveInfo_CLOUD {
   gcim -Class win32_logicaldisk -filter "DriveType=3" |
   ` select @{n='Drive';e={$_.DeviceID}}, VolumeName, @{n='Size (GB)';e={[math]::round($_.Size/1GB,2)}}, @{n='Free Space (GB)';e={[math]::round($_.Freespace/1GB,2)}}, @{n='Free Space Percentage';e={$a=[math]::Round(($_.Freespace/1gb)/($_.size/1gb)*100,2);$b="%";"$a $b"}}, @{n='Status';e={'Passed'}} 
}



#Folder Information   ========  OLD BASELINE
function Get-FolderInformation {
        $Directories = @(
            "D:\Backup",
            "D:\Log"
            "D:\Interfaces",
            "D:\Interfaces\inbox",
            "D:\Interfaces\outbox",
            "D:\Interfaces\reports",
            "D:\Interfaces\archive",
            "D:\Deployments",
            "D:\Deployments\DSC")

        foreach ($folder in $Directories) {
                    if (Test-Path $folder){
                            $data = [ordered]@{
                                Folder = $folder
                                Remarks = "Folder exists"
                                Status = "Passed" }

                            New-Object -TypeName PSObject -Property $data

                    }
                    else{
                           $data = [ordered]@{
                                Folder = $folder
                                Remarks = "Folder is not existing"
                                Status = "Failed" }

                            New-Object -TypeName PSObject -Property $data

                    }

       }
}
      
function Get-FolderInformation_CLOUD {

$driveLetters = (gcim -Class win32_logicaldisk -filter "DriveType=3").DeviceID
        
   
        
   
   
   if (test-path 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server')
   {
   $i = (get-itemproperty 'HKLM:\SOFTWARE\Microsoft\Microsoft SQL Server').InstalledInstances
   
   if ([string]::IsNullOrEmpty($i))
        {
        #NON-DB
            $Directories = @(
            "F:\interfaces",
            "F:\interfaces\inbox",
            "F:\interfaces\outbox",
            "F:\interfaces\reports",
            "F:\interfaces\archive",
            "F:\interfaces\extract",
            "F:\deployments",
            "F:\deployments\dsc",
            "F:\tools",
            "F:\Program Files")

            foreach ($folder in $Directories) {
                    if (Test-Path $folder){
                            $data = [ordered]@{
                                Folder = $folder
                                Remarks = "Folder exists"
                                Status = "Passed" }

                            New-Object -TypeName PSObject -Property $data

                    }
                    else{
                           $data = [ordered]@{
                                Folder = $folder
                                Remarks = "Folder is not existing"
                                Status = "Failed" }

                            New-Object -TypeName PSObject -Property $data

                    }

             }
        }

        else

        {
        #DB
                if ($driveLetter -like "I*") {
        

                $Directories = @(
                    "F:\interfaces",
                    "F:\interfaces\inbox",
                    "F:\interfaces\outbox",
                    "F:\interfaces\reports",
                    "F:\interfaces\archive",
                    "F:\interfaces\extract",
                    "F:\deployments",
                    "F:\deployments\dsc",
                    "F:\tools",
                    "F:\Program Files",
                    "F:\MSSQL_MDF",
                    "G:\log",
                    "G:\log\MSSQL_LOG",
                    "H:\backup",
                    "H:\backup\database",
                    "H:\backup\translog",
                    "I:\MSSQL_TEMP",
                    "J:\MSSQL_LDF")

                foreach ($folder in $Directories) {
                            if (Test-Path $folder){
                                    $data = [ordered]@{
                                        Folder = $folder
                                        Remarks = "Folder exists"
                                        Status = "Passed" }

                                    New-Object -TypeName PSObject -Property $data

                            }
                            else{
                                $data = [ordered]@{
                                        Folder = $folder
                                        Remarks = "Folder is not existing"
                                        Status = "Failed" }

                                    New-Object -TypeName PSObject -Property $data

                            }

       }

       }
             else {
                $Directories = @(
                    "F:\interfaces",
                    "F:\interfaces\inbox",
                    "F:\interfaces\outbox",
                    "F:\interfaces\reports",
                    "F:\interfaces\archive",
                    "F:\interfaces\extract",
                    "F:\deployments",
                    "F:\deployments\dsc",
                    "F:\tools",
                    "F:\Program Files",
                    "F:\MSSQL_MDF",
                    "G:\log",
                    "G:\log\MSSQL_LOG",
                    "H:\backup",
                    "H:\backup\database",
                    "H:\backup\translog",
                    "I:\MSSQL_TEMP",
                    "J:\MSSQL_LDF")

                foreach ($folder in $Directories) {
                            if (Test-Path $folder){
                                    $data = [ordered]@{
                                        Folder = $folder
                                        Remarks = "Folder exists"
                                        Status = "Passed" }

                                    New-Object -TypeName PSObject -Property $data

                            }
                            else{
                                $data = [ordered]@{
                                        Folder = $folder
                                        Remarks = "Folder is not existing"
                                        Status = "Failed" }

                                    New-Object -TypeName PSObject -Property $data

                            }

       }
       }

        }

    }  
    else
    {
    #NON-DB
            $Directories = @(
            "F:\interfaces",
            "F:\interfaces\inbox",
            "F:\interfaces\outbox",
            "F:\interfaces\reports",
            "F:\interfaces\archive",
            "F:\interfaces\extract",
            "F:\deployments",
            "F:\deployments\dsc",
            "F:\tools",
            "F:\Program Files")

            foreach ($folder in $Directories) {
                    if (Test-Path $folder){
                            $data = [ordered]@{
                                Folder = $folder
                                Remarks = "Folder exists"
                                Status = "Passed" }

                            New-Object -TypeName PSObject -Property $data

                    }
                    else{
                           $data = [ordered]@{
                                Folder = $folder
                                Remarks = "Folder is not existing"
                                Status = "Failed" }

                            New-Object -TypeName PSObject -Property $data

                    }

             }
    }   
        
        
}                               

#CD-ROM Drive Information
Function Get-CDRom {
        $CDRom = gcim Win32_CDROMDrive
           
            if($CDRom -ne $null){

                    ForEach ($CDR in ($CDRom).Drive){

                        if($CDR -eq "Z:"){
                                $data = [ordered]@{
                                    Name = ($CDRom).Caption
                                    Drive= ($CDRom).Drive
                                    Status = "Passed" }

                                New-Object -TypeName PSObject -Property $data

                        }
                         else{
                                $data = [ordered]@{
                                    Name = ($CDRom).Caption
                                    Drive= ($CDRom).Drive
                                    Status = "Failed" }  
                                    
                                New-Object -TypeName PSObject -Property $data
                                                          
                         }
                    
                     }
            }
            else {}
    
}


#Services Information
Function Get-ServiceInfo {
   $Service_names = @(
            "TrkWks",
            "Browser",
            "RasMan",
            "ShellHWDetection",
            "TapiSrv",
            "AudioEndpointBuilder",
            "Audiosrv",
            "dot3svc",
            "hidserv")

    foreach ($service_name in $Service_names){

            $service = gcim Win32_Service | ? Name -eq $service_name
                    if ([string]::IsNullOrEmpty($service))
                      {
                      } 
                    else {
                           
                                    if ($service.StartMode -eq "Disabled"){
                                        $data = [ordered]@{
                                                Service = $service.Caption
                                                State = $service.State
                                                "Startup Type"= $service.StartMode
                                                "Log On As" = $service.StartName
                                                Status = "Passed" }

                                     New-Object -TypeName PSObject -Property $data

                                    } 
                                    else {
                                         $data = [ordered]@{
                                                Service = $service.Caption
                                                State = $service.State
                                                "Startup Type"= $service.StartMode
                                                "Log On As" = $service.StartName
                                                Status = "Failed" }

                                     New-Object -TypeName PSObject -Property $data

                                     }

                    }
          

    }

}



#region Programs Information

#Programs helper function
$regSearch = 'Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall'
Function Win32_Product {
        Param ([string]$serverName, [string]$displayName)
        Try
        {
            $reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $serverName)
            $regKey = $reg.OpenSubKey($regSearch)
            If ($regKey) { [array]$keyVal = $regKey.GetSubKeyNames() }
        }
        Catch { Return $null }
        $found = $false
        If (($regKey) -and ($keyVal.Count -gt 0)) {
            ForEach ($app In $keyVal) {
                $appKey = $regKey.OpenSubKey($app).GetValue('DisplayName')
                If ($appKey -like ('*' + $displayName + '*')) {
                    $found = $true
                    [string]$verCheck = $regKey.OpenSubKey($app).GetValue('DisplayVersion')
                    If (-not $verCheck) { $verCheck = '0.1' } }
            }
            If ($found -eq $false) {
                If ($regSearch -like '*Wow6432Node*') {
                    $regSearch = $regSearch.Replace('Wow6432Node', '')
                    $verCheck = Win32_Product -serverName $serverName -displayName $displayName
                }
                Else { $verCheck = $null } }
        }
        Else { $verCheck = $null }
        $regKey.Close()
        $reg.Close()
        Return $verCheck
} #end Win32_Product




function Get-ProgramInfo {

    #Check if HP
    $HPSrv = (gcim -Class Win32_ComputerSystem).Manufacturer 
    $osversion = gcim -class Win32_OperatingSystem | select Caption
    if(($HPSrv -like '*HP*') -and ($osversion -like '*Microsoft Windows Server 2008*' -or $osversion -like '*Microsoft Windows Server 2012*')){
           $program_prod = @(
                "7-Zip",
                "Symantec Endpoint Protection",
                "NetBackup Client",
                "UniversalForwarder",
                "FusionInventory Agent",
                "HP Version Control Agent",
                "Insight Management WBEM Providers For Windows Server",
                "SNMP",
                "Telnet-client")

            $program_uat = @(
                "7-Zip",
                "Symantec Endpoint Protection",
                "FusionInventory Agent",
                "HP Version Control Agent",
                "Insight Management WBEM Providers For Windows Server",
                "SNMP",
                "Telnet-client")
        }

        #CLOUD
        elseif (($env:COMPUTERNAME -like "SW2*") -or ($env:COMPUTERNAME -like "SW3*") -or ($env:COMPUTERNAME -like "SW4*") -or ($env:COMPUTERNAME-like "SW5*") ) {
                $program_prod = @(
                "7-Zip",
                "Crowdstrike",
                "UniversalForwarder",
                "SNMP",
                "Telnet-client")

            $program_uat = @(
                "7-Zip",
                "Crowdstrike",
                "SNMP",
                "Telnet-client")
        
        
        }


        else {
           $program_prod = @(
                "7-Zip",
                "Symantec Endpoint Protection",
                "NetBackup Client",
                "UniversalForwarder",
                "FusionInventory Agent"
                "SNMP",
                "Telnet-client")

            $program_uat = @(
                "7-Zip",
                "Symantec Endpoint Protection",
                "FusionInventory Agent"
                "SNMP",
                "Telnet-client")

        }




        
       

    if ($Server_Env -eq "PROD")  {

          foreach ($prog in $program_prod) {

            #telnet & SNMP
            if (($prog -eq "SNMP") -or ($prog -eq "telnet-client")){
                
                if ($prog -eq "SNMP") { $prog ="SNMP-Service"}

                    $details = Get-WindowsFeature $prog 
                    if($details -eq $null){
                       #Feature Not Available
                    }

                    else{

                                                if($details.Installed -eq $False){
                                                        
                                                        $data = [ordered]@{
                                                                Application = $details.DisplayName
                                                                Version = "Not Installed"
                                                                Status = "Failed" } 

                                                        New-Object -TypeName PSObject -Property $data

                                                }

                                            else{
                                                        $data = [ordered]@{
                                                                Application = $details.DisplayName
                                                                Version = "Installed"
                                                                Status = "Passed" }

                                                        New-Object -TypeName PSObject -Property $data


                                                }
                    }



            }


            else{
            
                        $details = Win32_Product -displayName $prog

                            if($details -eq $null){
                                           $prog_ver = "Not Installed"
                                           $data = [ordered]@{
                                                Application = $prog
                                                Version = $prog_ver
                                                Status = "Failed" } 

                                            New-Object -TypeName PSObject -Property $data

                             }

                          else{
                                           $prog_ver = $details
                                           $data = [ordered]@{
                                                Application = $prog
                                                Version = $prog_ver
                                                Status = "Passed" }

                                            New-Object -TypeName PSObject -Property $data


                         }
            }
          
          }
    }



     
    else
     {
         foreach ($prog in $program_uat) {
            
            #telnet & SNMP
            if (($prog -eq "SNMP") -or ($prog -eq "telnet-client")){
                
                if ($prog -eq "SNMP") { $prog ="SNMP-Service"}

                    $details = Get-WindowsFeature $prog 
                    if($details -eq $null){
                       #Feature Not Available
                    }

                    else{

                                                if($details.Installed -eq $False){
                                                        
                                                        $data = [ordered]@{
                                                                Application = $details.DisplayName
                                                                Version = "Not Installed"
                                                                Status = "Failed" } 

                                                        New-Object -TypeName PSObject -Property $data

                                                }

                                            else{
                                                        $data = [ordered]@{
                                                                Application = $details.DisplayName
                                                                Version = "Installed"
                                                                Status = "Passed" }

                                                        New-Object -TypeName PSObject -Property $data


                                                }
                    }



            }


            else{
            
                        $details = Win32_Product -displayName $prog

                            if($details -eq $null){
                                           $prog_ver = "Not Installed"
                                           $data = [ordered]@{
                                                Application = $prog
                                                Version = $prog_ver
                                                Status = "Failed" } 

                                            New-Object -TypeName PSObject -Property $data

                             }

                          else{
                                           $prog_ver = $details
                                           $data = [ordered]@{
                                                Application = $prog
                                                Version = $prog_ver
                                                Status = "Passed" }

                                            New-Object -TypeName PSObject -Property $data


                         }
            }
         
         }




     }




          # windirstat & Sysinternals --------------------

    $sysinternal= "C:\Program Files\Tools\SysinternalsSuite\"
        if (test-path $sysinternal){ 
               
                $data = [ordered]@{
                        Application = "SysinternalsSuite"
                        Version = "Installed"
                        Status = "Passed"}
                New-Object -TypeName PSObject -Property $data
        }
        else{
            $data = [ordered]@{
                        Application = "SysinternalsSuite"
                        Version = "Not Installed"
                        Status = "Failed"}
                New-Object -TypeName PSObject -Property $data
        } 


    $windirstat1 = "C:\Program Files (x86)\WinDirStat\windirstat.exe"
    $windirstat2 = "C:\Program Files\WinDirStat\windirstat.exe"

    if (test-path $windirstat1) { 
                $data = [ordered]@{
                        Application = "WinDirStat"
                        Version = "Installed"
                        Status = "Passed"}
                New-Object -TypeName PSObject -Property $data
     }
    else {
        if(test-path $windirstat2){ $
                $data = [ordered]@{
                        Application = "WinDirStat"
                        Version = "Installed"
                        Status = "Passed"}
                New-Object -TypeName PSObject -Property $data
        }
             else {
                    $data = [ordered]@{
                        Application = "WinDirStat"
                        Version = "Not Installed"
                        Status = "Failed"}
                    New-Object -TypeName PSObject -Property $data
             } 

    }

}



#endregion



#Firewall Rules Information  ############################################################################### PENDING

Function Firewall_Status {


        $FirewallProfiles = @(
                        "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"
                        "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"
                        "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"
                        )


        foreach ($FirewallProfile in $FirewallProfiles) {
              $Profile = Get-ItemProperty -Path $FirewallProfile 
                        if ($Profile.EnableFirewall -eq 1) {
                                $FirewallState = "ON"
                                if ($Profile.PSchildName -eq "StandardProfile") {$ProfileName="PrivateProfile"} else {$ProfileName= $Profile.PSchildName}

                                        $data = [ordered]@{
                                        "Firewall Profile" = $ProfileName
                                        State = $FirewallState
                                        Status = "Passed"} 

                                New-Object -TypeName PSObject -Property $data

                                                                       
                                
                            } 
                        else {
                                $FirewallState = "OFF"
                                if ($Profile.PSchildName -eq "StandardProfile") {$ProfileName="PrivateProfile"} else {$ProfileName= $Profile.PSchildName}


                                        $data = [ordered]@{
                                        "Firewall Profile" = $ProfileName
                                        State = $FirewallState
                                        Status = "Failed"}

                                New-Object -TypeName PSObject -Property $data


                                        
                             } 

               



        }

}



Function Firewall_Status_CLOUD {


        $FirewallProfiles = @(
                        "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\DomainProfile"
                        "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\PublicProfile"
                        "HKLM:\SYSTEM\CurrentControlSet\Services\SharedAccess\Parameters\FirewallPolicy\StandardProfile"
                        )


        foreach ($FirewallProfile in $FirewallProfiles) {
              $Profile = Get-ItemProperty -Path $FirewallProfile 
                        if ($Profile.EnableFirewall -eq 1) {
                                $FirewallState = "ON"
                                if ($Profile.PSchildName -eq "StandardProfile") {$ProfileName="PrivateProfile"} else {$ProfileName= $Profile.PSchildName}

                                        $data = [ordered]@{
                                        "Firewall Profile" = $ProfileName
                                        State = $FirewallState
                                        Status = "Failed"} 

                                 New-Object -TypeName PSObject -Property $data
                                                                       
                                
                            } 
                        else {
                                $FirewallState = "OFF"
                                if ($Profile.PSchildName -eq "StandardProfile") {$ProfileName="PrivateProfile"} else {$ProfileName= $Profile.PSchildName}


                                        $data = [ordered]@{
                                        "Firewall Profile" = $ProfileName
                                        State = $FirewallState
                                        Status = "Passed"}

                                 New-Object -TypeName PSObject -Property $data

                                        
                             } 

               



        }

}

Function Get-Firewall_Rules {

    #Get Baseline FW rules
    $ICMP4Stat = netsh advfirewall firewall show rule name="File and Printer Sharing (Echo Request - ICMPv4-In)" | sls "Enabled:                              Yes" -ErrorAction SilentlyContinue
    $NBStat = netsh advfirewall firewall show rule name="Netbackup" | sls "Enabled:                              Yes" -ErrorAction SilentlyContinue
    $RDSStat1 = netsh advfirewall firewall show rule name="Remote Desktop 3389 - Restricted" | sls "Enabled:                              Yes" -ErrorAction SilentlyContinue

    $RDSStat2a = netsh advfirewall firewall show rule name="Remote Desktop 3389 - Restricted" | sls "172.16.209.58/32" -ErrorAction SilentlyContinue
    $RDSStat2b = netsh advfirewall firewall show rule name="Remote Desktop 3389 - Restricted" | sls "172.16.235.90/32" -ErrorAction SilentlyContinue
    $RDSStat2c = netsh advfirewall firewall show rule name="Remote Desktop 3389 - Restricted" | sls "172.22.45.51/32" -ErrorAction SilentlyContinue
    $RDSStat2d = netsh advfirewall firewall show rule name="Remote Desktop 3389 - Restricted" | sls "172.22.71.40/32" -ErrorAction SilentlyContinue
    if($RDSStat2a -eq $Null -or $RDSStat2b -eq $Null -or $RDSStat2c -eq $Null -or $RDSStat2d -eq $Null){$RDSStat2 = "Failed"}

    $RDSStat3 = netsh advfirewall firewall show rule name="Remote Desktop 3389 - Restricted" | sls "LocalPort:                            3389" -ErrorAction SilentlyContinue
    $RDSStat4 = netsh advfirewall firewall show rule name="Remote Desktop 3389 - Restricted" | sls "Protocol:                             TCP" -ErrorAction SilentlyContinue
    $RDSStat5 = netsh advfirewall firewall show rule name="Remote Desktop 3389 - Restricted" | sls "Action:                               Allow" -ErrorAction SilentlyContinue


    if($ICMP4Stat -eq $null){
                           $data = [ordered]@{
                                                "Firewall Rule" = "File and Printer Sharing (Echo Request - ICMPv4-In)"
                                                 Status = "Failed" }
                            New-Object -TypeName PSObject -Property $data }
    else{
                            $data = [ordered]@{
                                                "Firewall Rule" = "File and Printer Sharing (Echo Request - ICMPv4-In)"
                                                 Status = "Passed" }
                            New-Object -TypeName PSObject -Property $data }


    if($Server_Env -eq "PROD"){
             if($NBStat -eq $null){
                            $data = [ordered]@{
                                                "Firewall Rule" = "Netbackup"
                                                 Status = "Failed" }
                            New-Object -TypeName PSObject -Property $data }
    else{
                            $data = [ordered]@{
                                                "Firewall Rule" = "Netbackup"
                                                 Status = "Passed" }
                            New-Object -TypeName PSObject -Property $data }

    }



    if($RDSStat1 -eq $null -or $RDSStat2 -eq "Failed" -or $RDSStat3 -eq $null -or $RDSStat4 -eq $null -or $RDSStat5 -eq $null){
                            $data = [ordered]@{
                                                "Firewall Rule" = "Remote Desktop 3389 - Restricted"
                                                 Status = "Failed" }
                            New-Object -TypeName PSObject -Property $data }
        

    else{
                            $data = [ordered]@{
                                                "Firewall Rule" = "Remote Desktop 3389 - Restricted"
                                                 Status = "Passed" }
                            New-Object -TypeName PSObject -Property $data }


}


Function Get-Remote_Desktop_Firewall  {


if($osversion -like '*Microsoft Windows Server 2008*'){
$RDSGroup = netsh advfirewall firewall show rule name="Remote Desktop (TCP-In)" | sls "Enabled:                              No"
    if($RDSGroup -eq $null){$RDSGroupVal = "Failed"}
    else{$RDSGroupVal = "Passed"}
    

    if($RDSGroupVal -eq "Failed"){
                            $data = [ordered]@{
                                                "Firewall Rule" = "Remote Desktop (TCP-In)"
                                                 Status = $RDSGroupVal }
                            New-Object -TypeName PSObject -Property $data }
    
    else{
                            $data = [ordered]@{
                                                "Firewall Rule" = "Remote Desktop (TCP-In)"
                                                 Status = $RDSGroupVal }
                            New-Object -TypeName PSObject -Property $data }

}

else{

    #$fragments+= "<table><tr><th>Firewall Rule</th><th>Enabled</th><th>Status</th></tr>"

    ForEach ($RDSRule in (Get-NetFirewallRule -DisplayGroup "Remote Desktop")){
                $RDSRuleName = ($RDSRule.DisplayName)
                $RDSRuleStat = ($RDSRule.Enabled)

                if($RDSRuleStat -eq "False"){
                            $data = [ordered]@{
                                                "Firewall Rule" = $RDSRuleName
                                                 Enabled = $RDSRuleStat
                                                 Status = "Passed" }
                            New-Object -TypeName PSObject -Property $data }

                else{
                            $data = [ordered]@{
                                                "Firewall Rule" = $RDSRuleName
                                                 Enabled = $RDSRuleStat
                                                 Status = "Failed" }
                            New-Object -TypeName PSObject -Property $data }

     }



 }

}


##### Function Registry
   
function Get-RegistryInfo {

    Param(
    [parameter(Mandatory=$true)]
    [Array]
    $Registry_hash
    )

   
    
     
    foreach ($Reg_key in $Registry_hash) {

    
                   $Reg_detail = gp -Path $Reg_key.path -Name $Reg_key.parameter -ErrorAction SilentlyContinue
                   $ParamValue = $Reg_key.parameter
                   $Param = $Reg_detail.$ParamValue
                   #[array]$Key_Name = ($Reg_key.path).Split('\')
                   $Key_Name_final = $Reg_key.Parameter

                   if(( $Param -eq $null) -or ($Reg_detail -eq $null)){
                                $Data = [ordered]@{
                                        Registry = $Reg_key.Description
                                        Remarks = "Registry key is not existing"
                                        Status="Failed"}
  
                                 New-Object -TypeName PSObject -Property $Data

                   }
                   else{
                        if(( $Param -ne $Reg_key.valuecheck) -and ($Reg_detail -ne $null)){
                                $Data = [ordered]@{
                                        Registry = $Reg_key.Description
                                        Remarks = "Registry key is not defined"
                                        Status="Failed"}

                                 New-Object -TypeName PSObject -Property $Data

                        }
                        else{

                                $Data = [ordered]@{
                                        Registry = $Reg_key.Description
                                        Remarks = "$Key_Name_final = $Param"
                                        Status="Passed"}

                                 New-Object -TypeName PSObject -Property $Data

                        }


                   }
                 

    }

}

#region Registry Information
    
    #Disable USB Storage Devices and Autoplay
    $hashes_1 = @()
    $Registry_hash_1 = New-Object PSObject -property @{
                                Description="USB Storage Devices";
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\UsbStor";
                                Parameter="Start"
                                valuecheck ="4"}

    $hashes_1 += $Registry_hash_1 
    $Registry_hash_1 = New-Object PSObject -property @{
                                Description="USB Storage Devices Autoplay";
                                Path="HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer";
                                Parameter="NoDriveTypeAutoRun"
                                valuecheck ="255"}      
    $hashes_1 += $Registry_hash_1  
     
                
    
    #Disable SSL/TLS 1.0/TLS 1.1
    $hashes_2 = @()
    $Registry_hash_2 = New-Object PSObject -property @{
                                Description="SSL 2.0 "
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server"
                                Parameter="Enabled"
                                valuecheck ="0"}
    $hashes_2 += $Registry_hash_2 

    $Registry_hash_2 = New-Object PSObject -property @{
                                Description="SSL 3.0"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server"
                                Parameter="Enabled"
                                valuecheck ="0"}
    $hashes_2 += $Registry_hash_2 
    
    $Registry_hash_2 = New-Object PSObject -property @{
                                Description="TLS 1.0"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server"
                                Parameter="Enabled"
                                valuecheck ="0"}
    $hashes_2 += $Registry_hash_2 
    
    $Registry_hash_2 = New-Object PSObject -property @{
                                Description="TLS 1.1"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server"
                                Parameter="Enabled"
                                valuecheck ="0"}
    $hashes_2 += $Registry_hash_2 


$osversion = gcim -class Win32_OperatingSystem | select Caption
if($osversion -like '*Microsoft Windows Server 2008*'){
    
    $Registry_hash_2 = New-Object PSObject -property @{
                                Description="TLS 1.2"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.2\Server"
                                Parameter="DisabledByDefault"
                                valuecheck ="0"}
    $hashes_2 += $Registry_hash_2 
}
else {}
                      
          
    
    #Disable RC4 Ciphers
    $hashes_3 = @()
    $Registry_hash_3 = New-Object PSObject -property @{
                                Description="RC4 128/128"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 128/128"
                                Parameter="Enabled"
                                valuecheck ="0"}
    $hashes_3 += $Registry_hash_3 


    $Registry_hash_3 = New-Object PSObject -property @{
                                Description="RC4 40/128"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 40/128"
                                Parameter="Enabled"
                                valuecheck ="0"}
    $hashes_3 += $Registry_hash_3 


    $Registry_hash_3 = New-Object PSObject -property @{
                                Description="RC4 56/128"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\RC4 56/128"
                                Parameter="Enabled"
                                valuecheck ="0"}
    $hashes_3 += $Registry_hash_3 

          

    
    
    #Disable IP Source Routing
    $hashes_4 = @()
    $Registry_hash_4 = New-Object PSObject -property @{
                                Description="IP Source Routing TCPIP"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
                                Parameter="DisableIPSourceRouting"
                                valuecheck ="2"}
    $hashes_4 += $Registry_hash_4 


    $Registry_hash_4 = New-Object PSObject -property @{
                                Description="IP Source Routing TCPIP6"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters"
                                Parameter="DisableIPSourceRouting"
                                valuecheck ="2"}
    $hashes_4 += $Registry_hash_4 

    
    
    #DisableStrictNameChecking and DisableLoopbackCheck Settings
    $hashes_5 = @()
    $Registry_hash_5 = New-Object PSObject -property @{
                                Description="DisableStrictNameChecking"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
                                Parameter="DisableStrictNameChecking"
                                valuecheck ="1"}
    $hashes_5 += $Registry_hash_5 

    $Registry_hash_5 = New-Object PSObject -property @{
                                Description="DisableLoopbackCheck"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\LSA"
                                Parameter="DisableLoopbackCheck"
                                valuecheck ="1"}
    $hashes_5 += $Registry_hash_5 


    
    
    #DNS Cache TTL
    $hashes_6 =  New-Object PSObject -property @{
                                Description="Max CacheEntry TTL Limit"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters"
                                Parameter="MaxCacheEntryTtlLimit"
                                valuecheck ="900"}
  
    
    
  
    #Remote Desktop Access
   Function Get-hashes_7_result  {


    $hashes_7 = @()

    $Registry_hash_7 = New-Object PSObject -property @{
                                Description="Allow remote connections to this computer"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server"
                                Parameter="fDenyTSConnections"
                                valuecheck ="0"}
    $hashes_7 += $Registry_hash_7 

    $Registry_hash_7 = New-Object PSObject -property @{
                                Description= "Session Time Limit"
                                Path="HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
                                Parameter="MaxIdleTime"
                                valuecheck ="900000"}
    $hashes_7 += $Registry_hash_7 

    $Registry_hash_7 = New-Object PSObject -property @{
                                Description="Administrative shares key disabled"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
                                Parameter="AutoShareServer"
                                valuecheck ="0"}
    $hashes_7 += $Registry_hash_7 

    
    Get-RegistryInfo -Registry_hash $hashes_7


        $NLA = (gwmi -class Win32_TSGeneralSetting -ns root\cimv2\terminalservices -f "TerminalName='RDP-tcp'").UserAuthenticationRequired
        if ($NLA -eq 1){ 
               
                $data = [ordered]@{
                        Registry ="Remote Desktop with Network Level Authentication"
                        Remarks = "UserAuthenticationRequired = $NLA"
                        Status = "Passed"}
                New-Object -TypeName PSObject -Property $data
        }
        else{
                $data = [ordered]@{
                        Registry ="Remote Desktop with Network Level Authentication"
                        Remarks = "UserAuthenticationRequired = $NLA"
                        Status = "Failed"}
                New-Object -TypeName PSObject -Property $data
        } 
    
    } #end Get-hashes_7_result

                


       

#endregion



#region Other Baseline Configuration Settings


#Internet Explorer
function Get-InternetExplorer{
    
    gp -Path "HKLM:\SOFTWARE\Microsoft\Internet Explorer" -ErrorAction SilentlyContinue | 
    `Select @{n='Version';e={$_.svcVersion}} , @{n='Update Version';e={$_.svcUpdateVersion}}, @{n='KB Numbern';e={$_.svcKBNumber}}

} #end Get-InternetExplorer



#HP IRS SNMP Information  
function Get-HP{



    $HPSrv = (gcim -Class Win32_ComputerSystem).Manufacturer #check if HP IRS is applicable
if($HPSrv -like '*HP*'){
$PerManKey = "HKLM:\SYSTEM\CurrentControlSet\services\SNMP\Parameters\PermittedManagers"
$ACNRegKey = "HKLM:\SYSTEM\CurrentControlSet\services\SNMP\Parameters\ValidCommunities"
$PerManProp = gp -Path "HKLM:\SYSTEM\CurrentControlSet\services\SNMP\Parameters\PermittedManagers" -ErrorAction SilentlyContinue | Select-Object * -exclude PS* | fl 
$ACNReg1Prop = gp -Path $ACNRegKey -Name "BDOprivate" -ErrorAction SilentlyContinue
$ACNReg2Prop = gp -Path $ACNRegKey -Name "BDOpublic" -ErrorAction SilentlyContinue

if(($ACNReg1Prop.BDOprivate -eq $null) -or ($ACNRegKey -eq $null)){$ACNReg1Val = "False; Registry key is not existing."}else{
if(($ACNReg1Prop.BDOprivate -ne 16) -and ($ACNRegKey -ne $null)){$ACNReg1Val = "False"}else{$ACNReg1Val = "True"}}

if(($ACNReg2Prop.BDOpublic -eq $null) -or ($ACNRegKey -eq $null)){$ACNReg2Val = "False; Registry key is not existing."}else{
if(($ACNReg2Prop.BDOpublic -ne 4) -and ($ACNRegKey -ne $null)){$ACNReg2Val = "False"}else{$ACNReg2Val = "True"}}

$PerManProp = gp -Path "HKLM:\SYSTEM\CurrentControlSet\services\SNMP\Parameters\PermittedManagers" -ErrorAction SilentlyContinue
if($PerManProp -like "*app01.hpirs.bdo.com.ph*"){
$PerManVal = "app01.hpirs.bdo.com.ph is defined."
}
else{$PerManVal = "app01.hpirs.bdo.com.ph is not defined."}

           

                if($ACNReg1Val -eq "False; Registry key is not existing." -or $ACNReg1Val -eq "Failed"){

                         $data = [ordered]@{
                                    'Accepted Community Name' = "BDOPrivate"
                                    Remarks= "BDOPrivate is not defined"
                                    Status = "Failed" }

                        New-Object -TypeName PSObject -Property $data
                        
                }
                else{
                         
                         

                        $data = [ordered]@{
                                    'Accepted Community Name' = "BDOPrivate"
                                    Remarks= "BDOPrivate is defined"
                                    Status = "Passed" }

                        New-Object -TypeName PSObject -Property $data 
                                          
                }

                
                
                if($ACNReg2Val -eq "False; Registry key is not existing." -or $ACNReg2Val -eq "Failed"){
                       

                         $data = [ordered]@{
                                    'Accepted Community Name' = "BDOPublic"
                                    Remarks= "BDOPrivate is not defined"
                                    Status = "Failed" }

                        New-Object -TypeName PSObject -Property $data 
                        
                }
                else{
                       
                                           
                        $data = [ordered]@{
                                    'Accepted Community Name' = "BDOPublic"
                                    Remarks= "BDOPrivate is defined"
                                    Status = "Passed" }

                        New-Object -TypeName PSObject -Property $data
                        
                }


               

                if($PerManVal -eq "app01.hpirs.bdo.com.ph is not defined."){
                     
                        $data = [ordered]@{
                                    'Accepted Community Name' = "HP IRS"
                                    Remarks= "app01.hpirs.bdo.com.ph is not defined"
                                    Status = "Failed" }
                                    
                        
                        New-Object -TypeName PSObject -Property $data
                        
                }
                else{
                       
                        $data = [ordered]@{
                                    'Accepted Community Name' = "HP IRS"
                                    Remarks= "app01.hpirs.bdo.com.ph is defined"
                                    Status = "Passed" }


                        New-Object -TypeName PSObject -Property $data
                        
                }




    

    }
    else {}
} #Get-HP





#Network Connections
function Get-NetworkInfo{

    $bdolan = gcim win32_networkadapter -Filter "NetEnabled='True'" | where NetConnectionID -eq "BDO"
        if($bdolan -eq $null){
                $data = [ordered]@{
                                    LAN = 'BDO LAN'
                                    Remarks= "No connection named BDO has been detected"
                                    Status = "Failed" }

                New-Object -TypeName PSObject -Property $data

        }
        else{
                $data = [ordered]@{
                                    LAN = 'BDO LAN'
                                    Remarks= "BDO LAN has been renamed"
                                    Status = "Passed" }

                New-Object -TypeName PSObject -Property $data

        }


    if($Server_Env -eq "PROD"){
                $nblan = gcim win32_networkadapter -Filter "NetEnabled='True'" | where NetConnectionID -eq "Netbackup"
                if($nblan -eq $null){
                        
                        $data = [ordered]@{
                                    LAN = 'Netbackup LAN'
                                    Remarks= "No connection named Netbackup has been detected"
                                    Status = "Failed" }

                New-Object -TypeName PSObject -Property $data

                }
                else{
                        
                        $data = [ordered]@{
                                    LAN = 'Netbackup LAN'
                                    Remarks= "BDO LAN has been renamed"
                                    Status = "Passed" }

                New-Object -TypeName PSObject -Property $data

                }
    }
    else{}
        


} #Get-NetworkInfo


#OTHERS Baseline
function Get-OthersBaseline{

    #Last Accessed Date
   
   
    $Reg_key = "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem"
    $Reg_key_Name = "NtfsDisableLastAccessUpdate"
    $Reg_key_Value = 0
    $Reg_key_Value2 = 2147483648
    $LastAccessedDate = gp -Path $Reg_key -Name $Reg_key_Name -ErrorAction SilentlyContinue
    $LastAccessedDate.NtfsDisableLastAccessUpdate

    if (($LastAccessedDate.NtfsDisableLastAccessUpdate -eq $Reg_key_Value) -or ($LastAccessedDate.NtfsDisableLastAccessUpdate -eq $Reg_key_Value2)) {
            $data = [ordered]@{
                                    Name = "Last Accessed Date"
                                    Remarks= "Last accessed date has been enabled"
                                    Status = "Passed" }

             New-Object -TypeName PSObject -Property $data
    }
    else { 
            $data = [ordered]@{
                                    Name = "Last Accessed Date"
                                    Remarks= "Last accessed date is not enabled"
                                    Status = "Failed" }

            New-Object -TypeName PSObject -Property $data
    }
   


    #DSC
    <#
    $DSCLogs = [System.Diagnostics.EventLog]::Exists('PSDSCLogs'); #check if DSC Logs is present
    if($DSCLogs -eq $false){

            $data = [ordered]@{
                                    Name = "DSC Configuration"
                                    Remarks= "DSC has not been deployed"
                                    Status = "Failed" }

                        New-Object -TypeName PSObject -Property $data

    }
    else{
       
                        $data = [ordered]@{
                                    Name = "DSC Configuration"
                                    Remarks= "DSC has been deployed"
                                    Status = "Passed" }

                        New-Object -TypeName PSObject -Property $data
    }
    #>



    #check if SMB 1.0 has been disabled
    $SMBOS = gcim -class Win32_OperatingSystem | select Caption
    if($SMBOS -like '*Microsoft Windows Server 201*'){
            $SMBFeat = Get-WindowsFeature -Name FS-SMB1
            If ($SMBFeat.Installed -eq "True"){
                 
                    $data = [ordered]@{
                                    Name = "SMB 1.0/CIFS File Sharing Support"
                                    Remarks= "SMB 1.0/CIFS File Sharing Support is still installed"
                                    Status = "Failed" }

                        New-Object -TypeName PSObject -Property $data
            }
            else{
             
                    $data = [ordered]@{
                                    Name = "SMB 1.0/CIFS File Sharing Support"
                                    Remarks= "SMB 1.0/CIFS File Sharing Support has been removed"
                                    Status = "Passed" }

                        New-Object -TypeName PSObject -Property $data
            }             
    }
    else{

            $data = [ordered]@{
                                    Name = "SMB 1.0/CIFS File Sharing Support"
                                    Remarks= "OS is not Windows Server 201*"
                                    Status = "Passed" }

                        New-Object -TypeName PSObject -Property $data
   }



} # Get-OthersBaseline

#endregion Other Baseline Configuration Settings

#region Qualys Fixes

    #NetBIOS over TCP/IP
    function Get-NetBIOS{

        ForEach ($NetBios in (Get-WmiObject Win32_NetworkAdapter -Filter "NetEnabled='True'")) #get enabled network adapter and index
            {  
                $NetBiosCfg = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "Index = '$($NetBios.Index)'" #match index to IP address
                $NetBiosConName = ($NetBios.NetConnectionID)
                    ForEach ($NetBiosVal in ($NetBiosCfg).TcpipNetbiosOptions){
                            if($NetBiosVal -eq 2){

                            $data = [ordered]@{
                                    'LAN Adapter' = $NetBios.NetConnectionID
                                     Remarks= "Netbios has been disabled"
                                     Status = "Passed" }

                            New-Object -TypeName PSObject -Property $data
                            
                            
                            }
                            else{
                            $data = [ordered]@{
                                    'LAN Adapter' = $NetBios.NetConnectionID
                                     Remarks= "Netbios is not disabled"
                                     Status = "Failed" }

                            New-Object -TypeName PSObject -Property $data

                            
                            }

                    }
        }


    }

    #Fix to Spectre/Meltdown
            $vmms = gcim -Class Win32_Service -f "Name='vmms'"
                    if($vmms -eq $null){

                    $Spectre_Meltdown  = @()
                    $Spectre_Meltdown_1 = New-Object PSObject -property @{
                                Description="FeatureSettingsOverride key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"
                                Parameter="FeatureSettingsOverride"
                                valuecheck ="72"}
                    $Spectre_Meltdown  += $Spectre_Meltdown_1

                    $Spectre_Meltdown_2 = New-Object PSObject -property @{
                                Description="FeatureSettingsOverrideMask key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"
                                Parameter="FeatureSettingsOverrideMask"
                                valuecheck ="3"}
                    $Spectre_Meltdown  += $Spectre_Meltdown_2



                    

            }
            else{



                    $Spectre_Meltdown  = @()
                    $Spectre_Meltdown_1 = New-Object PSObject -property @{
                                Description="Feature Settings Override key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"
                                Parameter="FeatureSettingsOverride"
                                valuecheck ="72"}
                    $Spectre_Meltdown  += $Spectre_Meltdown_1

                    $Spectre_Meltdown_2 = New-Object PSObject -property @{
                                Description="Feature Settings Override Mask key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"
                                Parameter="FeatureSettingsOverrideMask"
                                valuecheck ="3"}
                    $Spectre_Meltdown  += $Spectre_Meltdown_2


                    $Spectre_Meltdown_3 = New-Object PSObject -property @{
                                Description="MinVmVersionForCpuBasedMitigations key"
                                Path="HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization"
                                Parameter="MinVmVersionForCpuBasedMitigations"
                                valuecheck ="1.0"}
                    $Spectre_Meltdown  += $Spectre_Meltdown_3


            }





#Fix to Microsoft Group Policy Remote Code Execution Vulnerability
    function Get-Netlogon{
            $GPRCEKey ="HKLM:\SOFTWARE\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths"
            $GPRCE1Prop = gp -Path $GPRCEKey -Name "\\*\NETLOGON" -ErrorAction SilentlyContinue
            $GPRCE2Prop = gp -Path $GPRCEKey -Name "\\*\SYSVOL" -ErrorAction SilentlyContinue
            if((($GPRCE1Prop)."\\*\NETLOGON" -eq $null) -or ($GPRCEKey -eq $null)){$GPRCE1Val = "Failed; Registry key is not existing."}else{
            if((($GPRCE1Prop)."\\*\NETLOGON" -ne "RequireMutualAuthentication=1, RequireIntegrity=1") -and ($GPRCEKey -ne $null)){$GPRCE1Val = "Failed"}else{$GPRCE1Val = "Passed"}}

            if((($GPRCE2Prop)."\\*\SYSVOL" -eq $null) -or ($GPRCEKey -eq $null)){$GPRCE2Val = "Failed; Registry key is not existing."}else{
            if((($GPRCE2Prop)."\\*\SYSVOL" -ne "RequireMutualAuthentication=1, RequireIntegrity=1") -and ($GPRCEKey -ne $null)){$GPRCE2Val = "Failed"}else{$GPRCE2Val = "Passed"}}
            
            

                    if($GPRCE1Val -eq "Failed; Registry key is not existing." -or $GPRCE1Val -eq "Failed"){
                            #$fragments+= "<tr><td>NETLOGON key defined</td><td class='alert'>$GPRCE1Val</td></tr>"
                            $data = [ordered]@{
                                    Registry = "NETLOGON key "
                                    Remarks= "Registry key is not existing"
                                    Status = "Failed" }
                                New-Object -TypeName PSObject -Property $data
                     }
                    else{
                            #$fragments+= "<tr><td>NETLOGON key defined</td><td class='passed'>$GPRCE1Val</td></tr>"
                            $data = [ordered]@{
                                    Registry = "NETLOGON key"
                                    Remarks= "Registry key is defined"
                                    Status = "Passed" }
                                New-Object -TypeName PSObject -Property $data
                     }
                    
                    if($GPRCE2Val -eq "Failed; Registry key is not existing." -or $GPRCE2Val -eq "Failed"){
                            #$fragments+= "<tr><td>SYSVOL key defined</td><td class='alert'>$GPRCE2Val</td></tr>"
                            $data = [ordered]@{
                                    Registry = "SYSVOL key"
                                    Remarks= "Registry key is not existing"
                                    Status = "Failed" }
                                New-Object -TypeName PSObject -Property $data
                    }
                    else{
                            #$fragments+= "<tr><td>SYSVOL key defined</td><td class='passed'>$GPRCE2Val</td></tr>"
                            $data = [ordered]@{
                                    Registry = "SYSVOL key"
                                    Remarks= "Registry key is defined"
                                    Status = "Passed" }
                                New-Object -TypeName PSObject -Property $data
                    }

    }
    
#Fix to Windows Registry Setting To Globally Prevent Socket Hijacking Missing
    $SocketHijacking = New-Object PSObject -property @{
                                Description="Disable Address Sharing Key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\Afd\Parameters"
                                Parameter="DisableAddressSharing"
                                valuecheck ="1"}




#TLS ciphers with 64bit block size vulnerability (Sweet32)
    $Sweet32= New-Object PSObject -property @{
                                Description="Triple DES 168 Key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\Triple DES 168"
                                Parameter="Enabled"
                                valuecheck ="0"}



#Disable Cached Logon Credential, Null Session, LM Hash and NTLMv1
    $CacheLogon = @()
    $CacheLogon_1 = New-Object PSObject -property @{
                                Description="Cache Logon Key"
                                Path="HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
                                Parameter="CachedLogonsCount"
                                valuecheck ="0"}
    $CacheLogon  += $CacheLogon_1

    $CacheLogon_2 = New-Object PSObject -property @{
                                Description="Null Session Key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
                                Parameter="RestrictAnonymous"
                                valuecheck ="1"}
    $CacheLogon  += $CacheLogon_2

    <#
    $CacheLogon_3 = New-Object PSObject -property @{
                                Description="LM Hash and NTLMv1"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Control\LSA"
                                Parameter="LMCompatibilityLevel"
                                valuecheck ="3"}
    $CacheLogon  += $CacheLogon_3
    #>



#Internet Explorer Security
    $InternetExplorer = @()
    $InternetExplorer_1 = New-Object PSObject -property @{
                                Description="FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX Key"
                                Path="HKLM:\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX"
                                Parameter="iexplore.exe"
                                valuecheck ="1"}
    $InternetExplorer  += $InternetExplorer_1

    $InternetExplorer_2 = New-Object PSObject -property @{
                                Description="WOW6432Node Key"
                                Path="HKLM:\SOFTWARE\WOW6432Node\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX"
                                Parameter="iexplore.exe"
                                valuecheck ="1"}
    $InternetExplorer  += $InternetExplorer_2



#SMB Signing


    $SMBSigning = @()
    $SMBSigning_1 = New-Object PSObject -property @{
                                Description="LanmanWorkstation - RequireSecuritySignature Key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters"
                                Parameter="RequireSecuritySignature"
                                valuecheck ="1"}
    $SMBSigning  += $SMBSigning_1

    $SMBSigning_2 = New-Object PSObject -property @{
                                Description="LanmanServer - EnableSecuritySignature Key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
                                Parameter="enablesecuritysignature"
                                valuecheck ="1"}
    $SMBSigning  += $SMBSigning_2

    $SMBSigning_3 = New-Object PSObject -property @{
                                Description="LanmanServer - RequireSecuritySignature Key"
                                Path="HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
                                Parameter="requiresecuritysignature"
                                valuecheck ="1"}
    $SMBSigning  += $SMBSigning_3
 



#endregion

#HTML =======================================================================================================



 #stylesheet
$head = @"
<Title>Baseline Configuration Report - $($env:computername)</Title>
<style>
body { background-color:#E5E4E2;
       font-family:Monospace;
       font-size:10pt; }
td, th { border:0px solid black; 
         border-collapse:collapse;
         white-space:pre; 
         }
th { color:white;
     background-color:MidnightBlue; }
.subheader { padding: 2px; margin: 0px ;white-space:pre; }
table, tr, td, th { padding: 2px; margin: 0px ;white-space:pre; }
tr:nth-child(odd) {background-color: lightgray}
table { width:100%;margin-left:5px; margin-bottom:20px;}
h2 {
 font-family:Tahoma;
 color:MidnightBlue;
}
.alert {
 color: red; 
 width: 10%;
 text-align: center;  font-style:bold;
 }
.passed {
 text-align: center;
 color: green; 
 width: 10%  }
.footer 
{ color:blue; 
  margin-left:10px; 
  font-family:Tahoma;
  font-size:10pt;
  font-style:italic;
}
.transparent {
background-color:#E5E4E2;
}

.colspan, h4, p {
background-color:#E5E4E2;
 font-family:Tahoma;
 color:#6D7B8D;
 font-size:12pt;
}


 
 
</style>
 
"@

#Image & Title
$html_image =@"
<table>
<tr>
<td class='transparent'><Img src='data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD//gA7Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2NjIpLCBxdWFsaXR5ID0gODIK/9sAQwAGBAQFBAQGBQUFBgYGBwkOCQkICAkSDQ0KDhUSFhYVEhQUFxohHBcYHxkUFB0nHR8iIyUlJRYcKSwoJCshJCUk/9sAQwEGBgYJCAkRCQkRJBgUGCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQkJCQk/8AAEQgB/gH+AwEiAAIRAQMRAf/EAB8AAAEFAQEBAQEBAAAAAAAAAAABAgMEBQYHCAkKC//EALUQAAIBAwMCBAMFBQQEAAABfQECAwAEEQUSITFBBhNRYQcicRQygZGhCCNCscEVUtHwJDNicoIJChYXGBkaJSYnKCkqNDU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6g4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2drh4uPk5ebn6Onq8fLz9PX29/j5+v/EAB8BAAMBAQEBAQEBAQEAAAAAAAABAgMEBQYHCAkKC//EALURAAIBAgQEAwQHBQQEAAECdwABAgMRBAUhMQYSQVEHYXETIjKBCBRCkaGxwQkjM1LwFWJy0QoWJDThJfEXGBkaJicoKSo1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoKDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uLj5OXm5+jp6vLz9PX29/j5+v/aAAwDAQACEQMRAD8A+qaSlooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkPSlooA8M0f43fETxRNqT+G/hpBqVpY3stk0/9piPLIcdCvpg1pf8ACx/jL/0SGD/wcp/8TTP2Y+fD3iv/ALGa9/8AZa9koA8e/wCFj/GX/okMH/g5T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/iaP+Fj/ABl/6JDB/wCDhP8A4mvYaKAPHv8AhY/xl/6JDB/4OU/+Jo/4WP8AGX/okMH/AIOU/wDia9hooA8e/wCFj/GX/okMH/g5T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/iaP+Fj/ABl/6JDB/wCDlP8A4mvYaKAPHv8AhY/xl/6JDB/4OU/+Jo/4WP8AGT/okMH/AIOU/wDia9hooA8e/wCFj/GX/okMH/g5T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/iaP+Fj/ABl/6JDB/wCDlP8A4mvYaKAPHv8AhY/xl/6JDB/4OU/+Jo/4WP8AGX/okMH/AIOU/wDia9hooA8e/wCFj/GT/okMH/g5T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/iaP+Fj/ABl/6JDB/wCDlP8A4mvYaKAPHv8AhY/xl/6JDB/4OU/+Jo/4WP8AGX/okMH/AIOU/wDia9hooA8e/wCFj/GT/okMH/g5T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/iaP+Fj/ABl/6JDB/wCDlP8A4mvYaKAPHv8AhY/xl/6JDB/4OU/+Jo/4WP8AGX/okMH/AIOU/wDia9hooA8e/wCFj/GT/okMH/g5T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/iaP+Fj/ABl/6JDB/wCDlP8A4mvYaKAPHv8AhY/xl/6JDB/4OU/+Jo/4WP8AGX/okMH/AIOU/wDia9hooA8e/wCFj/GX/okMH/g5T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/iaP+Fj/ABl/6JDB/wCDhP8A4mvYaKAPHv8AhY/xl/6JDB/4OU/+Jo/4WP8AGX/okMH/AIOE/wDia9hooA8e/wCFj/GX/okMH/g5T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/iaP+Fj/ABl/6JDB/wCDhP8A4mvYaKAPHv8AhY/xl/6JDB/4OU/+Jo/4WP8AGX/okMH/AIOU/wDia9hooA8e/wCFj/GX/okMH/g4T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/iaP+Fj/ABl/6JDB/wCDhP8A4mvYaKAPHv8AhY/xl/6JDB/4OE/+Jo/4WP8AGX/okMH/AIOU/wDia9hooA8e/wCFj/GX/okMH/g4T/4mj/hY/wAZf+iQwf8Ag5T/AOJr2GigDx7/AIWP8Zf+iQwf+DlP/ia1fhV8Uda8c+IfEWha94bj0K+0PyPNjW687cZNxxnaBxt9+temV418Lefjt8VvZtP/APQJKAPZaKKKACiiigDxr9mL/kXvFf8A2M17/wCy17LXjX7MX/IveK/+xmvf/Za9loAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApKWigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKAEpaKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArxr4Wf8l2+K3+9p/8A6BJXsteNfCz/AJLt8Vv97T//AECSgD2WiiigAooooA8a/Zi/5F7xX/2M17/7LXsteNfsxf8AIveK/wDsZr3/ANlr2WgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK8a+Fn/ACXb4rf72n/+gSV7LXjfws/5Lt8Vv97T/wD0CSgD2SiiigAooooA8a/Zj/5F7xX/ANjNe/8Astey141+zH/yL3iv/sZr3/2WvZaACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArxr4Wf8l2+K3+9p/8A6BJXsteNfCz/AJLt8Vv97T//AECSgD2WiiigAooooA8a/Zi/5F7xX/2M17/7LXsteNfsx/8AIveK/wDsZr3/ANlr2WgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK8b+Fn/ACXb4rf72n/+gSV7JXjXws/5Lt8Vv97T/wD0CSgD2WiiigAooooA8a/Zi/5F7xX/ANjNe/8Astey141+zF/yL3iv/sZr3/2WvZaACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArxr4Wf8l2+K3+9p/8A6BJXsteNfCz/AJLt8Vv97T//AECSgD2WiiigAooooA8a/Zi/5F7xX/2M17/7LXsteNfsx/8AIveK/wDsZr3/ANlr2WgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK8a+Fn/ACXb4rf72n/+gSV7LXjXws/5Lt8Vv97T/wD0CSgD2WiiigAooooA8a/Zi/5F7xX/ANjNe/8Astey141+zF/yL3iv/sZr3/2WvZaACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArxr4Wf8l2+K3+9p/8A6BJXsteNfCz/AJLt8Vv97T//AECSgD2WiiigAooooA8a/Zi/5F7xX/2M17/7LXsteNfsx/8AIveK/wDsZr3/ANlr2WgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK8a+Fn/ACXb4rf72n/+gSV7LXjXws/5Lt8Vv97T/wD0CSgD2WiiigAooooA8a/Zj/5F7xX/ANjNe/8Astey141+zH/yL3iz/sZr3/2WvZaACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArxr4Wf8l2+K3+9p/8A6BJXsteNfCz/AJLt8Vv97T//AECSgD2WiiigAooooA8a/Zj/AORe8V/9jNe/+y17LXjX7Mf/ACL3iv8A7Ga9/wDZa9loAKKKKACikrnta+IPhbw7ffYNX1yysbraH8qaTDbT0NNRcnZITaWrOiorj/8Ahb3gL/oa9L/7/Uf8Le8Bf9DXpf8A3+qvZT7Mn2kO52FFcf8A8Le8Bf8AQ16X/wB/qP8Ahb3gL/oa9L/7/Ueyn2Ye0h3Oworj/wDhb3gL/oa9L/7/AFH/AAt7wF/0Nel/9/qPZT7MPaQ7nYUZrj/+FveAv+hr0v8A7/Uf8Ld8Bf8AQ16X/wB/qPZT7MPaQ7nYUVyA+LngInH/AAlelfjMBVy1+InhC9wLfxLpMhJwMXSD+ZodOfZh7SPc6OioYLy3uoxJbzRzIRkNG4YH8RUoIPSoLFooooAKKQ8CuWvfih4L028msr3xHp1vcwsUkiklwyEdiKai5bITkludVRXH/wDC3fAX/Q16X/3+o/4W94C/6GvS/wDv9Veyn2ZPtIdzsKK4/wD4W94C/wChr0v/AL/Uf8Le8Bf9DXpf/f6j2U+zD2kO52FFcf8A8Le8Bf8AQ16X/wB/qP8Ahb3gL/oa9L/7/Ueyn2Ye0h3OworlYfip4HnIEfirSCT/ANPCitOz8W+H9QYLaa1p05JwBHcoT+WaHTmt0xqcX1Neio0lSQZRgw9Qc08HNQULRRRQAUUUUAFFFFABRRRQAUU0sBVK81zT7H/X3KKf7oOT+QrKrWp0lzVJJLzKhCU3aKuX6K5i58cWacQQSy+5+UVQk8dXJz5dpEo/2mJrxq3E2XU/+Xl/RNnbDLMTL7NvU7aiuCPjXUuywAf7p/xoHjbUgeUgP/AT/jXL/rfl/d/ca/2PiOy+872iuKi8d3AI82zjb/dYitC28b2MmBPDND743CuujxLl9V2VS3rdGM8txEN4nS0VStNWsr4Zt7iNz6Z5/KrYNezTqwqLmg015HHKLi7SVh1FIOlLWhIUUUUAFFFFABRRRQAV418LP+S7fFb/AHtP/wDQJK9lrxr4Wf8AJdvit/vaf/6BJQB7LRRRQAUUUUAeNfsxf8i94r/7Ga9/9lr2WvGv2Y/+Re8V/wDYzXv/ALLXstABRRRQAhr5F/ad4+JpA6fYIf5tX10a+Rf2nv8Akpx/68If5tXo5X/H+TOLHfwjyWiiivozxrBRRU6WN3IiyJazsjchhGSCPak3bcdiCirH9nXv/Pncf9+2/wAKP7Ovf+fO4/79t/hS5l3DlfYr0VY/s69/587j/v23+FMktbiH/WQSp/vIRT5kHL5EVGOc9aTNLTAuadrOpaRMJtOv7qzkHO6CVkP6GvTfCH7SXjDw+6Q6o8etWgwCJxtlA9nHf6g15NRWVShTqK0lcuFWcHeLPubwF8T/AA98Q7My6TclLlBmW0mwJYvw7j3HFdcDnvX59aFruoeGtVt9V0u5e3u7dgyup6+oI7g9xX2t8L/H1t8Q/C9vqsYWO5T91dQg58uUDn8D1Hsa8DG4L2PvR+E9bDYr2vuy3Owr4V+K/wDyUjxH/wBf8v8AOvuqvhX4r/8AJSfEf/X/AC/zrbKf4kvQzzD4EcpRRRXvHkhRRVj+zb7/AJ87j/v2f8KTaW47FeirH9nXv/Pncf8Aftv8KRrG7QZa1nUe8Zpcy7hbyIKTApzKyHDKVPoRikzVbhsaGn+ItY0l1fT9VvrQr08mdkx+RrttC/aB+IGhlQdXGoRL/BexiTP/AALhv1rzmis50ac/iii41Jx2Z9K+GP2rbG4ZIfEmkSWbHg3FmfMTPup5A/E17L4a8Y6F4ttBc6Lqltepj5hG/wAyezL1H418C1b0vV9Q0S8S90y8ns7mM5WSFypH/wBavPrZXTlrT0Z1U8dOPxan6E7gRnNLXzx8MP2lVuHi0nxptiYkKmpIMKT/ANNFHT/eHFfQUFzFcxJLC6yROAyuhyrA9CDXi1qE6MuWaPTpVY1FeJLSGimySLGpZyAoGSSelYNpK7NRSeDzWPq3ii000mMN50w/gTt9TWFr3ix7gtb2DFIujS92+lc0ckkkk5r4bOOLFTbo4PV/zdPke5gspc0p1tF2NTUPEmoagSGl8qM/wR8D86yzyST19aTFLXwmJxVbES560nJ+Z9BSowpq0FYKKsWWn3eoNttoGk9x0H41vWvge4lANxcpF7Ku4/0rpwmUYzF60aba77L72ZVsZRpaTkczSV2yeA7QD5rqZj7ACkk8B2pHyXcyn3ANep/qnmNr8q+9HL/bGHvu/uOLpK6S68EXcQJt50n9iNprCurO5sZDHcQtG3v3rycXleKwmtem0u/T7zqo4ujW/hyuQglTuBII6Eda2NO8VahYEK7/AGiL+6/JH0NY9FY4XG18NLmoyaZdWhTqq01c9G0nxDaaqNqP5cveN+D+HrWqDmvJVZkYMrFWHII6ius8P+LSWW11Bhk8LMf5H/Gvv8m4rjXao4vSXR9H69j5/G5S6d50dV2OvopAwIBHINLX2p4oUUUUAFFFFABXjXws/wCS7fFb/e0//wBAkr2WvGvhZ/yXb4rf72n/APoElAHstFFFABRRRQB41+zF/wAi94s/7Ga9/wDZa9lrxr9mP/kXvFf/AGM17/7LXstABRRRQAhr5F/ae/5Kcf8Arwh/m1fXRr5F/ae/5Kcf+vCH+bV6OV/x/kzjx38I8looor6M8YF+8PrX3F8HOfhh4b/68U/rXw6PvD619xfBz/kmHhr/AK8Y68nNv4cfU78v+N+h2WPajHtS0V4J6wmPaobiytrxdtzbwzL/AHZEDD9anooFY838ZfAfwd4sgkMemx6VeEErcWSiPn3UfKfyz718r+PvAWq/D3XX0vU0Vgw3wTp9yZM9R7+or7vNeUftH+GYdb+HlzqHlA3WlutxG+OQpIVx9MHP4V6WBxk4TUJO6ZxYrDRlFyS1R8hUUUV9EeQFeyfsveJZNM8bzaK7nyNTgbC548xAWB/753V43XZ/Bqd7f4o+G3Q4Juwn4MCp/QmufFR5qMk+xrQly1Ez7hHSvhb4r/8AJSPEn/X/AC/zr7oXpXwv8V/+Sk+I/wDr/l/nXkZT8cvQ9DMPhRylFFFe+eSOiJEqEcHcK/Q21UC3iAAA2Dp9K/PKL/WJ/vD+dfodbf6iP/cH8q8TN/sfM9PL/tEmPakKhuCAR6EU6ivGPTsZl/4b0XU0KXukafdKeolt0bP5iuJ1/wDZ+8Ba6rldJ/s6U5xJYt5eP+A8r+lek0VpCrOGsXYiVOMt0fKnjf8AZi17RI5Lvw7dLrFsuT5DjZcAf+gt+GK8ZubWeyne3uYZIJozteORSrKfQg1+h+M15/8AFH4PaN8RLF5diWerxr+5vEHJ9FcfxL+o7V6eGzRp8tXbucNbAp60z4sorR8QeH9R8L6vcaTqtu0F3bttZT0PoQe4PUGs6vcTTV0eW01owr1/4JfGq58HXkWha3O82hyttR2JJtGPcf7HqO3UV5BSVnWoxqx5ZIunUlTfNE/RGKeOaFZonDxuNysDkEeoNcV4o8QteStZW7HyEOGYfxn/AAry/wCB/wAQNWvfBl1odysjpZOsdvck9I2ySme5Hb2Ndd3r8Y4yzWVCo8vpPX7T/T/M+8yTCqrBYma9A6UUUV+dH0wZrovD3hdr8LdXYK255VOhf/61VPDWjnVbzdIP9Hi5b/aPpXoUSqiBVAAHAA7V9pwzkEcT/tWIXu9F38/Q8TNMwdP9zT36jLe2jtoxHDGqIBwAMVLilor9HjBRSjFWR823fVhQaKKoQmPaoLuygvYTFPEsinsR0qxRUThGacZK6Y02ndHnviDw5JpLGaEl7Ynqeq+x/wAaxc16vPBHcRtHIoZGGCD0Neca5pLaRfNCMmJvmjb1FfmfEuQrCP6xQXuPddn/AJH0+WY91l7Op8X5mfRRRXyJ7B1XhTxCQ62F25IPETnt7GuxBBryQEqQynBByD6V6F4a1f8AtOxG8gzx/K/v6Gv0bhTOnWX1Su9Vs+67HzWbYJQftoLR7m1RQKK+3PECiiigArxv4Wf8l2+K3+9p/wD6BJXsleNfCz/ku3xW/wB7T/8A0CSgD2WiiigAooooA8a/Zj/5F7xX/wBjNe/+y17LXjX7Mf8AyL3iv/sZr3/2WvZaACiiigBDXyL+09/yU4/9eEP82r66NfIv7T3/ACU4/wDXhD/Nq9HK/wCP8mceO/hHktFFFfRnjAPvD619xfBz/kmHhr/rxjr4dH3h9a+4vg5/yTDw1/14x/1rys2/hx9Tvy/436HZ0UUV4B6wUUUlAAa4n4z3Udp8MPETykAPaGMZ9WIUfqa7YmvnH9pn4lW13FH4N0ydZSkgmvnQ5CkZ2x/nyfoK6MJSdSrFIwxE1Cm2z55ooor6w8EK7/4Daa2p/FXQwFLJbvJcPjsERiD/AN9bR+NcBX0x+y54Dl0+xu/Fd7EUe9XyLUMOfLB+Z/xI49hXJjaqp0ZPvob4aDnUSR72vAFfC/xX/wCSk+I/+v8Al/nX3Tivhb4r/wDJSPEn/X/L/OvLyn+JL0O7MPhRylFFFe+eSOi/1if7w/nX6HW3+oj/ANwfyr88Yv8AWJ/vD+dfodbf6iP/AHB/KvEzfeHzPTy77RLRRRXjHphRRRQAUY4oooA8d/aJ+HEfifw22vWUP/E00tC52D5pof4lPqQOR+NfJdfonLCkyMkihlYFSD0INfCPxH8Nf8Ij431fR1UrFBcMYf8Arm3zL+hx+Fe5lVdtOk+mx5WPpWamjm6FUuwVQSxOAB3PpRXS/DjSRrHjLToHUGON/OcHphef5gV34zExw1CdeW0U39xyUKTq1I011dj3fwT4eTwz4bs7AKPNC+ZMwHLO3J/w+grdoFFfy/i8TPE1p16j1k238z9bo0o0qapx2SCkpauaLa/bNVtoSMqXyR7DmooUnVqRpx3bS+8qpNQi5Pod54e04abpkUZUB2G9z7mtMUAcUtfuOGoRoUo0obJWPhak3OTm92FFFFbkBRRRQAUUUUAFYPi3TvtmltKq/vIPnGPTvW9UcsYkiZG5VgQfpXJjsLHE0J0ZbNGtGq6VRTXQ8nHSipbuA211NCeqOV/Woq/D5wcJOL3R91FqSTQVq+GdQ+warHk/u5fkYfXoayqASrAjORW2ExMsPWjWhvF3M61JVIOD6nrY6UtU9Kuvtmn28/d0Gfr3q4K/caVRVIKcdmrnw0ouLcX0CiiitCQrxr4Wf8l2+K3+9p//AKBJXsteN/Cz/ku3xW/3tP8A/QJKAPZKKKKACiiigDxr9mP/AJF7xX/2M17/AOy17LXjX7Mf/IveK/8AsZr3/wBlr2WgAooooAQ18i/tPf8AJTj/ANeEP82r66NfIv7T3/JTj/14Q/zavRyv+P8AJnHjv4R5LRRRX0Z4wDgg19FeA/2j/DXhXwfpOiXematLPZWywu8SJtYjuMsDivnWisK+HhWSjM1pVpU3eJ9Uf8NX+Ef+gRrf/fEf/wAXR/w1f4R/6BGt/wDfEf8A8XXyvRXN/ZlDs/vNvrtU+qP+Gr/CP/QI1v8A74j/APi6qXv7WWgKhNl4e1SV+wlkSMfoWr5ioo/syh2/EPrtXueseMf2jvFniWGS009YdFtpAVJtyWmIP+2en4AV5Q7tK7O7MzMclmOST6k0lFddKjCmrQVjnnUlN3kwozzRVjTtQudKvYr2zk8qeE7kfaGwfoQRWj8iD1n4R/AXUfFdzBq/iGCWx0ZSHWJxtkuvYDqF9Sfwr6ttLSCwtora2iSKGJQiRoMBVAwAK+U/DP7Tvi3SnRNYhtNYgHDEoIpMexUY/SvdvAHxk8MeP9sFpd/ZNQxzZXRCuT/s9m/Cvn8fDESfNNaeR6+EnRStF6ne18K/Ff8A5KT4j/6/5f51905HrXwt8V/+Sk+I/wDr/l/nVZT/ABJehOYfAjlKKKK988kdF/rE/wB4fzr9Drb/AFEf+4P5V+eMX+sT/eH86/Q62/1Ef+4P5V4mb7w+Z6eXfaJaKKK8Y9MKKKKACiiigBK+U/2qNLFp45sb9VAF5ZDcR3ZGYfyIr6sr5v8A2tYh9p8Oy4+bZOufxSu7LpWro5Mar0mfPdemfAqzEuu6hdEZ8m2CL7bm/wDsTXmdev8AwEQeTq79y0Q/RqnjOo4ZPXa6pL72jPIoqWOp3/rQ9aooor+dj9PCt7wXF5mrliP9XGx/PArBrpvAqg3tyfSMfzr2OH4KWYUk+5w5i7YefodtRRRX7KfGhRRRQAUUUUAFFFFABSEUtFAHnHimEQ63cAfxEN+YrJre8aADWyfWNf61hV+KZxDkx1WK/mZ9tgpc1CD8kFFFFeadR3vg2YyaOFPWN2X+tbwrmPArZsbhfSX+grqBX7NkNTny+jJ9vy0PisfHlxE15hRRRXrnIFeNfCz/AJLt8Vv97T//AECSvZa8a+Fn/Jdvit/vaf8A+gSUAey0UUUAFFFFAHjX7Mf/ACL3iv8A7Ga9/wDZa9lrxr9mP/kXvFf/AGM17/7LXstABRRRQAlfIv7T3/JTj/14Q/zavro18i/tPf8AJTj/ANeEP82r0cr/AI/yZx47+EeS0UUV9GeMHWu40b4J+PPEGl22qabofn2dygkik+1QruU9DhnBrh1+8PrX3F8Gx/xa/wANf9eMdcOPxMqEFKHU6sLRVWTUj5i/4Z6+Jf8A0Lg/8Dbf/wCLo/4Z6+Jf/QuD/wADbf8A+Lr7PxS15f8Aatbsjt+oU+7Pi/8A4Z6+Jf8A0Lg/8Dbf/wCLo/4Z6+Jf/QuD/wADbf8A+Lr7QxRij+1a3ZB9Qp92fFkn7P8A8SYl3N4bOPa7gJ/R6wNa+HHi/wAPoZNS8O6jBGvWTyt6D/gS5FfeOBSMoIPHX9auObVVukJ5fDoz87KK+w/if8C9C8bWc13p9vDp2tKpZJ4l2pMfSQDrn1618i6ppl3o2o3Om30LQ3VrI0UqN/CwODXq4bFwrrTc4K+HlSepWp8M8ttMk0MjxSodyujEMp9QRTKK6rdzA+ofgT8bX8TMnhrxHODqar/o1y3H2kD+Fv8Ab/n9a8J+K/8AyUjxJ/1/y/zrmrO8n0+7hvLWVoriBxJHIpwVYHINW/Eety+I9dvdXmQJLeSGV1HTcQM/rXJSwqpVXOOzN513Omoy3RnUUUV1mA6L/WJ/vD+dfodbf6iP/cH8q/PGL/WJ/vD+dfodbf6iP/cH8q8TN94fM9LLvtEtFFFeMemFFFFABRRRQAlfNn7WtwDqPh63z8whmkP4soH8jX0pXyJ+01rI1L4jfY0YldPtY4SM9GJZz/6EK78tjeun2OTGytSPJa9c+Akw/wCJvDnn90/4fMK8jr0X4H3/ANn8UXNqTxc2xwP9pSD/ACzS4wourk9eK6K/3NMyySahjabfc90ooor+dD9QCul8Cvi+uF9YwfyP/wBeuara8ITCLWUUn/WIy/1/pXr5DUUMwpSff8zjzCPNh5ryPQqKKK/Zj4sKKKKACiiigAooooAKKKaelAHA+Mm3a44/uoo/rWHWl4jn+0azdNnOG2/lxWbX4lm1RVMbVmusn+Z9vg48tCC8kFFFGa886TtfAyY0+dv70v8AICunFYnhGDydFiOMGQs/61tCv2jI6bp4CjF9vz1PicbLmrzfmLRRRXqnKFeNfCz/AJLt8Vv97T//AECSvZa8a+Fn/Jdvit/vaf8A+gSUAey0UUUAFFFFAHjX7MX/ACL3iz/sZr3/ANlr2WvGv2Y/+Re8V/8AYzXv/stey0AFFFFACGvkX9p7/kpx/wCvCH+bV9dGvkX9p7/kpx/68If5tXo5X/H+TOPHfwjyWiiivozxgH3h9a+4vg5/yTDw1/14x/1r4dH3h9a+4vg5/wAkw8Nf9eMdeVm38OPqd+X/ABv0OzooorwD1gooooAKSlooATFfKv7U3h6HTvGNjq0CBRqNuRLjvIhxn8iPyr6rzXzb+1rcRm78PWwI8xVnkI74JUD+Rruy6TVdWOTGpOk7nz5RRRX0x4oUUUUAFFFFADov9Yn+8P51+h1t/qI/9wfyr88Yv9Yn+8P51+h1t/qI/wDcH8q8TN/sfM9LLvtEtFFFeMemFFFFABRRmkJ4oAp6xqttomm3Wo3brHb20TSyMeAABmvgnxNrk3iXxBqGsT5El7O8xB7AngfgMD8K9y/aT+KUV0D4M0idXVWDahIhyCRgiLP6n8K+e+/f8a+gyzD8kHUlu/yPIx1bmlyLoFbHg7WP7C8TadqBYhI5gJD/ALB4P6GsekruxFGNelKlPaSafzOSlUdOamt07n1yrBlDA5BGQaWuO+FviZfEPhiFJH3Xdl+4myeSB91vxH6iuxr+YMxwU8FiZ4apvFtf8H5n61hcRGvSjVjs0FT2FybK9guB/wAs3BP071BSVzUqjpzU47p3NpxUk4vqeto4dFZTkEZBp1YPhHUxe6cIXP72D5T7jsa3RzX7hgcVHFUIVobNHw1ak6U3B9BaKKK6jIKKKKACiiigAqC8uFtbWWdzhY1LH8BU9ct401LybRbKNhvlOW9lH+NcGZ4yOEw060ui09ehvhqLrVYwXU46WQzSvI3V2JP402gUV+JSk5Ntn3CVlZBToomnlSJRlnYKB9aaa3/B2mm6v/tTrmODkZ7t2rry/ByxeIhQj1f4dTHE1lRpym+h21nbi1tYYV6RoFqfpQOlFft8IKEVFbI+Hbu7sKKKKoQV418LP+S7fFb/AHtP/wDQJK9lrxv4Wf8AJdvit/vaf/6BJQB7JRRRQAUUUUAeNfsx/wDIveK/+xmvf/Za9lrxr9mP/kXvFf8A2M17/wCy17LQAUUUUAIa+Rf2nv8Akpx/68If5tX10a+Rf2nv+SnH/rwh/m1ejlf8f5M48d/CPJaKKK+jPGAfeH1r7i+Dn/JMPDX/AF4x/wBa+HRwR9a+rvhn8ZfAmheAtD0zUfEEdvd21okcsZglO1h2yFxXl5pCUoRUVfU7sDJRk7s9norz7/hffw2/6GeH/wAB5v8A4ij/AIX38Nv+hnh/8B5v/iK8T2FX+V/cen7aHdHoNFeff8L7+G3/AEM8X/gPN/8AEUf8L7+G3/Qzxf8AgPN/8RR7Cr/K/uD20O6PQaK89f4+fDhFLDxJG2Owt5s/+gVzuuftQeC7CNhp0WoanLj5QkXlrn3Lf4GqjhastFFidemt5I9dvLqGyt5Lm4lSKGJS7u5wFA5JJr4o+MXjlfHvje61C2JNjAPs1rn+JFJ+b23Ek/lVz4ifG3xH8QEaycpp2lk/8esBP7wf7bdW+nArzyvZwGBdF889zzMViVU92OwUUUV6hxBRWn4Y8O3vizXbPRtPjLz3UgQEfwDux9gOc1Z8caPB4f8AF2raTbZ8mzuGhTPUheM1POubk6j5Xbm6GHRRRVCHRf6xP94fzr9Drb/UR/7g/lX54xkCRSTgAjJr7Pg+PPw4SGMN4liBCgY+zzen+5Xj5rTlLl5Vfc9DATjHm5meiUV59/wvv4bf9DPF/wCA83/xFMk+P/w3jGR4jR/922m/+Iryfq9X+V/cej7aH8yPRKK8l1H9prwFaKTBLqN4w7Q2xGfxYgVw/iD9rCaRXj0Hw+keQQJb2Tdj/gC/41pDBV57RM54qlHqfRlzcw2kDzzyxxRIMs7sAqj3Jr5/+LP7RkMcM+i+DZRLKwKS6iPuoO4j9T/tdK8W8W/EnxT42c/2xqs0kBPFtGdkI/4CP65rma9TDZYoPmq6s4a2NctIaIV5HldpJHZ3YkszHJJ7k0lFFescAU6OKSaRYokZ5HIVVUZLE9AKW3t5rudILeJ5ZpGCoiDLMT2A7mvp74IfAn/hHWi8R+JoVbU8bra0bBFt/tN/t/y+tc2JxMKEby3NaNGVWVkafwq+D58LeCma8ULrd9iaX/pljO2P8jz7mp5I2ikaNxtdSQQe1esAcYrmvFHhs3gN5aL+/A+dB/H/APXr8m4tyieNvjKSvNbruv8AgH2uUYuOHSoS+HocVRRgjgggjgjHSivzDbc+qTLmk6lJpV6twnI6Ov8AeFekWV3De2yTwOGRxmvK60NI1u50eXMZ3xMfmjPQ/wD16+o4dz76jL2Nb+G/wPLzHL/brnh8S/E9MorK0zxBY6mo8uUJJjmN+CK0wQelfp1DE0q8FOlJNeR8vOnKD5ZKzHUUUHityAoNNLAVkat4lstNQqH86bsiHv7mufEYujh4e0rSSRpTpSqS5YK7Lmp6lDpds08x4HRR1Y+grze+vZdQu5LiY/O56dgPSpNU1W51afzZ24/hQdFHtVSvy3iDPXmE+SnpTW3n5n1OX4D6vHml8TCiinRxvK6xxqWdjgAd6+dSbdkek3ZXY63t5LudIIlLO5wBXpOkabHpllHbpyRyzep7ms/w14eGlxiecA3Ljn/YHoK36/UeGckeDp+3rL35fgv8z5XM8d7eXJD4V+IUUUV9WeUFFFFABXjXws/5Lt8Vv97T/wD0CSvZa8a+Fn/Jdvit/vaf/wCgSUAey0UUUAFBoooA8a/Zj/5F7xX/ANjNe/8Astey141+zF/yL3iv/sZr3/2WvZaAEpaKKAENfIv7T3/JTj/14Q/zavro18q/tH+HtY1T4jmex0q+uovsUK74YGdc5bjIFehljSr69mceOV6eh4rRWx/whviT/oAat/4Byf4Uf8Ib4k/6AGrf+Acn+FfQ+0h3R4/JLsY9GK2P+EN8Sf8AQA1b/wAA5P8ACj/hDfEn/QA1b/wDk/wo9pHuHI+xj4oxWx/whviT/oAat/4Byf4Uf8Ib4k/6AGrf+Acn+FHtI90HI+xj4oxWx/whviT/AKAGrf8AgHJ/hR/whviT/oAat/4Byf4Ue0h3DkfYxsD0pfatj/hDfEn/AEANW/8AAOT/AApy+CvE7HC+HtWJP/TpJ/hR7SPcOWXYxaK6i0+F/ja9YLB4W1Zif70BUfmcV0mk/s6fEHUyDLpsGnof4rq4Xj8FyaiWIpR1ckWqM3sjzPNaXh/w1q/irUY9O0axmvLhz92NeFHqx6Ae5r6B8MfsoWULpN4j1qS5wQTb2a+Wp9ix5P5CvafDfhDRPCVmLPRNNt7KIfe8tMM59Wbqx+tcFfNKcdKerOqlgZv49Djfg/8ACCz+HFg1zdFLrWrlQJpwDtjX+4ntnv1NfMHxX/5KT4k/6/5f5190kV8VfE/wrr138QvEE8Gi6lLFJeyMjpbOysCeoIFYZdWc6spzetjXGU1GnGMUcBRWx/whviT/AKAGrf8AgHJ/hR/whviT/oAat/4Byf4V7PtI9zzeSXYx6MVsf8Ib4k/6AGrf+Acn+FH/AAhviT/oAat/4Byf4Ue0j3Qckuxj4orY/wCEN8Sf9ADVv/AOT/Cj/hDfEv8A0L+rf+Acn+FHtI9w5H2MccdKK3ovAPi2c4i8Nau2f+nV/wDCtSz+DnxAviBD4V1AZ/56qIx/48RSdaC3khqnJ7I42ivVtL/Zp8e35X7TBY6ep6me4DEfgma7jQf2TIVKvrviJ5PWOyi2j/vps/yrnnjqEftGscLVlsj5xGScCu78EfBfxb44kjkt7B7GxY83l2pRMeqjq34ce9fUfhf4M+CfCbLLZaNDNcL0uLsedJn1BbgfgBXaqgQALwB2rgrZr0pL5s7KeA6zZ598OPgv4e+HqLcRRm/1QjDXs45Hsi9FH6+9ehYA7UtFeTOpKb5pu7PQhBRVooKQgdxS0dago57XvC8WpZnt8RXHf0f61xV3Z3FjMYriNo2Hr/jXqpGRiq95p9tfxeXcRLIvbI5FfK5xwxSxjdWj7s/wZ6mDzSdH3Z6xPK6Wuq1HwSVJexmBH9yT/Gueu9MvLEkXFtIg9cZH51+f43J8XhHarB27rVH0VDG0ay9yRWHByOCO9aFrr+p2YCxXcm0dmww/Ws/NGa4qOIq0XelJxfk7G06UKitNJm8njXVFGG8lvcrSSeNNVcYUwp9ErCpK7/7cx9re2f3mH1DD78iL11reo3oImu5GHovyj8hVI0lGa8+rXqVnepJt+bubwpwgrRVhaKuWej398f3FtIR/eIwPzNdFpvghVIe/m3n/AJ5p0/E16OCyTGYt/u4O3d6I56+Oo0filqc1YabdalKI7aJm9W6AfU13Oh+HLfSl8x/3twRy57ewrTtrOC0jEcEaxoOyjFTAV+g5Pw1RwTVSp70/wXp/mfPYzM51/djpEMUtFFfTHmBRRRQAUUUUAFeNfCz/AJLt8Vv97T//AECSvZa8a+Fn/Jdvit/vaf8A+gSUAey0UUUAFFFFAHjX7MX/ACL3iv8A7Ga9/wDZa9lrxr9mL/kXvFf/AGM17/7LXstABRRRQAhpMDOcU6igBMUYpaKAExRilooATFGKWigBMUYpaKAExRilooAaVHoKXaMdKWigBAMUtFFAAelNwPSnUUAJijFLRQAmKMUtFACYoxS0UAJgUgUDoAKdRQAmPagClooAKKKKACiiigAooooAKKKKAExSFQwwQCPSnUUmr7gZ9zoenXXMlnET6gYP6VQl8F6Y/wB1ZY/o/wDjW/RXDWyvCVv4lKL+SN4YmtD4ZNfM5k+BbI9Li4H5f4UDwLZDrPcH8R/hXTUVzf6v5fv7FGv9oYj+dmDF4N0uM/NHJJ/vOf6VoW2jWFpzDaRKfXbk/nV6iuqjluFo606aXyMZ4irP4pN/MaFA4AxRinUV22MQFFFFMAooooAKKKKACiiigArxr4Wf8l2+K3+9p/8A6BJXsteNfCz/AJLt8Vv97T//AECSgD2WiiigAooooA8a/Zi/5F7xX/2M17/7LXsteNfsxf8AIveK/wDsZr3/ANlr2WgAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK8b+Fn/ACXb4rf72n/+gSV7JXjXws/5Lt8Vv97T/wD0CSgD2WiiigAooooA8a/Zi/5F7xX/ANjNe/8Astey141+zF/yL3iv/sZr3/2WvZaACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArxv4Wf8l2+K3+9p/8A6BJXsleNfCz/AJLt8Vv97T//AECSgD2WiiigAooooA8b/Zi/5F7xZ/2M17/7LXsleNfsxf8AIveLP+xmvf8A2WvZaACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArxv4Wf8AJdvit/vaf/6BJXsleN/Cz/ku3xW/3tP/APQJKAPZKKKKACiiigDxr9mL/kXvFf8A2M17/wCy17LXjX7MX/IveLP+xmvf/Za9loAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvG/hZ/yXb4rf72n/wDoEleyV438LP8Aku3xW/3tP/8AQJKAPZKKKKACiiigDxr9mL/kXvFf/YzXv/stey141+zF/wAi94r/AOxmvf8A2WvZaACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArxr4Wf8AJdvit/vaf/6BJXsteN/Cz/ku3xW/3tP/APQJKAPZKKKKACiiigDxr9mL/kXvFf8A2M17/wCy17LXjX7MX/IveLP+xmvf/Za9loAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvG/hZ/yXb4rf72n/wDoEleyV438LP8Aku3xW/3tP/8AQJKAPZKKKKACiiigDxr9mL/kXvFf/YzXv/stey141+zF/wAi94r/AOxmvf8A2WvZaACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigArxr4Wf8AJdvit/vaf/6BJXsteN/Cz/ku3xW/3tP/APQJKAPZKKKKACiiigDxr9mL/kXvFf8A2M17/wCy17LXjX7MX/IveLP+xmvf/Za9loAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvGvhZ/yXb4rf72n/wDoEley1438LP8Aku3xW/3tP/8AQJKAPZKKKKACiiigDxr9mL/kXvFf/YzXv/stey141+zF/wAi94s/7Ga9/wDZa9loAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvGvhZ/wAl2+K3+9p//oEley1438LP+S7fFb/e0/8A9AkoA9kooooAKKKDzQB8w/Cb4waH8MrbxLpOuabrzXE+vXdyhtbEyIUJABzkehru/wDhqfwT/wBArxV/4LD/APFV7FgUtAHjn/DU3gn/AKBXir/wWH/4qj/hqfwT/wBArxV/4LD/APFV7HRQB45/w1P4J/6BXir/AMFh/wDiqP8AhqfwT/0CvFX/AILD/wDFV7HRQB45/wANTeCf+gX4q/8ABYf/AIqj/hqfwT/0CvFX/gsP/wAVXsdFAHjn/DU3gn/oFeKv/BYf/iqP+GpvBP8A0CvFX/gsP/xVex0UAeOf8NTeCf8AoFeKv/BYf/iqP+Gp/BP/AECvFX/gsP8A8VXsdFAHjn/DU3gn/oF+Kv8AwWH/AOKo/wCGp/BP/QK8Vf8AgsP/AMVXsdFAHjn/AA1P4J/6BXir/wAFh/8AiqP+GpvBP/QL8Vf+Cw//ABVex0UAeOf8NT+Cf+gV4q/8Fh/+Ko/4am8E/wDQK8Vf+Cw//FV7HRQB45/w1N4J/wCgV4q/8Fh/+Ko/4an8E/8AQK8Vf+Cw/wDxVex0UAeOf8NT+Cf+gV4q/wDBYf8A4qj/AIam8E/9ArxV/wCCw/8AxVex0UAeOf8ADU3gn/oFeKv/AAWH/wCKo/4am8E/9ArxV/4LD/8AFV7HRQB45/w1P4J/6Bfir/wWH/4qj/hqfwT/ANArxV/4LD/8VXsdFAHjn/DU/gn/AKBXir/wWH/4qj/hqbwT/wBArxV/4LD/APFV7HRQB45/w1N4J/6BXir/AMFh/wDiqP8AhqbwT/0CvFX/AILD/wDFV7HRQB45/wANT+Cf+gV4q/8ABYf/AIqj/hqfwT/0CvFX/gsP/wAVXsdFAHjn/DU/gn/oFeKv/BYf/iqP+Gp/BP8A0CvFX/gsP/xVex0UAeOf8NTeCf8AoFeKv/BYf/iqP+Gp/BP/AECvFX/gsP8A8VXsdFAHjn/DU3gn/oFeKv8AwWH/AOKo/wCGp/BP/QK8Vf8AgsP/AMVXsdFAHjn/AA1P4J/6BXir/wAFh/8AiqP+Gp/BP/QK8Vf+Cw//ABVex0UAeOf8NT+Cf+gX4q/8Fh/+Ko/4an8E/wDQL8Vf+Cw//FV7HRQB45/w1P4J/wCgV4q/8Fh/+Ko/4an8Ff8AQL8Vf+Cw/wDxVex0UAeOf8NT+Cf+gV4q/wDBYf8A4qj/AIan8E/9AvxV/wCCw/8AxVex0UAeOf8ADU/gn/oFeKv/AAWH/wCKo/4an8E/9AvxV/4LD/8AFV7HRQB45/w1P4J/6Bfir/wWH/4qj/hqfwT/ANAvxV/4LD/8VXsdFAHjn/DU/gn/AKBXir/wWH/4qj/hqfwT/wBAvxV/4LD/APFV7HRQB45/w1P4J/6BXir/AMFh/wDiqP8AhqfwT/0C/FX/AILD/wDFV7HRQB45/wANT+Cf+gX4q/8ABYf/AIqj/hqfwT/0C/FX/gsP/wAVXsdFAHjn/DU/gn/oF+Kv/BYf/iqP+Gp/BP8A0CvFX/gsP/xVex0UAeOf8NT+Cf8AoFeKv/BYf/iqzPgNrsPir4pfEfxDZ2t7BZah9haH7XCYnIVZAeDXu1JtXduxz60ALRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAH//Z' Alt='bdo.png' style='float:left' width='120' height='120' hspace=10></td><td class='transparent'>
<H1>Windows Baseline Configuration Report v2.0 - $env:COMPUTERNAME</H1></td>
</tr>
</table>
"@

#Sytem Information
$html_SysInfo = Get-SystemInfo | ConvertTo-Html -Fragment -As List -PreContent "<h2>System Information</h2> <hr>" 
$Html_OS = Get-OSVersionInfo | ConvertTo-Html -Fragment

#ILO
$Html_ILO = Get-ILO 

#Disks Information
$html_DiskInfo = Get-DriveInfo | ConvertTo-Html -Fragment -PreContent "<h2>Disks Information</h2> <hr>"
$html_DiskInfo_CLOUD = Get-DriveInfo_CLOUD | ConvertTo-Html -Fragment -PreContent "<h2>Disk Information</h2> <hr>"

#Folders Information   ------ removed
$Html_folders = Get-FolderInformation | ConvertTo-Html -Fragment -PreContent "<h2>Folders Information</h2> <hr>"
$Html_folders_CLOUD = Get-FolderInformation_CLOUD | ConvertTo-Html -Fragment -PreContent "<h2>Folders Information</h2> <hr>"

#Local User Information
$html_LocalUser = Get-LocalUser | ConvertTo-Html -PreContent "<h2>Local User Information</h2> <hr>" -Fragment




#CD-ROM Drive Information
$CDInfo = Get-CDRom
if($CDInfo -ne $null){
            $html_CDRom = $CDInfo | ConvertTo-Html -Fragment -PreContent "<h2>CD-ROM Drive Information</h2> <hr>"
                 }
               else {}




#Services Information
$Html_services = Get-ServiceInfo | ConvertTo-Html -Fragment -PreContent "<h2>Services Information</h2> <hr>"


#Program Information
$Html_programs = Get-ProgramInfo | ConvertTo-Html -Fragment -PreContent "<h2>Programs Information</h2> <hr>"

#region FIREWALL

  #Firewall_DISABLE
$Html_firewall_disable = Firewall_Status_CLOUD | ConvertTo-Html -Fragment -PreContent "<h2>Firewall Status</h2> <hr>"
$Html_firewall_rules = ""
$Html_firewall_remote = ""

 #Firewall_ENABLE
$Html_firewall_enable = Firewall_Status | ConvertTo-Html -Fragment -PreContent "<h2>Firewall Status</h2> <hr>"
$Html_firewall_rules = Get-Firewall_Rules | ConvertTo-Html -Fragment -PreContent "<h4>Firewall Rules Information</h4>"
$Html_firewall_remote = Get-Remote_Desktop_Firewall  | ConvertTo-Html -Fragment -PreContent "<h4>Remote Desktop pre-defined Firewall Rules</h4>"



#endregion Firewall

#Registry Information
$Html_reg = "<h2>Registry Information</h2> <hr> <table-start>"
$Html_reg += Get-RegistryInfo -Registry_hash $hashes_1 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'>Disable USB Storage Devices and Autoplay </th></tr>"
$Html_reg += Get-RegistryInfo -Registry_hash $hashes_2 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> Disable SSL/TLS 1.0/TLS 1.1</th></tr>"
$Html_reg += Get-RegistryInfo -Registry_hash $hashes_3 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> Disable RC4 Ciphers</th></tr>"
$Html_reg += Get-RegistryInfo -Registry_hash $hashes_4 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> Disable IP Source Routing</th></tr>"
$Html_reg += Get-RegistryInfo -Registry_hash $hashes_5 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> DisableStrictNameChecking and DisableLoopbackCheck Settings (Resolves issue when accessing alias names on the local computer)</th></tr>"
$Html_reg += Get-RegistryInfo -Registry_hash $hashes_6 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> DNS Cache TTL</th></tr>"
$Html_reg += Get-hashes_7_result | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> Remote Desktop Access</th></tr>"

$Html_reg = $Html_reg -replace '<table>','' 
$Html_reg = $Html_reg -replace '</table>','' 
$Html_reg = $Html_reg -replace '<table-start>','<table>' 
$Html_reg += "</table>"


#Registry Information  - CLOUD
$Html_reg_CLOUD = "<h2>Registry Information</h2> <hr> <table-start>"
$Html_reg_CLOUD += Get-RegistryInfo -Registry_hash $hashes_2 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> Disable SSL/TLS 1.0/TLS 1.1</th></tr>"
$Html_reg_CLOUD += Get-RegistryInfo -Registry_hash $hashes_3 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> Disable RC4 Ciphers</th></tr>"
$Html_reg_CLOUD += Get-RegistryInfo -Registry_hash $hashes_4 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> Disable IP Source Routing</th></tr>"
$Html_reg_CLOUD += Get-RegistryInfo -Registry_hash $hashes_5 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> DisableStrictNameChecking and DisableLoopbackCheck Settings (Resolves issue when accessing alias names on the local computer)</th></tr>"
$Html_reg_CLOUD += Get-RegistryInfo -Registry_hash $hashes_6 | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> DNS Cache TTL</th></tr>"
$Html_reg_CLOUD += Get-hashes_7_result | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> <br> Remote Desktop Access</th></tr>"



$Html_reg_CLOUD = $Html_reg_CLOUD -replace '<table>','' 
$Html_reg_CLOUD = $Html_reg_CLOUD -replace '</table>','' 
$Html_reg_CLOUD = $Html_reg_CLOUD -replace '<table-start>','<table>' 
$Html_reg_CLOUD += "</table>"


#Other Baseline Configuration Settings
$Html_B_config = "<h2>Other Baseline Configuration Settings</h2> <hr> <table-start>"
$Html_B_config += $PSVersionTable.PSVersion | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'> Powershell Version Information   </th></tr>"
$Html_B_config  = $Html_B_config  -replace '<table>','' 
$Html_B_config  = $Html_B_config  -replace '</table>','' 
$Html_B_config  = $Html_B_config  -replace '<table-start>','<table>' 
$Html_B_config  += "</table>"

#Internet Explorer

$Html_explore = Get-InternetExplorer | ConvertTo-Html -Fragment -PreContent "<h4> &nbsp Internet Explorer Version Information </h4>"

#HP IRS SNMP Information
if(($test=Get-HP) -ne $null) {$Html_HP = Get-HP | ConvertTo-Html -Fragment -PreContent "<h4> &nbsp HP IRS SNMP Information </h4>"} else {}

#Network Connections
$Html_netadapter = Get-NetworkInfo | ConvertTo-Html -Fragment -PreContent "<h4> &nbsp Network Connections </h4>"


#OTHERS BASELINE
$Html_otherbaseline = Get-OthersBaseline | ConvertTo-Html -Fragment -PreContent "<h4> &nbsp Other Baseline </h4>"



#Qualys
$HTML_qualys = "<h2>Qualys Fixes</h2> <hr> <table-start>"
$HTML_qualys += Get-NetBIOS | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'>  NetBIOS over TCP/IP</th></tr>"
$HTML_qualys += Get-RegistryInfo -Registry_hash $Spectre_Meltdown  | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'>  Fix to Spectre/Meltdown </th></tr>"
$HTML_qualys += Get-Netlogon | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'>  Fix to Microsoft Group Policy Remote Code Execution Vulnerability</th></tr>"
$HTML_qualys += Get-RegistryInfo -Registry_hash $SocketHijacking  | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'>  Fix to Windows Registry Setting To Globally Prevent Socket Hijacking Missing </th></tr>"
$HTML_qualys += Get-RegistryInfo -Registry_hash $sweet32  | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'>  TLS Ciphers with 64bit Block Size Vulnerability (Sweet32) </th></tr>"
$HTML_qualys += Get-RegistryInfo -Registry_hash $CacheLogon | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'>  Cached Logon Credential & Null Session </th></tr>"
$HTML_qualys += Get-RegistryInfo -Registry_hash $InternetExplorer | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'>  Internet Explorer Security </th></tr>"
$HTML_qualys += Get-RegistryInfo -Registry_hash $SMBSigning | ConvertTo-Html -Fragment -PreContent "<tr> <th align='left' colspan=3 class='colspan'>  SMB Signing </th></tr>"


$HTML_qualys = $HTML_qualys -replace '<table>','' 
$HTML_qualys = $HTML_qualys -replace '</table>','' 
$HTML_qualys = $HTML_qualys -replace '<table-start>','<table>' 
$HTML_qualys += "</table>"


#region #### consolidate =================================================================================


#old report --------- MY FORMAT
#$Report_FIREWALL_Enable = ConvertTo-HTML -Body "$html_image $html_SysInfo $Html_OS $Html_ILO $html_DiskInfo $Html_folders $html_LocalUser $html_CDRom $Html_services $Html_programs $Html_firewall_enable $Html_firewall_rules $Html_firewall_remote $Html_reg  $Html_B_config $Html_explore $Html_HP $Html_netadapter $Html_otherbaseline $HTML_qualys " -Title "Windows Baseline Report" -Head $head -PostContent "<p class='footer'>Creation Date: $(Get-Date)</p>"
#$Report_FIREWALL_Disable = ConvertTo-HTML -Body "$html_image $html_SysInfo $Html_OS $Html_ILO $html_DiskInfo $Html_folders $html_LocalUser $html_CDRom $Html_services $Html_programs $Html_firewall_disable $Html_reg_CLOUD  $Html_B_config $Html_explore $Html_HP $Html_otherbaseline $HTML_qualys " -Title "Windows Baseline Report" -Head $head -PostContent "<p class='footer'>Creation Date: $(Get-Date)</p>"


#NORMAL
$Report_FIREWALL_Enable = ConvertTo-HTML -Body "$html_image $html_SysInfo $Html_OS $html_DiskInfo $Html_folders $html_LocalUser $html_CDRom $Html_services $Html_programs $Html_firewall_enable $Html_firewall_rules $Html_firewall_remote $Html_reg  $Html_B_config $Html_explore $Html_HP $Html_netadapter $Html_otherbaseline $HTML_qualys " -Title "Windows Baseline Report" -Head $head -PostContent "<p class='footer'>Creation Date: $(Get-Date)</p>"


#CLOUD / VPC
$Report_FIREWALL_Disable = ConvertTo-HTML -Body "$html_image $html_SysInfo $Html_OS  $html_DiskInfo_CLOUD $Html_folders_CLOUD $html_LocalUser $html_CDRom_CLOUD $Html_services $Html_programs $Html_firewall_disable $Html_reg_CLOUD  $Html_B_config $Html_explore $Html_HP $Html_otherbaseline $HTML_qualys " -Title "Windows Baseline Report" -Head $head -PostContent "<p class='footer'>Creation Date: $(Get-Date)</p>"


#endregion consolidate



################## REPORT ###########

#region REPORT

 #check Hostname
 if (($env:COMPUTERNAME -like "SW2*") -or ($env:COMPUTERNAME -like "SW3*") -or ($env:COMPUTERNAME -like "SW4*") -or ($env:COMPUTERNAME-like "SW5*") ) {
                  
               #Firewall_DISABLE
               $Report =$Report_FIREWALL_Disable

    } 


    else{
        #region Check if VM or Pysical 
        $ComputerSystemInfo = Get-WmiObject -Class Win32_ComputerSystem
        $MachineModel = $ComputerSystemInfo.Model
        switch -wildcard ($MachineModel) { 

            # Check for VMware Machine Type 
            "*VMware*" { 
               #Firewall_DISABLE
               $Report =$Report_FIREWALL_Disable
                Break  } 

            # Check for Oracle VM Machine Type 
            "VirtualBox" {
                #Firewall_ENABLE
               $Report = $Report_FIREWALL_Enable 
                Break } 
            default { 

                switch ($ComputerSystemInfo.Manufacturer) {

                    # Check for Xen VM Machine Type
                    "Xen" { 
                            #Firewall_ENABLE
                            $Report = $Report_FIREWALL_Enable 
                            Break }

                    # Check for KVM VM Machine Type
                    "QEMU" { 
                            #Firewall_ENABLE
                            $Report = $Report_FIREWALL_Enable 
                            Break }
                    # Check for Hyper-V Machine Type 
                    "Microsoft Corporation" { 
                        if (get-service WindowsAzureGuestAgent -ErrorAction SilentlyContinue) {
                            #Firewall_DISABLE
                            $Report = $Report_FIREWALL_Disable
                        }
                        else {
                             #Firewall_ENABLE
                            $Report = $Report_FIREWALL_Enable 
                        }
                        Break
                    }
                    # Check for Google Cloud Platform
                    "Google" {
                        #Firewall_DISABLE
                            $Report = $Report_FIREWALL_Disable
                            Break
                            }

                    # Check for AWS Cloud Platform
                    default { 
                        if ((((Get-WmiObject -query "select uuid from Win32_ComputerSystemProduct" | Select-Object UUID).UUID).substring(0, 3) ) -match "EC2") {
                            #Firewall_DISABLE
                            $Report = $Report_FIREWALL_Disable
                            }
                        # Otherwise it is a physical Box 
                        else {
                             #Firewall_ENABLE
                            $Report = $Report_FIREWALL_Enable 
                            }
                    } 
                } #end switch
                
                
                                 
            } 
        }

        #endregion  Check if VM or Pysical 
        }


#Modify last HTML column
$Report = $Report -replace '<td>Failed</td>','<td class="alert" >Failed</td>' 
$Report = $Report -replace '<td>Passed</td>','<td class="passed" >Passed</td>'

#endregion report


Write-host "$server Completed" 


          
#endregion CHECK BASELINE ==================================================================END CHECK BASELINE =========================================================================#


       New-Object PSObject -property @{
                    Server_Name=$env:COMPUTERNAME
                    Report=$Report
                    }
       

                        
    
    
    

    

            
        
            #Create LOG / Report


                        #check $logfiles existence
                        $year = (get-date).Year
                        $server=$Output.Server_Name
                        $logfile = "$PathDestination\$env:ComputerName - $year Windows Baseline Report.htm"
                        If (Test-Path $logfile) {Remove-Item $logfile}   ELSE {}
                
                        ##### Create Report
                        $Report | Out-File $logfile    
   

                        Write-host "$env:ComputerName Completed" 

                
                start $PathDestination




       
 
  
 #apply