﻿#Script that transfer Dll files to T4S server.
#Author : Dion Macaraeg

Add-Type -AssemblyName System.DirectoryServices.AccountManagement
Add-Type -AssemblyName System.Windows.Forms


#PREPARATION
$Error.Clear()
$PS = $null

#START OF ELEVATED ACCOUNT {RUN SCRIPT AS ELEVATED ACCOUNT}
$myWindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal=New-Object System.Security.Principal.WindowsPrincipal($myWindowsID)

# Get the security principal for the Administrator role
$adminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator

# Check to see if we are currently running "as Administrator"
if ($myWindowsPrincipal.IsInRole($adminRole))

   {
   # We are running "as Administrator" - so change the title and background color to indicate this
   $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
   #$Host.UI.RawUI.BackgroundColor = 1
   clear-host
   }

else

   {
   # We are not running "as Administrator" - so relaunch as administrator
   # Create a new process object that starts PowerShell
   $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";
   
   # Specify the current script path and name as a parameter
   $newProcess.Arguments = $myInvocation.MyCommand.Definition;
   
   # Indicate that the process should be elevated
   $newProcess.Verb = "runas";
    
   # Start the new process
   [System.Diagnostics.Process]::Start($newProcess);

   # Exit from the current, unelevated, process
   exit
   }

 

# Run your code that needs to be elevated here
"Running on elevated account."
#END OF ELEVATED ACCOUNT


#CREDENTIAL
#$Cred = Get-Credential -Message "Enter username/password :"
#$USER = $Cred.UserName
#$Passwd = $Cred.Password

#END OF PREPARATION


#SCRIPT PROPER - START

function prompt {' '}

$computername = hostname.exe

$Logpath = "c:\sretools\Logs"
$Logpath2 = "\\fs10.cfs.bdo.com.ph\PUBLIC4\ITSC-Standards\NextGenIT\RTP\logs\$computername-RTP-Reports"
$Logpathaws = "\\tsclient\C\temp\D3_RTP\logs\$computername-RTP-Reports"
$Logpathaz = "\\SW40000002\rtp\logs\$computername-RTP-Reports"

New-Item -Path $Logpath -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item -Path $Logpath2 -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item -Path $Logpathaws -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item -Path $Logpathaz -ItemType "directory" -Force -ErrorAction SilentlyContinue

cls
#New-Item -ItemType Directory -Force -Path $Logpath\$ENV:COMPUTERNAME

#Progress parameter
$Progress = @{
    Activity = 'Collecting RTP Data for Report:'
    CurrentOperation = "Loading"
#    Status = 'Collecting data'
    PercentComplete = 0
}

Write-Progress @Progress
$i = 0

    $i++
#    [int]$percentage = ($i / $_.Count)*100
    $Name = $null
    $Name = $file.name
    $progress.CurrentOperation = "$name"
  #  $progress.Status = 'Processing file: '
  #  $progress.PercentComplete = $percentage
  
    Write-Progress @Progress
     
    Start-Sleep -Milliseconds 600


#Write-Host "Mapping drive, please wait..." -ForegroundColor Yellow 
#Write-Host ""
Write-Host "Running RTP Review Diagnostics please wait until its complete......" -ForegroundColor Yellow 


# General Info
$computername = hostname.exe
$FQDN = $DNSCheck.hostname
$IsVirtual=(Get-WmiObject win32_computersystem).manufacturer
$computername = (Get-ComputerInfo).CsDNSHostName
$dname = (Get-WmiObject -Class win32_ComputerSystem).Domain
$osname = (Get-ComputerInfo).OsName
$osversion = (Get-ComputerInfo).OsVersion
$osdate = (Get-ComputerInfo).OsInstallDate
$edition = (Get-ComputerInfo).WindowsEditionId
$processormodel = (Get-ComputerInfo).CsModel
$buildnumber = (Get-ComputerInfo).OsBuildNumber
$architecture = (Get-ComputerInfo).OsArchitecture
$oslanguange = (Get-ComputerInfo).OsLanguage
$processorsystem = (Get-ComputerInfo).CsSystemType
$systemlocale = (Get-ComputerInfo).OsLocale
$timezone = (Get-ComputerInfo).TimeZone
$oslastBoot = (Get-ComputerInfo).OsLastBootUpTime
$osuptime = (Get-ComputerInfo).OsUptime
$date = Get-Date
$hostip = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration | where {$_.DefaultIPGateway -ne $null}).IPAddress | select-object -first 1
$hostgateway = (Get-wmiObject Win32_networkAdapterConfiguration | ?{$_.IPEnabled}).DefaultIPGateway


#NTP Connection
$computername = hostname.exe
$servers = $computername

foreach ($server in $servers){
$ntps = w32tm /query /status | ?{$_ -match 'Stratum:'} | %{($_ -split ":\s\b")[1]}
$ntpssource = w32tm /query /Source
$ntpssync = w32tm /query /status | ?{$_ -match 'Last Successful Sync Time:'} | %{($_ -split ":\s\b")[1]}
#$ntps = w32tm /query /computer:$server /configuration | ?{$_ -match 'ntpserver:'} | %{($_ -split ":\s\b")[1]}
#new-object psobject -property @{
#    Server = $Server
#    NTPSource = $ntps
#    }
}

if($ntps -eq $null){
#echo 'ntp is empty'
$ntpcheckw = "WORKGROUP"
$ntpcheckstatus2 = "NO"
}else{
#echo 'ntp is not empty'
$ntpcheckd = "DOMAIN"
$ntpcheckstatus1 = "YES"
}


$getadapterip = Get-NetConnectionProfile -NetworkCategory 'DomainAuthenticated'
$getadapterip2 = $getadapterip.Name
#$getadapterip2

$getip= Get-NetConnectionProfile -Name $getadapterip2
$activeip = $getip.InterfaceAlias
$getip2 = (Get-NetIPAddress -AddressFamily IPV4 -InterfaceAlias $activeip).IPAddress
$ip = $getip2.split('.')
$count = $ip[3].length

#Check Hostname Vs IP 
$lastTwoCharsOfComputerName = $ENV:COMPUTERNAME.Substring($ENV:COMPUTERNAME.Length - $count)


    #Compare
    #$lastTwoCharsOfComputerName
    #$ip[3]

if($lastTwoCharsOfComputerName -eq $ip[3])
{
   #echo TRUE
   $nameipsame1 = "Passed- Naming Convention is OK"
   
} else {
   #echo FALSE
   $nameipsame2 = "Failed - Naming Convention is NOT OK"
}



# Network info
$networkadapter = Get-WMIObject win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -eq $true } | select-object `ServiceName, Description, @{Name="IPAddress";Expression={$_.ipaddress}} , @{Name="Subnet";Expression={$_.ipsubnet}}, @{Name="IP_Gateway";Expression={$_.DefaultIPGateway}}, MACAddress | ConvertTo-Html
$netadapter = Get-NetAdapter | SELECT Name,InterfaceDescription,ifIndex,Status,MacAddress,LinkSpeed,fullduplex | where status -eq ‘up’ | ConvertTo-Html

Get-NetAdapter | SELECT Name,InterfaceDescription,ifIndex,Status,MacAddress,LinkSpeed,fullduplex | where status -eq ‘up’


#If Condition and Variables - VMWare

If ((Get-ComputerInfo).CsManufacturer -eq "VMware, Inc.") {
#echo TRUE

$vcentercheck = 'Ensure that your VMWAre Server is using the correct DataStore and Type according to its role. Check by logging into the VCenter Console'

#BDO Adapter
#BDO Adapter
$getadaptername = Get-NetConnectionProfile -NetworkCategory 'DomainAuthenticated'
$getadaptername2 = $getadaptername.Name
$getadapter= Get-NetConnectionProfile -Name $getadaptername2
$getadapter2 = $getadapter.InterfaceAlias
#$getadapter2
$getadapter3 = (Get-NetAdapter -Name $getadapter2).InterfaceDescription
$getadapter3

if($getadapter3 -eq 'vmxnet3 Ethernet Adapter') {
   #echo TRUE
   $getadapter4 = "Passed - Adapter detected is vmnext3"
   #$getadapter4
    } 

if($getadapter3 -eq 'vmxnet3 Ethernet Adapter #2') {
    #echo TRUE2
    $getadapter4 = "Passed - Adapter detected is vmnext3"
    }
    
if($getadapter3 -eq 'vmxnet3 Ethernet Adapter #3') {
    #echo TRUE3
    $getadapter4 = "Passed - Adapter detected is vmnext3"
    }    

 if($getadapter3 -eq 'E1000') {
    #echo FALSE
    $getadapter4 = "Failed - adapter s/b vmnext3"
    }        


#Other Adapter
$get2adaptername = Get-NetConnectionProfile -NetworkCategory 'Public'
$get2adaptername2 = $get2adaptername.Name
$get2adapter= Get-NetConnectionProfile -Name $get2adaptername2
$get2adapter2 = $get2adapter.InterfaceAlias
#$getadapter2
$get2adapter3 = (Get-NetAdapter -Name $get2adapter2).InterfaceDescription
#$getadapter3

if($getadapter3 -eq 'vmxnet3 Ethernet Adapter') {
   #echo TRUE
   $get2adapter4 = "Passed - Adapter detected is vmnext3"
   #$getadapter4
    } 

if($getadapter3 -eq 'vmxnet3 Ethernet Adapter #2') {
    #echo TRUE2
    $get2adapter4 = "Passed - Adapter detected is vmnext3"
    }
    
if($getadapter3 -eq 'vmxnet3 Ethernet Adapter #3') {
    #echo TRUE3
    $get2adapter4 = "Passed - Adapter detected is vmnext3"
    }    

 if($getadapter3 -eq 'E1000') {
    #echo FALSE
    $get2adapter4 = "Failed - adapter s/b vmnext3"
    }

} Else {
$nonvmware = 'Passed - VMWare requirement N/A'
$nonevcentercheck = 'Ensure that your AWS/AZURE Instance has assigned zones. . Check by logging into the AWS/AZ Console'
}


if($timezone -like '(UTC+08:00) Kuala Lumpur, Singapore')
    {
#   echo TRUE
   $timezonepass = "Passed"
   
    } else {
#   echo FALSE
   $timezonefail = "Failed - TimeZone s/b (UTC+08:00) Kuala Lumpur, Singapore"
   
    }


#AdminPWD.dll Checking

if (Test-Path "C:\Program Files\LAPS\CSE\AdmPwd.dll") {
   
$adminpwdtrue = "LAPS Enrollment Existing"
    
}
else {

#echo FALSE
$adminpwdfalse = "LAPS Enrollment Missing"
  
}

cls

#Check Disk Labels


$cvolume3 = $null
$cvolume4 = $null
$fvolume3 = $null
$fvolume4 = $null
$gvolume3 = $null
$gvolume4 = $null
$hvolume3 = $null
$hvolume4 = $null
$cvolume3 = $null
$cvolume4 = $null
$fvolume3 = $null
$fvolume4 = $null
$gvolume3 = $null
$gvolume4 = $null
$hvolume3 = $null
$hvolume4 = $null
$ivolume3 = $null
$ivolume4 = $null
$jvolume3 = $null
$jvolume4 = $null



$dbservice = 'SQLSERVERAGENT'
If (Get-Service $dbservice -ErrorAction SilentlyContinue)
{

#   echo "w/ Database"

$driveLetters= (Get-Volume).DriveLetter
#if ($driveLetters -contains "C" -and $driveLetters -contains "F" -and $driveLetters -contains "G" -and $driveLetters -contains "H")
if ($driveLetters -contains "C")
{

#echo 'C, F, G and H Exists'
#run script to check label here
$cvolume = Get-Volume -DriveLetter C
$cvolume2 = $cvolume.FileSystemLabel
#$cvolume2

if($cvolume2 -eq 'System')
    {
#   echo TRUE
   $cvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $cvolume4 = "Failed- vol label s/b 'System'"
   #$getadapter5
    }


$fvolume = Get-Volume -DriveLetter F
$fvolume2 = $fvolume.FileSystemLabel
#$fvolume2

if($fvolume2 -eq 'MSSQL_MDF')
    {
#   echo TRUE
   $fvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $fvolume4 = "Failed- vol label s/b 'MSSQL_MDF'"
   #$getadapter5
    }

$gvolume = Get-Volume -DriveLetter G
$gvolume2 = $gvolume.FileSystemLabel
#$gvolume2

if($gvolume2 -eq 'logs')
    {
#   echo TRUE
   $gvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $gvolume4 = "Failed- vol label s/b 'logs'"
   #$getadapter5
    }

$hvolume = Get-Volume -DriveLetter H
$hvolume2 = $hvolume.FileSystemLabel
#$hvolume2

if($hvolume2 -eq 'backup')
    {
#   echo TRUE
   $hvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $hvolume4 = "Failed- vol label s/b 'backup'"
   #$getadapter5
    }

$ivolume = Get-Volume -DriveLetter I
$ivolume2 = $ivolume.FileSystemLabel
#$ivolume2

if($ivolume2 -eq 'MSSQL_TEMP')
    {
#   echo TRUE
   $ivolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $ivolume4 = "Failed- vol label s/b 'MSSQL_TEMP'"
   #$getadapter5
    }


$jvolume = Get-Volume -DriveLetter J
$jvolume2 = $jvolume.FileSystemLabel
#$jvolume2

if($jvolume2 -eq 'MSSQL_LDF')
    {
#   echo TRUE
   $jvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $jvolume4 = "Failed- vol label s/b 'MSSQL_LDF'"
   #$getadapter5
    }
    
    } else {
$dbvolumeinc = 'Database Server : # of volume disks are incomplete please validate..'
}
     
} else {
#   echo No Database


$driveLetters= (Get-Volume).DriveLetter
#if ($driveLetters -contains "C" -and $driveLetters -contains "F" -and $driveLetters -contains "G" -and $driveLetters -contains "H" -and $driveLetters -contains "I"  -and $driveLetters -contains "J")
if ($driveLetters -contains "C")
{

#echo 'C, F, G and H Exists'
#run script to check label here
$cvolume = Get-Volume -DriveLetter C
$cvolume2 = $cvolume.FileSystemLabel
#$cvolume2

if($cvolume2 -eq 'System')
    {
#   echo TRUE
   $cvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $cvolume4 = "Failed- vol label s/b 'System'"
   #$getadapter5
    }


$fvolume = Get-Volume -DriveLetter F
$fvolume2 = $fvolume.FileSystemLabel
#$fvolume2

if($fvolume2 -eq 'appdir')
    {
#   echo TRUE
   $fvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $fvolume4 = "Failed- vol label s/b 'appdir'"
   #$getadapter5
    }

$gvolume = Get-Volume -DriveLetter G
$gvolume2 = $gvolume.FileSystemLabel
#$gvolume2

if($gvolume2 -eq 'logs')
    {
#   echo TRUE
   $gvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $gvolume4 = "Failed- vol label s/b 'logs'"
   #$getadapter5
    }

$hvolume = Get-Volume -DriveLetter H
$hvolume2 = $hvolume.FileSystemLabel
#$hvolume2

if($hvolume2 -eq 'backup')
    {
#   echo TRUE
   $hvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $hvolume4 = "Failed- vol label s/b 'backup'"
   #$getadapter5
    } 




    } else {
$appvolumeinc = 'Apps Server : # of volume disks are incomplete please validate..'

}
}

#Average CPU Utilization
$AVGProc = Get-WmiObject -computername $computername win32_processor | Measure-Object -property LoadPercentage -Average | Select Average


#Average Memory Utilization
$OS = gwmi -Class win32_operatingsystem -computername $computername | Select-Object @{Name = "MemoryUsage"; Expression = {“{0:N2}” -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }}


#Logical Disk Capacity and Free space
$Disks = Get-WmiObject -Class Win32_LogicalDisk -Filter ‘DriveType=3’ | Select DeviceID, VolumeName, @{Name="Freespace (GB)"; Expression={[math]::round($_.Freespace/1GB, 2)}}, @{Name = 'Freespace (%)';Expression = {"{0:N0}%" -f (($_.FreeSpace/$_.Size) * 100)}}, @{Name="Capacity (GB)"; Expression={[math]::round($_.size/1GB, 2)}} | ConvertTo-Html
$DisksLUN = Get-PhysicalDisk | Select FriendlyName, MediaType | ConvertTo-Html


#Get CPU Socket and Core Info
$cs = Get-WmiObject -class Win32_ComputerSystem
$Sockets = $cs.numberofprocessors
$Cores = $cs.numberoflogicalprocessors

#Get Memory Info
$InstalledRAM = systeminfo | findstr /C:"Total Physical Memory"
$FreeRAM = systeminfo |findstr /C:"Available Physical Memory"

#GetLocalUserLists
$locallist = Get-LocalUser | Select Name,Enabled,Description,PasswordExpires | ConvertTo-Html
$localadmin = Get-LocalGroupMember -Name Administrators | ConvertTo-Html

#Check for latest Windows Updates / Hotfix Installed

$computername = hostname.exe
#$lastpatch1 = Get-HotFix -ComputerName $computername | Select-Object PSComputerName,HotFixID,Description,InstalledBy,InstalledOn
#$lastpatch = Get-WmiObject Win32_Quickfixengineering | select @{Name="InstalledOn";Expression={$_.InstalledOn -as [datetime]}} | Sort-Object -Property Installedon | select-object -property installedon -last 1

$lastpatchcsv = Get-Hotfix | Sort-Object -Descending -Property InstalledOn
$lastpatchhtml = Get-Hotfix | Sort-Object -Descending -Property InstalledOn | ConvertTo-Html
$lastpatch1 = Get-Date -UFormat "%B %Y"
$hotfixstatus = "Refer to Hotfix HTML and CSV Report"

#$lastpatch2 = $lastpatch1.split('-')
#$lastpatch2[0]
#$lastpatch1
#if($lastpatch2 -eq 2022)
#{
#    echo TRUE
#   $hotfixstatus1 = "Latest Patch Date Installed - $lastpatch1"
#   
#} else {
#    echo FALSE
#   $hotfixstatus2 = "Latest Patch Date Installed - $lastpatch1"
#}


#Scheduled Tasks

$schedtasks = Get-ChildItem -Path c:\windows\system32\Tasks | Select Name,Exists,CreationTime,LastWriteTime | ConvertTo-Html

#EventLog Critical Errors

$appevents = Get-EventLog -LogName Application -Newest 5 -EntryType Error | Select EventID,TimeGenerated,TimeWritten,Message | ConvertTo-Html
$systemevents = Get-EventLog -LogName System -Newest 5 -EntryType Error | Select EventID,TimeGenerated,TimeWritten,Message | ConvertTo-Html

#Bacula Comms Test


## If Server is VMWare
#If ((Get-ComputerInfo).CsManufacturer -eq "VMware, Inc.") {

#route -p add 10.5.0.0/20 10.72.12.1
#route -p add 10.72.4.0/23 10.72.12.1

#$gdcbacula = Test-NetConnection -ComputerName 10.5.7.2 -Port 9102 | Select InterfaceAlias,ComputerName,RemotePort,TcpTestSucceeded | ConvertTo-Html
#$mktbacula = Test-NetConnection -ComputerName 10.5.7.1 -Port 9102 | Select InterfaceAlias,ComputerName,RemotePort,TcpTestSucceeded | ConvertTo-Html
#$gdc2bacula = Test-NetConnection -ComputerName 10.5.7.2 -Port 9102 | Select InterfaceAlias,ComputerName,RemotePort,TcpTestSucceeded | ConvertTo-Html
#$mkt2bacula = Test-NetConnection -ComputerName 10.5.7.1 -Port 9102 | Select InterfaceAlias,ComputerName,RemotePort,TcpTestSucceeded | ConvertTo-Html
#}


## If Server is AWS
If ((Get-ComputerInfo).CsManufacturer -eq "Amazon EC2") {}

## If Server is AZURE
If ((Get-ComputerInfo).CsManufacturer -eq "Microsoft Corporation") {}



#Reset conditional variables
$osmemfail = $null
$osmempass1 = $null
$procfail = $null
$procpass = $null
$sepstatus3 = $null
$sepstatus4 = $null
$crowdstatus3 = $null
$crowdstatus4 = $null
$mpsstatus2 = $null
$mpsstatuspass = $null
$mpsstatusfail = $null
$fwstatus2 = $null
$fwstatusfail = $null
$fwstatuspass = $null
$rdptestfail = $null
$rdptestpass = $null


#Enable and Check for PS Remoting BareMetal/VMWare


If ((Get-WmiObject win32_computersystem).manufacturer -eq "VMware, Inc.") {

#Enable and Check for PS Remoting BareMetal/VMWare

If ((Test-WSMan).ProductVendor -eq "Microsoft Corporation")
{
#"Same"
$psremote = "Enabled"
}else{
#"not same"

    #Check for Inbound Rule

    $r = Get-NetFirewallRule -DisplayName 'WinRM Connection' 2> $null; 
    if ($r) { 
            # write-host "found it"; 
            } 
    else { 
            #write-host "did not find it" 
        $ips = @("10.71.52.63", "172.16.202.248", ”172.16.209.58”, ”172.16.165.42”, ”172.16.165.41”)
        New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -RemoteAddress $ips -LocalPort 5985, 5986 -Protocol TCP -Action Allow
        #New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -LocalPort 5985, 5986 -Protocol TCP -Action Allow
         }
     
    enable-psremoting -force
    winrm quickconfig
   $psremote = "Enabled"
}

}else{

#Enable and Check for PS Remoting BareMetal/VMWare

If ((Test-WSMan).ProductVendor -eq "Microsoft Corporation")
{
#"Same"
$psremote = "Enabled"
}else{
#"not same"

    #Check for Inbound Rule

    $r = Get-NetFirewallRule -DisplayName 'WinRM Connection' 2> $null; 
    if ($r) { 
            # write-host "found it"; 
            } 
    else { 
            #write-host "did not find it" 
        $ips = @("10.71.52.63", "172.16.202.248", ”172.16.209.58”, ”172.16.165.42”, ”172.16.165.41”)
        New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -RemoteAddress $ips -LocalPort 5985, 5986 -Protocol TCP -Action Allow
        #New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -LocalPort 5985, 5986 -Protocol TCP -Action Allow
         }
     
    enable-psremoting -force
    winrm quickconfig
   $psremote = "Enabled"
}
}



#Enable and Check for PS Remoting Azure

If ((Get-WmiObject win32_computersystem).manufacturer -eq "Microsoft Corporation") {

#Enable and Check for PS Remoting BareMetal/VMWare

If ((Test-WSMan).ProductVendor -eq "Microsoft Corporation")
{
#"Same"
$psremote = "Enabled"
}else{
#"not same"

    #Check for Inbound Rule

    $r = Get-NetFirewallRule -DisplayName 'WinRM Connection' 2> $null; 
    if ($r) { 
            # write-host "found it"; 
            } 
    else { 
            #write-host "did not find it" 
        $ips = @("10.61.0.8", "10.60.0.113")
        New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -RemoteAddress $ips -LocalPort 5985, 5986 -Protocol TCP -Action Allow
        #New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -LocalPort 5985, 5986 -Protocol TCP -Action Allow
         }
     
    enable-psremoting -force
    winrm quickconfig
   $psremote = "Enabled"
}

}else{}


#Enable and Check for PS Remoting AWS

If ((Get-WmiObject win32_computersystem).manufacturer -eq "Amazon EC2") {

#Enable and Check for PS Remoting BareMetal/VMWare

If ((Test-WSMan).ProductVendor -eq "Microsoft Corporation")
{
#"Same"
$psremote = "Enabled"
}else{
#"not same"

    #Check for Inbound Rule

    $r = Get-NetFirewallRule -DisplayName 'WinRM Connection' 2> $null; 
    if ($r) { 
            # write-host "found it"; 
            } 
    else { 
            #write-host "did not find it" 
        $ips = @("10.61.0.8", "10.60.0.113")
        New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -RemoteAddress $ips -LocalPort 5985, 5986 -Protocol TCP -Action Allow
        #New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -LocalPort 5985, 5986 -Protocol TCP -Action Allow
         }
     
    enable-psremoting -force
    winrm quickconfig
   $psremote = "Enabled"
}

}else{}
 


#Check for PAM Account
$dname1 = (Get-WmiObject -Class win32_ComputerSystem).Domain

if($dname1 -eq "WORKGROUP")
{
    #echo TRUE
    #Workgroup Server

    $op = Get-LocalUser | where-Object Name -eq "p_pam_admin1" | Measure
    if ($op.Count -eq 0) {
    
    #echo missing
    $pamaccount2 = "Failed - missing enrollment"
    } else {
    $pamaccount = "Passed w/ pam id - process for Enrollment"
     # REPORT SOMETHING
    }
       
} else {
    #echo FALSE
    #Domain Joined

    $op2 = Get-LocalUser | where-Object Name -like "UP-BTPAM-*" | Measure
    if ($op2.Count -eq 0) {
    #echo missing
    $pamaccount3 = "Failed missing enrollment"
    } else {
    $pamaccount4 = "Passed added group process for PAM Enrollment"
     # REPORT SOMETHING
}
}


#Check if Database Server
$dbservice = 'SQLSERVERAGENT'
If (Get-Service $dbservice -ErrorAction SilentlyContinue)
{
   # echo noexist
   $dbstatus = "No"
   $dbstatus3 = "N/A"
   $dbcheck = "Database Server"
} else {
   # echo exist
   $dbstatus2 = "Yes"
   $dbcheck1 = "Application/Web/File Server"
 
}

#$dbstatusv = Invoke-Sqlcmd -Query "SELECT @@VERSION;" -QueryTimeout 3


#Check if Database Service is Running
$dbservice = 'SQLSERVERAGENT'

If (Get-Service $dbservice -ErrorAction SilentlyContinue) {

    If ((Get-Service $dbservice).Status -eq 'Running') {

        $dbservice1="Passed - Installed and Running"

                                                        } Else {

#        Write-Host "$serviceName found, but it is not running."
        $dbservice2="Stopped"

                                                                }

                                                           } Else {

#    Write-Host "$serviceName not found"
        $dbservice2="Stopped"

                                                                   }


#If Condition Cluster Service

$cluserviceName = 'ClusSvc'

If (Get-Service $cluserviceName -ErrorAction SilentlyContinue) {

    If ((Get-Service $cluserviceName).Status -eq 'Running') {

#        Stop-Service $serviceName
#        Write-Host "Service is Running"
        $clustatus="Passed - Installed and Running"

    } Else {

#        Write-Host "$serviceName found, but it is not running."
        $clustatus2="Not active"

    }

} Else {

#    Write-Host "$serviceName not found"
        $clustatus2="Not active"

}



#If Condition and Variables - VMWare

#If ((Get-ComputerInfo).CsModel -eq "VMware Virtual Platform") {
#                                                            }  Else {
#
#                                                            #echo FALSE
#
#                                                                    } 
$vmserviceName = 'VMTools'
If (Get-Service $vmserviceName -ErrorAction SilentlyContinue) {
        
        If ((Get-Service $vmserviceName).Status -eq 'Running') {

        $vmstatus="Passed - Installed and Running"

        } Else {

        #        Write-Host "$serviceName found, but it is not running."
        $vmstatus2="Missing - Fail"

                }

        } Else {

        #    Write-Host "$serviceName not found"
        $vmstatus2="Missing - Fail"

       }

$vmtoolversion = gwmi -class win32_product -filter "name='VMware Tools'" | select version
    # $vmversion = & "C:\Program Files\VMware\VMware Tools\vmtoolsd.exe" -v


#If Condition and Variables
$OS = $null
$OS = gwmi -Class win32_operatingsystem -computername $computername | Select-Object @{Name = "MemoryUsage"; Expression = {“{0:N2}” -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }}

If ($OS.MemoryUsage -gt "50") {
$osmemfail="Failed - for verification"
  }
  else
  {
$osmempass1="Passed"
} 

If ($AVGProc.Average -gt "50") {
$procfail="Failed - for verification"
  }
  else
  {
$procpass="Passed"
} 


#Check Crowd Strike Service if existing

$serviceName = 'CSFalconService'

If (Get-Service $serviceName -ErrorAction SilentlyContinue) {

    If ((Get-Service $serviceName).Status -eq 'Running') {

$crowdstatus4="Passed - Installed and Running"

    } Else {

#        Write-Host "$serviceName found, but it is not running."
        $crowdstatus3="Missing - Fail"

    }

} Else {

#    Write-Host "$serviceName not found"
    $crowdstatus3="Missing - Fail"

}


#Check Crowd Strike Service if existing

$splunkname = 'SplunkForwarder'
If (Get-Service $splunkname -ErrorAction SilentlyContinue) {
$splunkstatus="Passed - Installed"
} Else {
#    Write-Host "$serviceName not found"
$splunkstatus2="Failed - Missing"
}


If ((Get-Service $splunkname).Status -eq 'Running') {
$splunkstatus3="Status - Running"
    } Else {
$splunkstatus4="Failed - Stopped"
    }




#If Condition SEP

$serviceName = 'SepMasterService'

If (Get-Service $serviceName -ErrorAction SilentlyContinue) {

    If ((Get-Service $serviceName).Status -eq 'Running') {

#        Stop-Service $serviceName
#        Write-Host "Service is Running"
$sepstatus4="Passed - Installed and Running"

    } Else {

#        Write-Host "$serviceName found, but it is not running."
        $sepstatus3="Missing - Fail"

    }

} Else {

#    Write-Host "$serviceName not found"
    $sepstatus3="Missing - Fail"

}


#Check FW Service
$mpsstatus = Get-Service MpsSvc | Select Status
$mpsstatus2 = $mpsstatus.status

#If Condition FW
If ($mpsstatus2 -eq 'Running') {
$mpsstatuspass="Passed"
  }  Else {
$mpsstatusfail="Failed"
} 

#Check FW Status
$fwstatus = Get-NetFirewallProfile -name Domain
$fwstatus2 = $fwstatus.enabled

#If Condition FW
If ($fwstatus2 -eq 'False') {
$fwstatuspass="Passed"
$fwdomainstatus="turned off"
#Write-Host = TRUE
  }  Else {
$fwstatusfail="Failed - must be turned off"
$fwdomainstatus2="turned on"
#Write-Host = FALSE
} 

#Remote Desktop Connection Test 3389
$ipaddress = hostname.exe
$port = 3389
$connection = New-Object System.Net.Sockets.TcpClient($ipaddress, $port)
if ($connection.Connected) {
    $connectionsuccess="Success"
}
else {
    $connectionfailed="Failed"
}

#If Condition RDP
If ($connection.Connected -eq 'Success') {
$rdptestpass="Passed"
  }  Else {
$rdptestfail="Failed"
} 


#Solarwinds Ports TCP 135,445,49152

$135 = Test-NetConnection -ComputerName $hostip -Port 135
$135t = $135.TcpTestSucceeded

If ($135.TcpTestSucceeded -eq 'True') {
$135fail="Passed"
  }  Else {
$135pass="Failed"
} 


$445 = Test-NetConnection -ComputerName $hostip -Port 445
$445t = $445.TcpTestSucceeded

If ($445.TcpTestSucceeded -eq 'True') {
$445fail="Passed"
  }  Else {
$445pass="Failed"
} 


#$49152 = Test-NetConnection -ComputerName $hostip -Port 49152
#$49152t = $49152.TcpTestSucceeded

#If ($49152.TcpTestSucceeded -eq 'True') {
#$49152fail="Passed"
#  }  Else {
#$49152pass="Failed"
#} 




#Bacula Comm Test

## If Server is VMWare
If ((Get-ComputerInfo).CsManufacturer -eq "VMware, Inc.") {

$getadapterip = Get-NetConnectionProfile -NetworkCategory 'DomainAuthenticated'
$getadapterip2 = $getadapterip.Name
#$getadapterip2

$getip= Get-NetConnectionProfile -Name $getadapterip2
$activeip = $getip.InterfaceAlias
$getip2 = (Get-NetIPAddress -AddressFamily IPV4 -InterfaceAlias $activeip).IPAddress
$ip = $getip2.split('.')
$count = $ip[1].length

#IP assign
$vpcsite1="46" 
$vpcsite2="71"

if($vpcsite1 -eq $ip[1]){
route -p add 10.5.0.0/20 10.72.12.1
 $mkt = Test-NetConnection -ComputerName 10.5.7.2 -Port 9102
 $mktt = $mkt.TcpTestSucceeded

 If ($mkt.TcpTestSucceeded -eq 'True') {
 $mktpass="MDC: Passed"
   }  Else {
 $mktfail="MDC: Failed"
 } 
 }

if($vpcsite2 -eq $ip[1]){
route -p add 10.72.4.0/23 10.72.12.1

 $gdc = Test-NetConnection -ComputerName 10.72.4.180 -Port 9102
 $gdct = $gdc.TcpTestSucceeded

 If ($gdc.TcpTestSucceeded -eq 'True') {
 $gdcpass="GDC: Passed"
   }  Else {
 $gdcfail="GDC: Failed"
 }
 }
 }
 

## If Server is AWS
If ((Get-ComputerInfo).CsManufacturer -eq "Amazon EC2") {
$mktpass="N/A"
$gdcpass="N/A"
}
## If Server is AZURE
If ((Get-ComputerInfo).CsManufacturer -eq "Microsoft Corporation") {
$mktpass="N/A"
$gdcpass="N/A"
}

 

#Generate HTML Report - for VMWare Servers

If ((Get-WmiObject win32_computersystem).manufacturer -eq "VMware, Inc.") {
##echo TRUE

$Outputreport ="<HTML>
<style>
table, th, td {
border: 1px solid black;
}
</style>

<title>Release to Production Compliance Report</title>
                
<table>
<tr/><td style='text-align:center;'><B>Date</B>: $date<td/>
<tr/>
<tr>
<font color =""#99000"" face=""Microsoft Tai le""><H1 style='text-align:center;'>Engagement Initial Review</H1></font></tr></table>
<table>
<H5><font face=""Microsoft Tai le""><u>$vcentercheck$nonevcentercheck</u></font></H5>
</table>

<table>
<tr><td/><b>Platform: </b><td/>$IsVirtual
<tr><td/><b>Server Role: </b><td/>$dbcheck$dbcheck1
</table>

<table>
<font color =""#FF0000"" face=""Microsoft Tai le"">
<H4>Items with Downtime</H4></font>
<tr><td/><b>Hostname: </b>$computername<td/><font color=""#008000"" face=""Microsoft Tai le"">$nameipsame1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$nameipsame2</font></tr>
<tr><td/><b>IP Address: </b>$hostip<td/></tr>
<tr><td/><b>Disk Label Details</b></tr>
<tr><td/><b>&nbsp;&nbsp;C</b>: $cvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$cvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$cvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspF</b>: $fvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$fvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$fvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspG</b>: $gvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$gvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$gvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspH</b>: $hvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$hvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$hvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspI (DB)</b>: $ivolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$ivolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$ivolume4</font></tr>
<tr><td/><b>&nbsp;&nbspJ (DB)</b>: $jvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$jvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$jvolume4</font></tr>
<tr><td/><b>NIC Adapters</b></tr>
<tr><td/><b>&nbsp;&nbspBDO LAN</b><td/><font color=""#008000"" face=""Microsoft Tai le"">$nonvmware$getadapter4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$getadapter5</font></tr>
<tr><td/><b>&nbsp;&nbspBackup</b><td/><font color=""#008000"" face=""Microsoft Tai le"">$nonvmware$get2adapter4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$get2adapter5</font></tr>
<tr><td/><b>Windows Patches</b><td/><font color=""#0000FF"" face=""Microsoft Tai le"">$hotfixstatus</font></tr>
</table>
<table>
<font color =""#FF0000"" face=""Microsoft Tai le"">
<H4>Items with No Downtime</H4></font>
<tr/><td/>Time Zone s/b (UTC+08:00) Kuala Lumpur, Singapore: <td/><font color=""#008000"" face=""Microsoft Tai le"">$timezonepass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$timezonefail</font>
<tr><td/><b>NTP Details</b></tr>
<tr/><td/>&nbsp;&nbsp;Type of Connection<td/>$ntpcheckd$ntpcheckw
<tr/><td/>&nbsp;&nbsp;Synced to Domain?<td/><font color=""#008000"" face=""Microsoft Tai le"">$ntpcheckstatus1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$ntpcheckstatus2</font>
<tr/><td/>&nbsp;&nbsp;NTP Source<td/>$ntpssource
<tr/><td/>&nbsp;&nbsp;NTP Last Sync<td/>$ntpssync
<tr/><td>Remote Connection Port TCP 3389 Conection Test $rdptest <td/><font color=""#008000"" face=""Microsoft Tai le"">$rdptestpass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$rdptestfail</font>
<tr><td/><b>Utilization</b></tr>
<tr/><td/>&nbsp;&nbsp;CPU Utilization: $($AVGProc.Average)% <td/><font color=""#008000"" face=""Microsoft Tai le"">$procpass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$procfail</font>
<tr/><td/>&nbsp;&nbsp;RAM Utilization: $($OS.MemoryUsage)% <td/><font color=""#008000"" face=""Microsoft Tai le"">$osmempass1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$osmemfail</font>
<tr/><td/><b>Windows Firewall</b></tr>
<tr/><td/>&nbsp;&nbsp;Windows Firewall Service is $mpsstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$mpsstatuspass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$mpsstatusfail</font>
<tr/><td/>&nbsp;&nbsp;Windows Firewall Domain Profile is $fwdomainstatus$fwdomainstatus2<td/><font color=""#008000"" face=""Microsoft Tai le"">$fwstatuspass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$fwstatusfail</font>
<tr/><td/><b>Security</b></tr>
<tr/><td/>&nbsp;&nbsp;CrowdStrike Falcon Sensor Installed: $crowdstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$crowdstatus4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$crowdstatus3</font>
<tr/><td/>&nbsp;&nbsp;Symantec Installed: $sepstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$sepstatus4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$sepstatus3</font>
<tr/><td/>&nbsp;&nbsp;Splunk Installed: <td/><font color=""#008000"" face=""Microsoft Tai le"">$splunkstatus $splunkstatus3</font><font color=""#FF0000"" face=""Microsoft Tai le"">$splunkstatus2 $splunkstatus4</font>
<tr/><td/>&nbsp;&nbsp;PAM Enrollment: <td/><font color=""#008000"" face=""Microsoft Tai le"">$pamaccount$pamaccount4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$pamaccount2$pamaccount3</font>
<tr/><td/><b>Backup Monitoring</b></tr>
<tr/><td/>Solarwinds:
<tr/><td/>&nbsp;&nbsp;Port TCP 135 Conection Test<td/><font color=""#008000"" face=""Microsoft Tai le"">$135pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$135fail</font>
<tr/><td/>&nbsp;&nbsp;Port TCP 445  Conection Test<td/><font color=""#008000"" face=""Microsoft Tai le"">$445pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$445fail</font>
<tr/><td/>Bacula:
<tr/><td/>&nbsp;&nbsp;Port TCP 9102 Conection Test <td/><font color=""#008000"" face=""Microsoft Tai le"">$gdcpass</font> <font color=""#008000"" face=""Microsoft Tai le"">$mktpass</font><font color=""#FF0000"" face=""Microsoft Tai le"">$gdcfail</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$mktfail</font>
<tr/><td/>&nbsp;&nbsp;Port TCP 9102 Conection Test <td/><font color=""#008000"" face=""Microsoft Tai le"">$gdc2pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$mkt2pass</font><font color=""#FF0000"" face=""Microsoft Tai le"">$gdc2fail</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$mk2tfail</font>
<tr/><td/>PS Remote: <td/><font color=""#008000"" face=""Microsoft Tai le"">$psremote</font> <font color=""#FF0000"" face=""Microsoft Tai le""></font>
<tr/><td/>LAPS Requirement: <td/><font color=""#008000"" face=""Microsoft Tai le"">$adminpwdtrue</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$adminpwdfalse</font>
<tr/><td/>

 </Table>                     

</table>


<table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>General Information</H4></font>
                <tr><td/><b>Hostname: </b>$computername</tr>
                <tr><td/><b>Manufacturer: </b>$IsVirtual</tr>
                <tr><td/><b>IP Address: </b>IP Address: $hostip</tr>
                <tr><td/><b>Gateway </b>IP Gateway: $hostgateway</tr>
                <tr><td/><b>Domain: </b>$dname</tr>
                <tr><td/><b>Operating System: </b>$osname</tr>
                <tr><td/><b>Operating System Installation Date: </b>$osdate</tr>
                <tr><td/><b>Edition: </b>$edition</tr>
                <tr><td/><b>Processor Model: </b>$processormodel</tr>
                <tr><td/><b>Processor Model: </b>$processorsystem</tr>
                <tr><td/><b>Build: </b>$buildnumber</tr>
                <tr><td/><b>Architecture: </b>$architecture</tr>
                <tr><td/><b>OS Language: </b>$oslanguange</tr>
                <tr><td/><b>OS version: </b>$osversion</tr>
                <tr><td/><b>OS LastReboot: </b>$oslastBoot</tr>
                <tr><td/><b>OS Uptime: </b>$osuptime</tr>
                <tr><td/><b>Regional Settings: </b>$systemlocale</tr>
                <tr><td/><b>Timezone: </b>$timezone</tr>
                <tr><td/><b>With Database?: </b>$dbstatus$dbstatus2</tr>
                       
 </Table>

<Table>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4>CPU and Utilization &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; RAM and Utilization</H4></font>
                   
                    <tr>
                   <tr><TD><B>CPU Sockets</B>: $Sockets</TD><TD>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>RAM Installed</B>: $InstalledRAM</TD></tr>
                   <tr><TD><B>CPU Cores</B>: $Cores</TD><TD>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>RAM Free</B>: $FreeRAM</TD></tr>
                                      

</Table>
   <table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>Fail Over Cluster Service Check</H4></font>
                <tr/><td>Cluster Service - <font color=""#FF0000"" face=""Microsoft Tai le"">$clustatus2</font> <font color=""#008000"" face=""Microsoft Tai le"">$clustatus</font><td/>
  </Table>                                                                         
                   <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Disk and Utilization</H4></font>
                   $Disks

                   <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Disk and Datastore</H4></font>
                   $DisksLUN
                   
                    <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Network Adapters Set</H4></font>
                   $networkadapter                 
                   $netadapter
  </Table>


   <table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>VMWare Tools (applies ony to VMWare Servers)</H4></font>
                <tr/><td>Service VmWare Tools - <font color=""#FF0000"" face=""Microsoft Tai le"">$vmstatus2</font> <font color=""#008000"" face=""Microsoft Tai le"">$vmstatus</font><td/>
                <tr/><td>Version - $vmtoolversion<td/>
  </Table>
  <Table>
          
              <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Scheduled Tasks</H4></font>
                   $schedtasks
          
                
  </Table>

         
       
           <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Local Accounts</H4></font>
                   $locallist
                   $localadmin
              
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> HotFix Results</H4></font>
                   $lastpatchhtml                                     
          
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Application Critical Event Logs</H4></font>
                   $appevents
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> System Critical Logs</H4></font>
                   $systemevents
                            
    
                   </HTML>"

                                                            }  Else {

#HTML Report for Non VmWAre CI

$Outputreport ="<HTML>
<style>
table, th, td {
border: 1px solid black;
}
</style>

<title>Release to Production Compliance Report</title>
                
<table>
<tr/><td style='text-align:center;'><B>Date</B>: $date<td/>
<tr/>
<tr>
<font color =""#99000"" face=""Microsoft Tai le""><H1 style='text-align:center;'>Engagement Initial Review</H1></font></tr></table>
<table>
<H5><font face=""Microsoft Tai le""><u>$vcentercheck$nonevcentercheck</u></font></H5>
</table>

<table>
<tr><td/><b>Platform: </b><td/>$IsVirtual
<tr><td/><b>Server Role: </b><td/>$dbcheck$dbcheck1
</table>

<table>
<font color =""#FF0000"" face=""Microsoft Tai le"">
<H4>Items with Downtime</H4></font>
<tr><td/><b>Hostname: </b>$computername<td/><font color=""#008000"" face=""Microsoft Tai le"">$nameipsame1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$nameipsame2</font></tr>
<tr><td/><b>IP Address: </b>$hostip<td/></tr>
<tr><td/><b>Disk Label Details</b></tr>
<tr><td/><b>&nbsp;&nbsp;C</b>: $cvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$cvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$cvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspF</b>: $fvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$fvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$fvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspG</b>: $gvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$gvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$gvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspH</b>: $hvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$hvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$hvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspI (DB)</b>: $ivolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$ivolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$ivolume4</font></tr>
<tr><td/><b>&nbsp;&nbspJ (DB)</b>: $jvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$jvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$jvolume4</font></tr>
<tr><td/><b>NIC Adapters</b></tr>
<tr><td/><b>&nbsp;&nbspBDO LAN</b><td/><font color=""#008000"" face=""Microsoft Tai le"">$nonvmware$getadapter4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$getadapter5</font></tr>
<tr><td/><b>&nbsp;&nbspBackup</b><td/><font color=""#008000"" face=""Microsoft Tai le"">$nonvmware$get2adapter4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$get2adapter5</font></tr>
<tr><td/><b>Windows Patches</b><td/><font color=""#0000FF"" face=""Microsoft Tai le"">$hotfixstatus</font></tr>
</table>
<table>
<font color =""#FF0000"" face=""Microsoft Tai le"">
<H4>Items with No Downtime</H4></font>
<tr/><td/>Time Zone s/b (UTC+08:00) Kuala Lumpur, Singapore: <td/><font color=""#008000"" face=""Microsoft Tai le"">$timezonepass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$timezonefail</font>
<tr><td/><b>NTP Details</b></tr>
<tr/><td/>&nbsp;&nbsp;Type of Connection<td/>$ntpcheckd$ntpcheckw
<tr/><td/>&nbsp;&nbsp;Synced to Domain?<td/><font color=""#008000"" face=""Microsoft Tai le"">$ntpcheckstatus1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$ntpcheckstatus2</font>
<tr/><td/>&nbsp;&nbsp;NTP Server Connection<td/>$ntps
<tr/><td>Remote Connection Port TCP 3389 Conection Test $rdptest <td/><font color=""#008000"" face=""Microsoft Tai le"">$rdptestpass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$rdptestfail</font>
<tr><td/><b>Utilization</b></tr>
<tr/><td/>&nbsp;&nbsp;CPU Utilization: $($AVGProc.Average)% <td/><font color=""#008000"" face=""Microsoft Tai le"">$procpass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$procfail</font>
<tr/><td/>&nbsp;&nbsp;RAM Utilization: $($OS.MemoryUsage)% <td/><font color=""#008000"" face=""Microsoft Tai le"">$osmempass1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$osmemfail</font>
<tr/><td/><b>Windows Firewall</b></tr>
<tr/><td/>&nbsp;&nbsp;Windows Firewall Service is $mpsstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$mpsstatuspass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$mpsstatusfail</font>
<tr/><td/>&nbsp;&nbsp;Windows Firewall Domain Profile is $fwstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$fwstatuspass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$fwstatusfail</font>
<tr/><td/><b>Security</b></tr>
<tr/><td/>&nbsp;&nbsp;CrowdStrike Falcon Sensor Installed: $crowdstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$crowdstatus4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$crowdstatus3</font>
<tr/><td/>&nbsp;&nbsp;Symantec Installed: $sepstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$sepstatus4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$sepstatus3</font>
<tr/><td/>&nbsp;&nbsp;Splunk Installed: <td/><font color=""#008000"" face=""Microsoft Tai le"">$splunkstatus $splunkstatus3</font><font color=""#FF0000"" face=""Microsoft Tai le"">$splunkstatus2 $splunkstatus4</font>
<tr/><td/>&nbsp;&nbsp;PAM Enrollment: <td/><font color=""#008000"" face=""Microsoft Tai le"">$pamaccount</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$pamaccount2</font>
<tr/><td/><b>Backup Monitoring</b></tr>
<tr/><td/>Solarwinds:
<tr/><td/>&nbsp;&nbsp;Port TCP 135 Conection Test<td/><font color=""#008000"" face=""Microsoft Tai le"">$135pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$135fail</font>
<tr/><td/>&nbsp;&nbsp;Port TCP 445  Conection Test<td/><font color=""#008000"" face=""Microsoft Tai le"">$445pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$445fail</font>
<tr/><td/>PS Remote: <td/><font color=""#008000"" face=""Microsoft Tai le"">$psremote</font> <font color=""#FF0000"" face=""Microsoft Tai le""></font>
<tr/><td/>LAPS Requirement: <td/><font color=""#008000"" face=""Microsoft Tai le"">$adminpwdtrue</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$adminpwdfalse</font>
<tr/><td/>

 </Table>                     

</table>


<table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>General Information</H4></font>
                <tr><td/><b>Hostname: </b>$computername</tr>
                <tr><td/><b>Manufacturer: </b>$IsVirtual</tr>
                <tr><td/><b>IP Address: </b>IP Address: $hostip</tr>
                <tr><td/><b>Gateway </b>IP Gateway: $hostgateway</tr>
                <tr><td/><b>Domain: </b>$dname</tr>
                <tr><td/><b>Operating System: </b>$osname</tr>
                <tr><td/><b>Operating System Installation Date: </b>$osdate</tr>
                <tr><td/><b>Edition: </b>$edition</tr>
                <tr><td/><b>Processor Model: </b>$processormodel</tr>
                <tr><td/><b>Processor Model: </b>$processorsystem</tr>
                <tr><td/><b>Build: </b>$buildnumber</tr>
                <tr><td/><b>Architecture: </b>$architecture</tr>
                <tr><td/><b>OS Language: </b>$oslanguange</tr>
                <tr><td/><b>OS version: </b>$osversion</tr>
                <tr><td/><b>OS LastReboot: </b>$oslastBoot</tr>
                <tr><td/><b>OS Uptime: </b>$osuptime</tr>
                <tr><td/><b>Regional Settings: </b>$systemlocale</tr>
                <tr><td/><b>Timezone: </b>$timezone</tr>
                <tr><td/><b>With Database?: </b>$dbstatus$dbstatus2</tr>
                       
 </Table>

<Table>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4>CPU and Utilization &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; RAM and Utilization</H4></font>
                   
                    <tr>
                   <tr><TD><B>CPU Sockets</B>: $Sockets</TD><TD>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>RAM Installed</B>: $InstalledRAM</TD></tr>
                   <tr><TD><B>CPU Cores</B>: $Cores</TD><TD>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>RAM Free</B>: $FreeRAM</TD></tr>
                                      

</Table>
   <table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>Fail Over Cluster Service Check</H4></font>
                <tr/><td>Cluster Service - <font color=""#FF0000"" face=""Microsoft Tai le"">$clustatus2</font> <font color=""#008000"" face=""Microsoft Tai le"">$clustatus</font><td/>
  </Table>                                                                         
                   <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Disk and Utilization</H4></font>
                   $Disks

                   <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Disk and Datastore</H4></font>
                   $DisksLUN
                   
                    <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Network Adapters Set</H4></font>
                   $networkadapter                 
                   $netadapter
  </Table>
      
  <Table>
          
              <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Scheduled Tasks</H4></font>
                   $schedtasks
          
                
  </Table>

         
       
           <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Local Accounts</H4></font>
                   $locallist
                   $localadmin
              
              
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> HotFix Results</H4></font>
                   $lastpatchhtml                           
          
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Application Critical Event Logs</H4></font>
                   $appevents
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> System Critical Logs</H4></font>
                   $systemevents
                            
    
                   </HTML>"
##echo FALSE

                                                                    } 
    # }


#Windows Baseline fixes

#base# rem ####### Disabling Unrequired Services
#base# sc config TrkWks start= disabled
#base# sc config Browser start= disabled
#base# sc config RasMan start= disabled
#base# sc config ShellHWDetection start= disabled
#base# sc config TapiSrv start= disabled
#base# sc config AudioEndpointBuilder start= disabled
#base# sc config AudioSrv start= disabled
#base# sc config dot3svc start= disabled
#base# sc config hidserv start= disabled

#base# rem ####### Triple DES
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\Triple DES 168" /v Enabled /t REG_DWORD /d 0 /f
#base# rem ####### Cache logon
#base# rem ####### Null Session Key
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v CachedLogonsCount /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v RestrictAnonymous /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v LMCompatibilityLevel /t REG_DWORD /d 3 /f
#base# rem ####### FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX Key
#base# rem ####### WOW6432Node Key
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX" /v iexplore.exe /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX" /v iexplore.exe /t REG_DWORD /d 1 /f
#base# rem ####### Lanman
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" /v RequireSecuritySignature /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v enablesecuritysignature /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v requiresecuritysignature /t REG_DWORD /d 1 /f

#base# rem ####### Disabling Admin Shares
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v AutoShareServer /t REG_DWORD /d 0 /f

#base# rem ####### Set DNS Cache TTL to 15 minutes
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v MaxCacheEntryTtlLimit /t REG_DWORD /d 900 /f

#base# rem ####### Disabling SSL/TLS 1.0/TLS 1.1
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server" /v Enabled /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server" /v Enabled /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server" /v Enabled /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server" /v Enabled /t REG_DWORD /d 0 /f

#base# rem ####### Disabling IPSourceRouting
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v DisableIPSourceRouting /t REG_DWORD /d 2 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" /v DisableIPSourceRouting /t REG_DWORD /d 2 /f

#base# rem ####### Disabling StrictNameChecking and LoopbackCheck Registry Settings
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v DisableStrictNameChecking /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\LSA" /v DisableLoopbackCheck /t REG_DWORD /d 1 /f

#base# rem ####### Set DNS Cache TTL to 15 minutes
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v MaxCacheEntryTtlLimit /t REG_DWORD /d 900 /f

#base# rem ####### Enabled Last Accessed Date
#base# fsutil behavior set disablelastaccess 0

#base# rem ####### Disable LanMan/NTLMv1 Authentication method
#base# reg add "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Lsa" /v LMCompatibilityLevel /t REG_DWORD /d 3 /f

#base# rem ####### Fix to Spectre/Meltdown
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v FeatureSettingsOverride /t REG_DWORD /d 72 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v FeatureSettingsOverrideMask /t REG_DWORD /d 3 /f
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization" /v MinVmVersionForCpuBasedMitigations /t REG_SZ /d 1.0 /f

#base# rem Fix to Windows Registry Setting To Globally Prevent Socket Hijacking Missing
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Afd\Parameters" /v DisableAddressSharing /t REG_DWORD /d 1 /f

#base# rem ####### Setting Session Time for Idle Remote Desktop Connections
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v MaxIdleTime /t REG_DWORD /d 900000 /f

#base# rem ####### Enabling Remote Desktop Access with Network Level Authentication
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v UserAuthentication /t REG_DWORD /d 1 /f

#base# rem ####### Disabling Admin Shares
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v AutoShareServer /t REG_DWORD /d 0 /f

#base# rem ####### Microsoft Group Policy Remote Code Execution Vulnerability
#base# reg add "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" /v "\\*\NETLOGON" /t REG_SZ /d "RequireMutualAuthentication=1, RequireIntegrity=1" /f
#base# reg add "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" /v "\\*\SYSVOL" /t REG_SZ /d "RequireMutualAuthentication=1, RequireIntegrity=1" /f

#Windows Baseline fixes



#Opening Log Folder

$lastpatchcsv | Export-Csv $Logpath\$computername.Hotfix_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).csv -NoTypeInformation
$lastpatchcsv | Export-Csv $Logpath2\$computername.Hotfix_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).csv -NoTypeInformation
$lastpatchcsv | Export-Csv $Logpathaws\$computername.Hotfix_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).csv -NoTypeInformation
$lastpatchcsv | Export-Csv $Logpathaz\$computername.Hotfix_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).csv -NoTypeInformation

$Outputreport | out-file "$Logpath\$computername.RTP_Health_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).htm"
$Outputreport | out-file "$Logpath2\$computername.RTP_Health_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).htm"
$Outputreport | out-file "$Logpathaws\$computername.RTP_Health_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).htm"
$Outputreport | out-file "$Logpathaz\$computername.RTP_Health_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).htm"

#ii "$iilog"

#Generate Group Policy Report
#gpresult /h $Logpath\$computername.GPOResult.html /scope:computer /f

#Generate Critical EventLog Report
#Get-EventLog -LogName Application -EntryType Error | Select EventID,TimeGenerated,TimeWritten,Message | Export-Csv -Path "$Logpath\$computername.EventLog_Application.csv" -NoTypeInformation
#Get-EventLog -LogName System -EntryType Error | Select EventID,TimeGenerated,TimeWritten,Message | Export-Csv -Path "$Logpath\$computername.EventLog_System.csv" -NoTypeInformation

cls
cls

#Write-Host "Process Complete Please Check Logs"
$filter="$computername.RTP*.htm"
$latest = Get-ChildItem -Path $Logpath -Filter $filter | Sort-Object LastAccessTime -Descending | Select-Object -First 1
$latestfile = $latest.name
#& 'C:\Windows\System32\notepad.exe' $Logpath\$latestfile
& start $Logpath\$latestfile
#write-host ""
#write-host ""
#write-host "$computername - RTP Review Report Successful" -ForegroundColor Green

#$Error >>$PSScriptRoot\Error.txt
#}
#If ((Get-ComputerInfo).CsManufacturer -eq "VMware, Inc.") {logoff}else{cls}
If ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name -eq "HO\b025023265") {cls}else{cls}
