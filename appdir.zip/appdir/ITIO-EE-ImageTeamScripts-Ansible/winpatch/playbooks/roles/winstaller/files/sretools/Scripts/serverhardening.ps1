﻿$mypath = $MyInvocation.MyCommand.Path
Write-Output "Path of the script : $mypath"
$scriptpath = Split-Path $mypath -Parent

$serverlistfile = "$scriptpath\ServersLists.txt"
$Logpath = "$scriptpath\BaselineLogs"
$LocalLogpath = "C:\sretools\BaselineLogs"
$LogDate = get-date -f MM-dd-yyyy-hhmm


$FileExists = Test-Path $LocalLogpath
If ($FileExists -eq $True) {
    Write-Host "Local Folder Already exists"
     }
 Else {
    New-Item -Path $LocalLogpath -ItemType "directory" -Force
     }

$FileExists = Test-Path $Logpath
If ($FileExists -eq $True) {
    Write-Host "Folder Already exists"
     }
 Else {
    New-Item -Path $Logpath -ItemType "directory" -Force
     }
     


function GenerateForm {

[reflection.assembly]::loadwithpartialname("System.Windows.Forms") | Out-Null
[reflection.assembly]::loadwithpartialname("System.Drawing") | Out-Null

$form1 = New-Object System.Windows.Forms.Form
$button1 = New-Object System.Windows.Forms.Button
$button2 = New-Object System.Windows.Forms.Button
$textlabel1 = New-Object System.Windows.Forms.Label
$listBox1 = New-Object System.Windows.Forms.ListBox
$checkBox4 = New-Object System.Windows.Forms.CheckBox
$checkBox3 = New-Object System.Windows.Forms.CheckBox
$checkBox2 = New-Object System.Windows.Forms.CheckBox
$checkBox1 = New-Object System.Windows.Forms.CheckBox
$checkBox0 = New-Object System.Windows.Forms.CheckBox
$InitialFormWindowState = New-Object System.Windows.Forms.FormWindowState

$b1= $false
$b2= $false
$b3= $false
$b4= $false
$b5= $false


#----------------------------------------------
#Generated Event Script Blocks
#----------------------------------------------

$handler_button1_Click= 
{
    $listBox1.Items.Clear();    

    if ($checkBox0.Checked){
    $listBox1.Items.Add( "Performing RTP-Precheck....") 
    
#SCRIPT PROPER - START

function prompt {' '}

$computername = hostname.exe

$Logpath = "c:\sretools\RTPLogs"
$Logpath2 = "\\fs10.cfs.bdo.com.ph\PUBLIC4\ITSC-Standards\NextGenIT\RTP\logs\$computername-RTP-Reports"
$Logpathaws = "\\tsclient\C\temp\D3_RTP\logs\$computername-RTP-Reports"
$Logpathaz = "\\SW40000002\rtp\logs\$computername-RTP-Reports"

New-Item -Path $Logpath -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item -Path $Logpath2 -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item -Path $Logpathaws -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item -Path $Logpathaz -ItemType "directory" -Force -ErrorAction SilentlyContinue

cls
#New-Item -ItemType Directory -Force -Path $Logpath\$ENV:COMPUTERNAME

#Progress parameter
$Progress = @{
    Activity = 'Collecting RTP Data for Report:'
    CurrentOperation = "Loading"
#    Status = 'Collecting data'
    PercentComplete = 0
}

Write-Progress @Progress
$i = 0

    $i++
#    [int]$percentage = ($i / $_.Count)*100
    $Name = $null
    $Name = $file.name
    $progress.CurrentOperation = "$name"
  #  $progress.Status = 'Processing file: '
  #  $progress.PercentComplete = $percentage
  
    Write-Progress @Progress
     
    Start-Sleep -Milliseconds 600


#Write-Host "Mapping drive, please wait..." -ForegroundColor Yellow 
#Write-Host ""
Write-Host "Running RTP Review Diagnostics please wait until its complete......" -ForegroundColor Yellow 


# General Info
$computername = hostname.exe
$FQDN = $DNSCheck.hostname
$IsVirtual=(Get-WmiObject win32_computersystem).manufacturer
$computername = (Get-ComputerInfo).CsDNSHostName
$dname = (Get-WmiObject -Class win32_ComputerSystem).Domain
$osname = (Get-ComputerInfo).OsName
$osversion = (Get-ComputerInfo).OsVersion
$osdate = (Get-ComputerInfo).OsInstallDate
$edition = (Get-ComputerInfo).WindowsEditionId
$processormodel = (Get-ComputerInfo).CsModel
$buildnumber = (Get-ComputerInfo).OsBuildNumber
$architecture = (Get-ComputerInfo).OsArchitecture
$oslanguange = (Get-ComputerInfo).OsLanguage
$processorsystem = (Get-ComputerInfo).CsSystemType
$systemlocale = (Get-ComputerInfo).OsLocale
$timezone = (Get-ComputerInfo).TimeZone
$oslastBoot = (Get-ComputerInfo).OsLastBootUpTime
$osuptime = (Get-ComputerInfo).OsUptime
$date = Get-Date
$hostip = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration | where {$_.DefaultIPGateway -ne $null}).IPAddress | select-object -first 1
$hostgateway = (Get-wmiObject Win32_networkAdapterConfiguration | ?{$_.IPEnabled}).DefaultIPGateway


#NTP Connection
$computername = hostname.exe
$servers = $computername

foreach ($server in $servers){
$ntps = w32tm /query /status | ?{$_ -match 'Stratum:'} | %{($_ -split ":\s\b")[1]}
$ntpssource = w32tm /query /Source
$ntpssync = w32tm /query /status | ?{$_ -match 'Last Successful Sync Time:'} | %{($_ -split ":\s\b")[1]}
#$ntps = w32tm /query /computer:$server /configuration | ?{$_ -match 'ntpserver:'} | %{($_ -split ":\s\b")[1]}
#new-object psobject -property @{
#    Server = $Server
#    NTPSource = $ntps
#    }
}

if($ntps -eq $null){
#echo 'ntp is empty'
$ntpcheckw = "WORKGROUP"
$ntpcheckstatus2 = "NO"
}else{
#echo 'ntp is not empty'
$ntpcheckd = "DOMAIN"
$ntpcheckstatus1 = "YES"
}


$getadapterip = Get-NetConnectionProfile -NetworkCategory 'DomainAuthenticated'
$getadapterip2 = $getadapterip.Name
#$getadapterip2

$getip= Get-NetConnectionProfile -Name $getadapterip2
$activeip = $getip.InterfaceAlias
$getip2 = (Get-NetIPAddress -AddressFamily IPV4 -InterfaceAlias $activeip).IPAddress
$ip = $getip2.split('.')
$count = $ip[3].length

#Check Hostname Vs IP 
$lastTwoCharsOfComputerName = $ENV:COMPUTERNAME.Substring($ENV:COMPUTERNAME.Length - $count)


    #Compare
    #$lastTwoCharsOfComputerName
    #$ip[3]

if($lastTwoCharsOfComputerName -eq $ip[3])
{
   #echo TRUE
   $nameipsame1 = "Passed- Naming Convention is OK"
   
} else {
   #echo FALSE
   $nameipsame2 = "Failed - Naming Convention is NOT OK"
}



# Network info
$networkadapter = Get-WMIObject win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled -eq $true } | select-object `ServiceName, Description, @{Name="IPAddress";Expression={$_.ipaddress}} , @{Name="Subnet";Expression={$_.ipsubnet}}, @{Name="IP_Gateway";Expression={$_.DefaultIPGateway}}, MACAddress | ConvertTo-Html
$netadapter = Get-NetAdapter | SELECT Name,InterfaceDescription,ifIndex,Status,MacAddress,LinkSpeed,fullduplex | where status -eq ‘up’ | ConvertTo-Html

Get-NetAdapter | SELECT Name,InterfaceDescription,ifIndex,Status,MacAddress,LinkSpeed,fullduplex | where status -eq ‘up’


#If Condition and Variables - VMWare

If ((Get-ComputerInfo).CsManufacturer -eq "VMware, Inc.") {
#echo TRUE

$vcentercheck = 'Ensure that your VMWAre Server is using the correct DataStore and Type according to its role. Check by logging into the VCenter Console'

#BDO Adapter
#BDO Adapter
$getadaptername = Get-NetConnectionProfile -NetworkCategory 'DomainAuthenticated'
$getadaptername2 = $getadaptername.Name
$getadapter= Get-NetConnectionProfile -Name $getadaptername2
$getadapter2 = $getadapter.InterfaceAlias
#$getadapter2
$getadapter3 = (Get-NetAdapter -Name $getadapter2).InterfaceDescription
$getadapter3

if($getadapter3 -eq 'vmxnet3 Ethernet Adapter') {
   #echo TRUE
   $getadapter4 = "Passed - Adapter detected is vmnext3"
   #$getadapter4
    } 

if($getadapter3 -eq 'vmxnet3 Ethernet Adapter #2') {
    #echo TRUE2
    $getadapter4 = "Passed - Adapter detected is vmnext3"
    }
    
if($getadapter3 -eq 'vmxnet3 Ethernet Adapter #3') {
    #echo TRUE3
    $getadapter4 = "Passed - Adapter detected is vmnext3"
    }    

 if($getadapter3 -eq 'E1000') {
    #echo FALSE
    $getadapter4 = "Failed - adapter s/b vmnext3"
    }        


#Other Adapter
$get2adaptername = Get-NetConnectionProfile -NetworkCategory 'Public'
$get2adaptername2 = $get2adaptername.Name
$get2adapter= Get-NetConnectionProfile -Name $get2adaptername2
$get2adapter2 = $get2adapter.InterfaceAlias
#$getadapter2
$get2adapter3 = (Get-NetAdapter -Name $get2adapter2).InterfaceDescription
#$getadapter3

if($getadapter3 -eq 'vmxnet3 Ethernet Adapter') {
   #echo TRUE
   $get2adapter4 = "Passed - Adapter detected is vmnext3"
   #$getadapter4
    } 

if($getadapter3 -eq 'vmxnet3 Ethernet Adapter #2') {
    #echo TRUE2
    $get2adapter4 = "Passed - Adapter detected is vmnext3"
    }
    
if($getadapter3 -eq 'vmxnet3 Ethernet Adapter #3') {
    #echo TRUE3
    $get2adapter4 = "Passed - Adapter detected is vmnext3"
    }    

 if($getadapter3 -eq 'E1000') {
    #echo FALSE
    $get2adapter4 = "Failed - adapter s/b vmnext3"
    }

} Else {
$nonvmware = 'Passed - VMWare requirement N/A'
$nonevcentercheck = 'Ensure that your AWS/AZURE Instance has assigned zones. . Check by logging into the AWS/AZ Console'
}


if($timezone -like '(UTC+08:00) Kuala Lumpur, Singapore')
    {
#   echo TRUE
   $timezonepass = "Passed"
   
    } else {
#   echo FALSE
   $timezonefail = "Failed - TimeZone s/b (UTC+08:00) Kuala Lumpur, Singapore"
   
    }


#AdminPWD.dll Checking

if (Test-Path "C:\Program Files\LAPS\CSE\AdmPwd.dll") {
   
$adminpwdtrue = "LAPS Enrollment Existing"
    
}
else {

#echo FALSE
$adminpwdfalse = "LAPS Enrollment Missing"
  
}

cls

#Check Disk Labels


$cvolume3 = $null
$cvolume4 = $null
$fvolume3 = $null
$fvolume4 = $null
$gvolume3 = $null
$gvolume4 = $null
$hvolume3 = $null
$hvolume4 = $null
$cvolume3 = $null
$cvolume4 = $null
$fvolume3 = $null
$fvolume4 = $null
$gvolume3 = $null
$gvolume4 = $null
$hvolume3 = $null
$hvolume4 = $null
$ivolume3 = $null
$ivolume4 = $null
$jvolume3 = $null
$jvolume4 = $null



$dbservice = 'SQLSERVERAGENT'
If (Get-Service $dbservice -ErrorAction SilentlyContinue)
{

#   echo "w/ Database"

$driveLetters= (Get-Volume).DriveLetter
#if ($driveLetters -contains "C" -and $driveLetters -contains "F" -and $driveLetters -contains "G" -and $driveLetters -contains "H")
if ($driveLetters -contains "C")
{

#echo 'C, F, G and H Exists'
#run script to check label here
$cvolume = Get-Volume -DriveLetter C
$cvolume2 = $cvolume.FileSystemLabel
#$cvolume2

if($cvolume2 -eq 'System')
    {
#   echo TRUE
   $cvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $cvolume4 = "Failed- vol label s/b 'System'"
   #$getadapter5
    }


$fvolume = Get-Volume -DriveLetter F
$fvolume2 = $fvolume.FileSystemLabel
#$fvolume2

if($fvolume2 -eq 'MSSQL_MDF')
    {
#   echo TRUE
   $fvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $fvolume4 = "Failed- vol label s/b 'MSSQL_MDF'"
   #$getadapter5
    }

$gvolume = Get-Volume -DriveLetter G
$gvolume2 = $gvolume.FileSystemLabel
#$gvolume2

if($gvolume2 -eq 'logs')
    {
#   echo TRUE
   $gvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $gvolume4 = "Failed- vol label s/b 'logs'"
   #$getadapter5
    }

$hvolume = Get-Volume -DriveLetter H
$hvolume2 = $hvolume.FileSystemLabel
#$hvolume2

if($hvolume2 -eq 'backup')
    {
#   echo TRUE
   $hvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $hvolume4 = "Failed- vol label s/b 'backup'"
   #$getadapter5
    }

$ivolume = Get-Volume -DriveLetter I
$ivolume2 = $ivolume.FileSystemLabel
#$ivolume2

if($ivolume2 -eq 'MSSQL_TEMP')
    {
#   echo TRUE
   $ivolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $ivolume4 = "Failed- vol label s/b 'MSSQL_TEMP'"
   #$getadapter5
    }


$jvolume = Get-Volume -DriveLetter J
$jvolume2 = $jvolume.FileSystemLabel
#$jvolume2

if($jvolume2 -eq 'MSSQL_LDF')
    {
#   echo TRUE
   $jvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $jvolume4 = "Failed- vol label s/b 'MSSQL_LDF'"
   #$getadapter5
    }
    
    } else {
$dbvolumeinc = 'Database Server : # of volume disks are incomplete please validate..'
}
     
} else {
#   echo No Database


$driveLetters= (Get-Volume).DriveLetter
#if ($driveLetters -contains "C" -and $driveLetters -contains "F" -and $driveLetters -contains "G" -and $driveLetters -contains "H" -and $driveLetters -contains "I"  -and $driveLetters -contains "J")
if ($driveLetters -contains "C")
{

#echo 'C, F, G and H Exists'
#run script to check label here
$cvolume = Get-Volume -DriveLetter C
$cvolume2 = $cvolume.FileSystemLabel
#$cvolume2

if($cvolume2 -eq 'System')
    {
#   echo TRUE
   $cvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $cvolume4 = "Failed- vol label s/b 'System'"
   #$getadapter5
    }


$fvolume = Get-Volume -DriveLetter F
$fvolume2 = $fvolume.FileSystemLabel
#$fvolume2

if($fvolume2 -eq 'appdir')
    {
#   echo TRUE
   $fvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $fvolume4 = "Failed- vol label s/b 'appdir'"
   #$getadapter5
    }

$gvolume = Get-Volume -DriveLetter G
$gvolume2 = $gvolume.FileSystemLabel
#$gvolume2

if($gvolume2 -eq 'logs')
    {
#   echo TRUE
   $gvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $gvolume4 = "Failed- vol label s/b 'logs'"
   #$getadapter5
    }

$hvolume = Get-Volume -DriveLetter H
$hvolume2 = $hvolume.FileSystemLabel
#$hvolume2

if($hvolume2 -eq 'backup')
    {
#   echo TRUE
   $hvolume3 = "Passed"
   #$getadapter4
    } else {
#   echo FALSE
   $hvolume4 = "Failed- vol label s/b 'backup'"
   #$getadapter5
    } 




    } else {
$appvolumeinc = 'Apps Server : # of volume disks are incomplete please validate..'

}
}

#Average CPU Utilization
$AVGProc = Get-WmiObject -computername $computername win32_processor | Measure-Object -property LoadPercentage -Average | Select Average


#Average Memory Utilization
$OS = gwmi -Class win32_operatingsystem -computername $computername | Select-Object @{Name = "MemoryUsage"; Expression = {“{0:N2}” -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }}


#Logical Disk Capacity and Free space
$Disks = Get-WmiObject -Class Win32_LogicalDisk -Filter ‘DriveType=3’ | Select DeviceID, VolumeName, @{Name="Freespace (GB)"; Expression={[math]::round($_.Freespace/1GB, 2)}}, @{Name = 'Freespace (%)';Expression = {"{0:N0}%" -f (($_.FreeSpace/$_.Size) * 100)}}, @{Name="Capacity (GB)"; Expression={[math]::round($_.size/1GB, 2)}} | ConvertTo-Html
$DisksLUN = Get-PhysicalDisk | Select FriendlyName, MediaType | ConvertTo-Html


#Get CPU Socket and Core Info
$cs = Get-WmiObject -class Win32_ComputerSystem
$Sockets = $cs.numberofprocessors
$Cores = $cs.numberoflogicalprocessors

#Get Memory Info
$InstalledRAM = systeminfo | findstr /C:"Total Physical Memory"
$FreeRAM = systeminfo |findstr /C:"Available Physical Memory"

#GetLocalUserLists
$locallist = Get-LocalUser | Select Name,Enabled,Description,PasswordExpires | ConvertTo-Html
$localadmin = Get-LocalGroupMember -Name Administrators | ConvertTo-Html

#Check for latest Windows Updates / Hotfix Installed

$computername = hostname.exe
#$lastpatch1 = Get-HotFix -ComputerName $computername | Select-Object PSComputerName,HotFixID,Description,InstalledBy,InstalledOn
#$lastpatch = Get-WmiObject Win32_Quickfixengineering | select @{Name="InstalledOn";Expression={$_.InstalledOn -as [datetime]}} | Sort-Object -Property Installedon | select-object -property installedon -last 1

$lastpatchcsv = Get-Hotfix | Sort-Object -Descending -Property InstalledOn
$lastpatchhtml = Get-Hotfix | Sort-Object -Descending -Property InstalledOn | ConvertTo-Html
$lastpatch1 = Get-Date -UFormat "%B %Y"
$hotfixstatus = "Refer to Hotfix HTML and CSV Report"


#Scheduled Tasks

$schedtasks = Get-ChildItem -Path c:\windows\system32\Tasks | Select Name,Exists,CreationTime,LastWriteTime | ConvertTo-Html

#EventLog Critical Errors

$appevents = Get-EventLog -LogName Application -Newest 5 -EntryType Error | Select EventID,TimeGenerated,TimeWritten,Message | ConvertTo-Html
$systemevents = Get-EventLog -LogName System -Newest 5 -EntryType Error | Select EventID,TimeGenerated,TimeWritten,Message | ConvertTo-Html


## If Server is AWS
If ((Get-ComputerInfo).CsManufacturer -eq "Amazon EC2") {}

## If Server is AZURE
If ((Get-ComputerInfo).CsManufacturer -eq "Microsoft Corporation") {}



#Reset conditional variables
$osmemfail = $null
$osmempass1 = $null
$procfail = $null
$procpass = $null
$sepstatus3 = $null
$sepstatus4 = $null
$crowdstatus3 = $null
$crowdstatus4 = $null
$mpsstatus2 = $null
$mpsstatuspass = $null
$mpsstatusfail = $null
$fwstatus2 = $null
$fwstatusfail = $null
$fwstatuspass = $null
$rdptestfail = $null
$rdptestpass = $null


#Enable and Check for PS Remoting BareMetal/VMWare


If ((Get-WmiObject win32_computersystem).manufacturer -eq "VMware, Inc.") {

#Enable and Check for PS Remoting BareMetal/VMWare

If ((Test-WSMan).ProductVendor -eq "Microsoft Corporation")
{
#"Same"
$psremote = "Enabled"
}else{
#"not same"

    #Check for Inbound Rule

    $r = Get-NetFirewallRule -DisplayName 'WinRM Connection' 2> $null; 
    if ($r) { 
            # write-host "found it"; 
            } 
    else { 
            #write-host "did not find it" 
        $ips = @("10.71.52.63", "172.16.202.248", ”172.16.209.58”, ”172.16.165.42”, ”172.16.165.41”)
        New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -RemoteAddress $ips -LocalPort 5985, 5986 -Protocol TCP -Action Allow
        #New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -LocalPort 5985, 5986 -Protocol TCP -Action Allow
         }
     
    enable-psremoting -force
    winrm quickconfig
   $psremote = "Enabled"
}

}else{

#Enable and Check for PS Remoting BareMetal/VMWare

If ((Test-WSMan).ProductVendor -eq "Microsoft Corporation")
{
#"Same"
$psremote = "Enabled"
}else{
#"not same"

    #Check for Inbound Rule

    $r = Get-NetFirewallRule -DisplayName 'WinRM Connection' 2> $null; 
    if ($r) { 
            # write-host "found it"; 
            } 
    else { 
            #write-host "did not find it" 
        $ips = @("10.71.52.63", "172.16.202.248", ”172.16.209.58”, ”172.16.165.42”, ”172.16.165.41”)
        New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -RemoteAddress $ips -LocalPort 5985, 5986 -Protocol TCP -Action Allow
        #New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -LocalPort 5985, 5986 -Protocol TCP -Action Allow
         }
     
    enable-psremoting -force
    winrm quickconfig
   $psremote = "Enabled"
}
}



#Enable and Check for PS Remoting Azure

If ((Get-WmiObject win32_computersystem).manufacturer -eq "Microsoft Corporation") {

#Enable and Check for PS Remoting BareMetal/VMWare

If ((Test-WSMan).ProductVendor -eq "Microsoft Corporation")
{
#"Same"
$psremote = "Enabled"
}else{
#"not same"

    #Check for Inbound Rule

    $r = Get-NetFirewallRule -DisplayName 'WinRM Connection' 2> $null; 
    if ($r) { 
            # write-host "found it"; 
            } 
    else { 
            #write-host "did not find it" 
        $ips = @("10.61.0.8", "10.60.0.113")
        New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -RemoteAddress $ips -LocalPort 5985, 5986 -Protocol TCP -Action Allow
        #New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -LocalPort 5985, 5986 -Protocol TCP -Action Allow
         }
     
    enable-psremoting -force
    winrm quickconfig
   $psremote = "Enabled"
}

}else{}


#Enable and Check for PS Remoting AWS

If ((Get-WmiObject win32_computersystem).manufacturer -eq "Amazon EC2") {

#Enable and Check for PS Remoting BareMetal/VMWare

If ((Test-WSMan).ProductVendor -eq "Microsoft Corporation")
{
#"Same"
$psremote = "Enabled"
}else{
#"not same"

    #Check for Inbound Rule

    $r = Get-NetFirewallRule -DisplayName 'WinRM Connection' 2> $null; 
    if ($r) { 
            # write-host "found it"; 
            } 
    else { 
            #write-host "did not find it" 
        $ips = @("10.61.0.8", "10.60.0.113")
        New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -RemoteAddress $ips -LocalPort 5985, 5986 -Protocol TCP -Action Allow
        #New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -LocalPort 5985, 5986 -Protocol TCP -Action Allow
         }
     
    enable-psremoting -force
    winrm quickconfig
   $psremote = "Enabled"
}

}else{}
 


#Check for PAM Account
$dname1 = (Get-WmiObject -Class win32_ComputerSystem).Domain

if($dname1 -eq "WORKGROUP")
{
    #echo TRUE
    #Workgroup Server

    $op = Get-LocalUser | where-Object Name -eq "p_pam_admin1" | Measure
    if ($op.Count -eq 0) {
    
    #echo missing
    $pamaccount2 = "Failed - missing enrollment"
    } else {
    $pamaccount = "Passed w/ pam id - process for Enrollment"
     # REPORT SOMETHING
    }
       
} else {
    #echo FALSE
    #Domain Joined

    $op2 = Get-LocalUser | where-Object Name -like "UP-BTPAM-*" | Measure
    if ($op2.Count -eq 0) {
    #echo missing
    $pamaccount3 = "Failed missing enrollment"
    } else {
    $pamaccount4 = "Passed added group process for PAM Enrollment"
     # REPORT SOMETHING
}
}


#Check if Database Server
$dbservice = 'SQLSERVERAGENT'
If (Get-Service $dbservice -ErrorAction SilentlyContinue)
{
   # echo noexist
   $dbstatus = "No"
   $dbstatus3 = "N/A"
   $dbcheck = "Database Server"
} else {
   # echo exist
   $dbstatus2 = "Yes"
   $dbcheck1 = "Application/Web/File Server"
 
}

#$dbstatusv = Invoke-Sqlcmd -Query "SELECT @@VERSION;" -QueryTimeout 3


#Check if Database Service is Running
$dbservice = 'SQLSERVERAGENT'

If (Get-Service $dbservice -ErrorAction SilentlyContinue) {

    If ((Get-Service $dbservice).Status -eq 'Running') {

        $dbservice1="Passed - Installed and Running"

                                                        } Else {

#        Write-Host "$serviceName found, but it is not running."
        $dbservice2="Stopped"

                                                                }

                                                           } Else {

#    Write-Host "$serviceName not found"
        $dbservice2="Stopped"

                                                                   }


#If Condition Cluster Service

$cluserviceName = 'ClusSvc'

If (Get-Service $cluserviceName -ErrorAction SilentlyContinue) {

    If ((Get-Service $cluserviceName).Status -eq 'Running') {

#        Stop-Service $serviceName
#        Write-Host "Service is Running"
        $clustatus="Passed - Installed and Running"

    } Else {

#        Write-Host "$serviceName found, but it is not running."
        $clustatus2="Not active"

    }

} Else {

#    Write-Host "$serviceName not found"
        $clustatus2="Not active"

}



#If Condition and Variables - VMWare

#If ((Get-ComputerInfo).CsModel -eq "VMware Virtual Platform") {
#                                                            }  Else {
#
#                                                            #echo FALSE
#
#                                                                    } 
$vmserviceName = 'VMTools'
If (Get-Service $vmserviceName -ErrorAction SilentlyContinue) {
        
        If ((Get-Service $vmserviceName).Status -eq 'Running') {

        $vmstatus="Passed - Installed and Running"

        } Else {

        #        Write-Host "$serviceName found, but it is not running."
        $vmstatus2="Missing - Fail"

                }

        } Else {

        #    Write-Host "$serviceName not found"
        $vmstatus2="Missing - Fail"

       }

$vmtoolversion = gwmi -class win32_product -filter "name='VMware Tools'" | select version
    # $vmversion = & "C:\Program Files\VMware\VMware Tools\vmtoolsd.exe" -v


#If Condition and Variables
$OS = gwmi -Class win32_operatingsystem -computername $computername | Select-Object @{Name = "MemoryUsage"; Expression = {“{0:N2}” -f ((($_.TotalVisibleMemorySize - $_.FreePhysicalMemory)*100)/ $_.TotalVisibleMemorySize) }}

If ($OS.MemoryUsage -gt "50") {
$osmemfail="Failed - for verification"
  }
  else
  {
$osmempass1="Passed"
} 

If ($AVGProc.Average -gt "50") {
$procfail="Failed - for verification"
  }
  else
  {
$procpass="Passed"
}


#Check Crowd Strike Service if existing

$serviceName = 'CSFalconService'

If (Get-Service $serviceName -ErrorAction SilentlyContinue) {

    If ((Get-Service $serviceName).Status -eq 'Running') {

$crowdstatus4="Passed - Installed and Running"

    } Else {

#        Write-Host "$serviceName found, but it is not running."
        $crowdstatus3="Missing - Fail"

    }

} Else {

#    Write-Host "$serviceName not found"
    $crowdstatus3="Missing - Fail"

}


#Check Crowd Strike Service if existing

$splunkname = 'SplunkForwarder'
If (Get-Service $splunkname -ErrorAction SilentlyContinue) {
$splunkstatus="Passed - Installed"
} Else {
#    Write-Host "$serviceName not found"
$splunkstatus2="Failed - Missing"
}


If ((Get-Service $splunkname).Status -eq 'Running') {
$splunkstatus3="Status - Running"
    } Else {
$splunkstatus4="Failed - Stopped"
    }




#If Condition SEP

$serviceName = 'SepMasterService'

If (Get-Service $serviceName -ErrorAction SilentlyContinue) {

    If ((Get-Service $serviceName).Status -eq 'Running') {

#        Stop-Service $serviceName
#        Write-Host "Service is Running"
$sepstatus4="Passed - Installed and Running"

    } Else {

#        Write-Host "$serviceName found, but it is not running."
        $sepstatus3="Missing - Fail"

    }

} Else {

#    Write-Host "$serviceName not found"
    $sepstatus3="Missing - Fail"

}


#Check FW Service
$mpsstatus = Get-Service MpsSvc | Select Status
$mpsstatus2 = $mpsstatus.status

#If Condition FW
If ($mpsstatus2 -eq 'Running') {
$mpsstatuspass="Passed"
  }  Else {
$mpsstatusfail="Failed"
} 

#Check FW Status
$fwstatus = Get-NetFirewallProfile -name Domain
$fwstatus2 = $fwstatus.enabled

#If Condition FW
If ($fwstatus2 -eq 'False') {
$fwstatuspass="Passed"
$fwdomainstatus="turned off"
#Write-Host = TRUE
  }  Else {
$fwstatusfail="Failed - must be turned off"
$fwdomainstatus2="turned on"
#Write-Host = FALSE
} 

#Remote Desktop Connection Test 3389
$ipaddress = hostname.exe
$port = 3389
$connection = New-Object System.Net.Sockets.TcpClient($ipaddress, $port)
if ($connection.Connected) {
    $connectionsuccess="Success"
}
else {
    $connectionfailed="Failed"
}

#If Condition RDP
If ($connection.Connected -eq 'Success') {
$rdptestpass="Passed"
  }  Else {
$rdptestfail="Failed"
} 


#Solarwinds Ports TCP 135,445,49152

$135 = Test-NetConnection -ComputerName $hostip -Port 135
$135t = $135.TcpTestSucceeded

If ($135.TcpTestSucceeded -eq 'True') {
$135fail="Passed"
  }  Else {
$135pass="Failed"
} 


$445 = Test-NetConnection -ComputerName $hostip -Port 445
$445t = $445.TcpTestSucceeded

If ($445.TcpTestSucceeded -eq 'True') {
$445fail="Passed"
  }  Else {
$445pass="Failed"
} 


#$49152 = Test-NetConnection -ComputerName $hostip -Port 49152
#$49152t = $49152.TcpTestSucceeded

#If ($49152.TcpTestSucceeded -eq 'True') {
#$49152fail="Passed"
#  }  Else {
#$49152pass="Failed"
#} 




#Bacula Comm Test

## If Server is VMWare
If ((Get-ComputerInfo).CsManufacturer -eq "VMware, Inc.") {

$getadapterip = Get-NetConnectionProfile -NetworkCategory 'DomainAuthenticated'
$getadapterip2 = $getadapterip.Name
#$getadapterip2

$getip= Get-NetConnectionProfile -Name $getadapterip2
$activeip = $getip.InterfaceAlias
$getip2 = (Get-NetIPAddress -AddressFamily IPV4 -InterfaceAlias $activeip).IPAddress
$ip = $getip2.split('.')
$count = $ip[1].length

#IP assign
$vpcsite1="46" 
$vpcsite2="71"

if($vpcsite1 -eq $ip[1]){
route -p add 10.5.0.0/20 10.72.12.1
 $mkt = Test-NetConnection -ComputerName 10.5.7.2 -Port 9102
 $mktt = $mkt.TcpTestSucceeded

 If ($mkt.TcpTestSucceeded -eq 'True') {
 $mktpass="MDC: Passed"
   }  Else {
 $mktfail="MDC: Failed"
 } 
 }

if($vpcsite2 -eq $ip[1]){
route -p add 10.72.4.0/23 10.72.12.1

 $gdc = Test-NetConnection -ComputerName 10.72.4.180 -Port 9102
 $gdct = $gdc.TcpTestSucceeded

 If ($gdc.TcpTestSucceeded -eq 'True') {
 $gdcpass="GDC: Passed"
   }  Else {
 $gdcfail="GDC: Failed"
 }
 }
 }
 

## If Server is AWS
If ((Get-ComputerInfo).CsManufacturer -eq "Amazon EC2") {
$mktpass="N/A"
$gdcpass="N/A"
}
## If Server is AZURE
If ((Get-ComputerInfo).CsManufacturer -eq "Microsoft Corporation") {
$mktpass="N/A"
$gdcpass="N/A"
}

 

#Generate HTML Report - for VMWare Servers

If ((Get-WmiObject win32_computersystem).manufacturer -eq "VMware, Inc.") {
##echo TRUE

$Outputreport ="<HTML>
<style>
table, th, td {
border: 1px solid black;
}
</style>

<title>Release to Production Compliance Report</title>
                
<table>
<tr/><td style='text-align:center;'><B>Date</B>: $date<td/>
<tr/>
<tr>
<font color =""#99000"" face=""Microsoft Tai le""><H1 style='text-align:center;'>Engagement Initial Review</H1></font></tr></table>
<table>
<H5><font face=""Microsoft Tai le""><u>$vcentercheck$nonevcentercheck</u></font></H5>
</table>

<table>
<tr><td/><b>Platform: </b><td/>$IsVirtual
<tr><td/><b>Server Role: </b><td/>$dbcheck$dbcheck1
</table>

<table>
<font color =""#FF0000"" face=""Microsoft Tai le"">
<H4>Items with Downtime</H4></font>
<tr><td/><b>Hostname: </b>$computername<td/><font color=""#008000"" face=""Microsoft Tai le"">$nameipsame1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$nameipsame2</font></tr>
<tr><td/><b>IP Address: </b>$hostip<td/></tr>
<tr><td/><b>Disk Label Details</b></tr>
<tr><td/><b>&nbsp;&nbsp;C</b>: $cvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$cvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$cvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspF</b>: $fvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$fvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$fvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspG</b>: $gvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$gvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$gvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspH</b>: $hvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$hvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$hvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspI (DB)</b>: $ivolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$ivolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$ivolume4</font></tr>
<tr><td/><b>&nbsp;&nbspJ (DB)</b>: $jvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$jvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$jvolume4</font></tr>
<tr><td/><b>NIC Adapters</b></tr>
<tr><td/><b>&nbsp;&nbspBDO LAN</b><td/><font color=""#008000"" face=""Microsoft Tai le"">$nonvmware$getadapter4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$getadapter5</font></tr>
<tr><td/><b>&nbsp;&nbspBackup</b><td/><font color=""#008000"" face=""Microsoft Tai le"">$nonvmware$get2adapter4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$get2adapter5</font></tr>
<tr><td/><b>Windows Patches</b><td/><font color=""#0000FF"" face=""Microsoft Tai le"">$hotfixstatus</font></tr>
</table>
<table>
<font color =""#FF0000"" face=""Microsoft Tai le"">
<H4>Items with No Downtime</H4></font>
<tr/><td/>Time Zone s/b (UTC+08:00) Kuala Lumpur, Singapore: <td/><font color=""#008000"" face=""Microsoft Tai le"">$timezonepass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$timezonefail</font>
<tr><td/><b>NTP Details</b></tr>
<tr/><td/>&nbsp;&nbsp;Type of Connection<td/>$ntpcheckd$ntpcheckw
<tr/><td/>&nbsp;&nbsp;Synced to Domain?<td/><font color=""#008000"" face=""Microsoft Tai le"">$ntpcheckstatus1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$ntpcheckstatus2</font>
<tr/><td/>&nbsp;&nbsp;NTP Source<td/>$ntpssource
<tr/><td/>&nbsp;&nbsp;NTP Last Sync<td/>$ntpssync
<tr/><td>Remote Connection Port TCP 3389 Conection Test $rdptest <td/><font color=""#008000"" face=""Microsoft Tai le"">$rdptestpass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$rdptestfail</font>
<tr><td/><b>Utilization</b></tr>
<tr/><td/>&nbsp;&nbsp;CPU Utilization: $($AVGProc.Average)% <td/><font color=""#008000"" face=""Microsoft Tai le"">$procpass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$procfail</font>
<tr/><td/>&nbsp;&nbsp;RAM Utilization: $($OS.MemoryUsage)% <td/><font color=""#008000"" face=""Microsoft Tai le"">$osmempass1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$osmemfail</font>
<tr/><td/><b>Windows Firewall</b></tr>
<tr/><td/>&nbsp;&nbsp;Windows Firewall Service is $mpsstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$mpsstatuspass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$mpsstatusfail</font>
<tr/><td/>&nbsp;&nbsp;Windows Firewall Domain Profile is $fwdomainstatus$fwdomainstatus2<td/><font color=""#008000"" face=""Microsoft Tai le"">$fwstatuspass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$fwstatusfail</font>
<tr/><td/><b>Security</b></tr>
<tr/><td/>&nbsp;&nbsp;CrowdStrike Falcon Sensor Installed: $crowdstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$crowdstatus4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$crowdstatus3</font>
<tr/><td/>&nbsp;&nbsp;Symantec Installed: $sepstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$sepstatus4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$sepstatus3</font>
<tr/><td/>&nbsp;&nbsp;Splunk Installed: <td/><font color=""#008000"" face=""Microsoft Tai le"">$splunkstatus $splunkstatus3</font><font color=""#FF0000"" face=""Microsoft Tai le"">$splunkstatus2 $splunkstatus4</font>
<tr/><td/>&nbsp;&nbsp;PAM Enrollment: <td/><font color=""#008000"" face=""Microsoft Tai le"">$pamaccount$pamaccount4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$pamaccount2$pamaccount3</font>
<tr/><td/><b>Backup Monitoring</b></tr>
<tr/><td/>Solarwinds:
<tr/><td/>&nbsp;&nbsp;Port TCP 135 Conection Test<td/><font color=""#008000"" face=""Microsoft Tai le"">$135pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$135fail</font>
<tr/><td/>&nbsp;&nbsp;Port TCP 445  Conection Test<td/><font color=""#008000"" face=""Microsoft Tai le"">$445pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$445fail</font>
<tr/><td/>Bacula:
<tr/><td/>&nbsp;&nbsp;Port TCP 9102 Conection Test <td/><font color=""#008000"" face=""Microsoft Tai le"">$gdcpass</font> <font color=""#008000"" face=""Microsoft Tai le"">$mktpass</font><font color=""#FF0000"" face=""Microsoft Tai le"">$gdcfail</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$mktfail</font>
<tr/><td/>&nbsp;&nbsp;Port TCP 9102 Conection Test <td/><font color=""#008000"" face=""Microsoft Tai le"">$gdc2pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$mkt2pass</font><font color=""#FF0000"" face=""Microsoft Tai le"">$gdc2fail</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$mk2tfail</font>
<tr/><td/>PS Remote: <td/><font color=""#008000"" face=""Microsoft Tai le"">$psremote</font> <font color=""#FF0000"" face=""Microsoft Tai le""></font>
<tr/><td/>LAPS Requirement: <td/><font color=""#008000"" face=""Microsoft Tai le"">$adminpwdtrue</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$adminpwdfalse</font>
<tr/><td/>

 </Table>                     

</table>


<table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>General Information</H4></font>
                <tr><td/><b>Hostname: </b>$computername</tr>
                <tr><td/><b>Manufacturer: </b>$IsVirtual</tr>
                <tr><td/><b>IP Address: </b>IP Address: $hostip</tr>
                <tr><td/><b>Gateway </b>IP Gateway: $hostgateway</tr>
                <tr><td/><b>Domain: </b>$dname</tr>
                <tr><td/><b>Operating System: </b>$osname</tr>
                <tr><td/><b>Operating System Installation Date: </b>$osdate</tr>
                <tr><td/><b>Edition: </b>$edition</tr>
                <tr><td/><b>Processor Model: </b>$processormodel</tr>
                <tr><td/><b>Processor Model: </b>$processorsystem</tr>
                <tr><td/><b>Build: </b>$buildnumber</tr>
                <tr><td/><b>Architecture: </b>$architecture</tr>
                <tr><td/><b>OS Language: </b>$oslanguange</tr>
                <tr><td/><b>OS version: </b>$osversion</tr>
                <tr><td/><b>OS LastReboot: </b>$oslastBoot</tr>
                <tr><td/><b>OS Uptime: </b>$osuptime</tr>
                <tr><td/><b>Regional Settings: </b>$systemlocale</tr>
                <tr><td/><b>Timezone: </b>$timezone</tr>
                <tr><td/><b>With Database?: </b>$dbstatus$dbstatus2</tr>
                       
 </Table>

<Table>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4>CPU and Utilization &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; RAM and Utilization</H4></font>
                   
                    <tr>
                   <tr><TD><B>CPU Sockets</B>: $Sockets</TD><TD>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>RAM Installed</B>: $InstalledRAM</TD></tr>
                   <tr><TD><B>CPU Cores</B>: $Cores</TD><TD>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>RAM Free</B>: $FreeRAM</TD></tr>
                                      

</Table>
   <table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>Fail Over Cluster Service Check</H4></font>
                <tr/><td>Cluster Service - <font color=""#FF0000"" face=""Microsoft Tai le"">$clustatus2</font> <font color=""#008000"" face=""Microsoft Tai le"">$clustatus</font><td/>
  </Table>                                                                         
                   <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Disk and Utilization</H4></font>
                   $Disks

                   <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Disk and Datastore</H4></font>
                   $DisksLUN
                   
                    <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Network Adapters Set</H4></font>
                   $networkadapter                 
                   $netadapter
  </Table>


   <table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>VMWare Tools (applies ony to VMWare Servers)</H4></font>
                <tr/><td>Service VmWare Tools - <font color=""#FF0000"" face=""Microsoft Tai le"">$vmstatus2</font> <font color=""#008000"" face=""Microsoft Tai le"">$vmstatus</font><td/>
                <tr/><td>Version - $vmtoolversion<td/>
  </Table>
  <Table>
          
              <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Scheduled Tasks</H4></font>
                   $schedtasks
          
                
  </Table>

         
       
           <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Local Accounts</H4></font>
                   $locallist
                   $localadmin
              
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> HotFix Results</H4></font>
                   $lastpatchhtml                                     
          
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Application Critical Event Logs</H4></font>
                   $appevents
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> System Critical Logs</H4></font>
                   $systemevents
                            
    
                   </HTML>"

                                                            }  Else {

#HTML Report for Non VmWAre CI

$Outputreport ="<HTML>
<style>
table, th, td {
border: 1px solid black;
}
</style>

<title>Release to Production Compliance Report</title>
                
<table>
<tr/><td style='text-align:center;'><B>Date</B>: $date<td/>
<tr/>
<tr>
<font color =""#99000"" face=""Microsoft Tai le""><H1 style='text-align:center;'>Engagement Initial Review</H1></font></tr></table>
<table>
<H5><font face=""Microsoft Tai le""><u>$vcentercheck$nonevcentercheck</u></font></H5>
</table>

<table>
<tr><td/><b>Platform: </b><td/>$IsVirtual
<tr><td/><b>Server Role: </b><td/>$dbcheck$dbcheck1
</table>

<table>
<font color =""#FF0000"" face=""Microsoft Tai le"">
<H4>Items with Downtime</H4></font>
<tr><td/><b>Hostname: </b>$computername<td/><font color=""#008000"" face=""Microsoft Tai le"">$nameipsame1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$nameipsame2</font></tr>
<tr><td/><b>IP Address: </b>$hostip<td/></tr>
<tr><td/><b>Disk Label Details</b></tr>
<tr><td/><b>&nbsp;&nbsp;C</b>: $cvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$cvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$cvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspF</b>: $fvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$fvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$fvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspG</b>: $gvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$gvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$gvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspH</b>: $hvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$hvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$hvolume4</font></tr>
<tr><td/><b>&nbsp;&nbspI (DB)</b>: $ivolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$ivolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$ivolume4</font></tr>
<tr><td/><b>&nbsp;&nbspJ (DB)</b>: $jvolume2<td/><font color=""#008000"" face=""Microsoft Tai le"">$jvolume3</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$jvolume4</font></tr>
<tr><td/><b>NIC Adapters</b></tr>
<tr><td/><b>&nbsp;&nbspBDO LAN</b><td/><font color=""#008000"" face=""Microsoft Tai le"">$nonvmware$getadapter4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$getadapter5</font></tr>
<tr><td/><b>&nbsp;&nbspBackup</b><td/><font color=""#008000"" face=""Microsoft Tai le"">$nonvmware$get2adapter4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$get2adapter5</font></tr>
<tr><td/><b>Windows Patches</b><td/><font color=""#0000FF"" face=""Microsoft Tai le"">$hotfixstatus</font></tr>
</table>
<table>
<font color =""#FF0000"" face=""Microsoft Tai le"">
<H4>Items with No Downtime</H4></font>
<tr/><td/>Time Zone s/b (UTC+08:00) Kuala Lumpur, Singapore: <td/><font color=""#008000"" face=""Microsoft Tai le"">$timezonepass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$timezonefail</font>
<tr><td/><b>NTP Details</b></tr>
<tr/><td/>&nbsp;&nbsp;Type of Connection<td/>$ntpcheckd$ntpcheckw
<tr/><td/>&nbsp;&nbsp;Synced to Domain?<td/><font color=""#008000"" face=""Microsoft Tai le"">$ntpcheckstatus1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$ntpcheckstatus2</font>
<tr/><td/>&nbsp;&nbsp;NTP Server Connection<td/>$ntps
<tr/><td>Remote Connection Port TCP 3389 Conection Test $rdptest <td/><font color=""#008000"" face=""Microsoft Tai le"">$rdptestpass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$rdptestfail</font>
<tr><td/><b>Utilization</b></tr>
<tr/><td/>&nbsp;&nbsp;CPU Utilization: $($AVGProc.Average)% <td/><font color=""#008000"" face=""Microsoft Tai le"">$procpass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$procfail</font>
<tr/><td/>&nbsp;&nbsp;RAM Utilization: $($OS.MemoryUsage)% <td/><font color=""#008000"" face=""Microsoft Tai le"">$osmempass1</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$osmemfail</font>
<tr/><td/><b>Windows Firewall</b></tr>
<tr/><td/>&nbsp;&nbsp;Windows Firewall Service is $mpsstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$mpsstatuspass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$mpsstatusfail</font>
<tr/><td/>&nbsp;&nbsp;Windows Firewall Domain Profile is $fwstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$fwstatuspass</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$fwstatusfail</font>
<tr/><td/><b>Security</b></tr>
<tr/><td/>&nbsp;&nbsp;CrowdStrike Falcon Sensor Installed: $crowdstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$crowdstatus4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$crowdstatus3</font>
<tr/><td/>&nbsp;&nbsp;Symantec Installed: $sepstatus2 <td/><font color=""#008000"" face=""Microsoft Tai le"">$sepstatus4</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$sepstatus3</font>
<tr/><td/>&nbsp;&nbsp;Splunk Installed: <td/><font color=""#008000"" face=""Microsoft Tai le"">$splunkstatus $splunkstatus3</font><font color=""#FF0000"" face=""Microsoft Tai le"">$splunkstatus2 $splunkstatus4</font>
<tr/><td/>&nbsp;&nbsp;PAM Enrollment: <td/><font color=""#008000"" face=""Microsoft Tai le"">$pamaccount</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$pamaccount2</font>
<tr/><td/><b>Backup Monitoring</b></tr>
<tr/><td/>Solarwinds:
<tr/><td/>&nbsp;&nbsp;Port TCP 135 Conection Test<td/><font color=""#008000"" face=""Microsoft Tai le"">$135pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$135fail</font>
<tr/><td/>&nbsp;&nbsp;Port TCP 445  Conection Test<td/><font color=""#008000"" face=""Microsoft Tai le"">$445pass</font> <font color=""#008000"" face=""Microsoft Tai le"">$445fail</font>
<tr/><td/>PS Remote: <td/><font color=""#008000"" face=""Microsoft Tai le"">$psremote</font> <font color=""#FF0000"" face=""Microsoft Tai le""></font>
<tr/><td/>LAPS Requirement: <td/><font color=""#008000"" face=""Microsoft Tai le"">$adminpwdtrue</font> <font color=""#FF0000"" face=""Microsoft Tai le"">$adminpwdfalse</font>
<tr/><td/>

 </Table>                     

</table>


<table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>General Information</H4></font>
                <tr><td/><b>Hostname: </b>$computername</tr>
                <tr><td/><b>Manufacturer: </b>$IsVirtual</tr>
                <tr><td/><b>IP Address: </b>IP Address: $hostip</tr>
                <tr><td/><b>Gateway </b>IP Gateway: $hostgateway</tr>
                <tr><td/><b>Domain: </b>$dname</tr>
                <tr><td/><b>Operating System: </b>$osname</tr>
                <tr><td/><b>Operating System Installation Date: </b>$osdate</tr>
                <tr><td/><b>Edition: </b>$edition</tr>
                <tr><td/><b>Processor Model: </b>$processormodel</tr>
                <tr><td/><b>Processor Model: </b>$processorsystem</tr>
                <tr><td/><b>Build: </b>$buildnumber</tr>
                <tr><td/><b>Architecture: </b>$architecture</tr>
                <tr><td/><b>OS Language: </b>$oslanguange</tr>
                <tr><td/><b>OS version: </b>$osversion</tr>
                <tr><td/><b>OS LastReboot: </b>$oslastBoot</tr>
                <tr><td/><b>OS Uptime: </b>$osuptime</tr>
                <tr><td/><b>Regional Settings: </b>$systemlocale</tr>
                <tr><td/><b>Timezone: </b>$timezone</tr>
                <tr><td/><b>With Database?: </b>$dbstatus$dbstatus2</tr>
                       
 </Table>

<Table>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4>CPU and Utilization &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; RAM and Utilization</H4></font>
                   
                    <tr>
                   <tr><TD><B>CPU Sockets</B>: $Sockets</TD><TD>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>RAM Installed</B>: $InstalledRAM</TD></tr>
                   <tr><TD><B>CPU Cores</B>: $Cores</TD><TD>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<B>RAM Free</B>: $FreeRAM</TD></tr>
                                      

</Table>
   <table>
                 <font color =""#99000"" face=""Microsoft Tai le"">
                 <H4>Fail Over Cluster Service Check</H4></font>
                <tr/><td>Cluster Service - <font color=""#FF0000"" face=""Microsoft Tai le"">$clustatus2</font> <font color=""#008000"" face=""Microsoft Tai le"">$clustatus</font><td/>
  </Table>                                                                         
                   <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Disk and Utilization</H4></font>
                   $Disks

                   <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Disk and Datastore</H4></font>
                   $DisksLUN
                   
                    <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Network Adapters Set</H4></font>
                   $networkadapter                 
                   $netadapter
  </Table>
      
  <Table>
          
              <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Scheduled Tasks</H4></font>
                   $schedtasks
          
                
  </Table>

         
       
           <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Local Accounts</H4></font>
                   $locallist
                   $localadmin
              
              
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> HotFix Results</H4></font>
                   $lastpatchhtml                           
          
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> Application Critical Event Logs</H4></font>
                   $appevents
          <body/>
                   <font color =""#99000"" face=""Microsoft Tai le"">
                   <H4> System Critical Logs</H4></font>
                   $systemevents
                            
    
                   </HTML>"
##echo FALSE

                                                                    } 
    # }


#Windows Baseline fixes

#base# rem ####### Disabling Unrequired Services
#base# sc config TrkWks start= disabled
#base# sc config Browser start= disabled
#base# sc config RasMan start= disabled
#base# sc config ShellHWDetection start= disabled
#base# sc config TapiSrv start= disabled
#base# sc config AudioEndpointBuilder start= disabled
#base# sc config AudioSrv start= disabled
#base# sc config dot3svc start= disabled
#base# sc config hidserv start= disabled

#base# rem ####### Triple DES
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\Triple DES 168" /v Enabled /t REG_DWORD /d 0 /f
#base# rem ####### Cache logon
#base# rem ####### Null Session Key
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v CachedLogonsCount /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v RestrictAnonymous /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v LMCompatibilityLevel /t REG_DWORD /d 3 /f
#base# rem ####### FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX Key
#base# rem ####### WOW6432Node Key
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX" /v iexplore.exe /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX" /v iexplore.exe /t REG_DWORD /d 1 /f
#base# rem ####### Lanman
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" /v RequireSecuritySignature /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v enablesecuritysignature /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v requiresecuritysignature /t REG_DWORD /d 1 /f

#base# rem ####### Disabling Admin Shares
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v AutoShareServer /t REG_DWORD /d 0 /f

#base# rem ####### Set DNS Cache TTL to 15 minutes
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v MaxCacheEntryTtlLimit /t REG_DWORD /d 900 /f

#base# rem ####### Disabling SSL/TLS 1.0/TLS 1.1
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server" /v Enabled /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server" /v Enabled /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server" /v Enabled /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server" /v Enabled /t REG_DWORD /d 0 /f

#base# rem ####### Disabling IPSourceRouting
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v DisableIPSourceRouting /t REG_DWORD /d 2 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" /v DisableIPSourceRouting /t REG_DWORD /d 2 /f

#base# rem ####### Disabling StrictNameChecking and LoopbackCheck Registry Settings
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v DisableStrictNameChecking /t REG_DWORD /d 1 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\LSA" /v DisableLoopbackCheck /t REG_DWORD /d 1 /f

#base# rem ####### Set DNS Cache TTL to 15 minutes
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v MaxCacheEntryTtlLimit /t REG_DWORD /d 900 /f

#base# rem ####### Enabled Last Accessed Date
#base# fsutil behavior set disablelastaccess 0

#base# rem ####### Disable LanMan/NTLMv1 Authentication method
#base# reg add "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Lsa" /v LMCompatibilityLevel /t REG_DWORD /d 3 /f

#base# rem ####### Fix to Spectre/Meltdown
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v FeatureSettingsOverride /t REG_DWORD /d 72 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v FeatureSettingsOverrideMask /t REG_DWORD /d 3 /f
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization" /v MinVmVersionForCpuBasedMitigations /t REG_SZ /d 1.0 /f

#base# rem Fix to Windows Registry Setting To Globally Prevent Socket Hijacking Missing
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Afd\Parameters" /v DisableAddressSharing /t REG_DWORD /d 1 /f

#base# rem ####### Setting Session Time for Idle Remote Desktop Connections
#base# reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v MaxIdleTime /t REG_DWORD /d 900000 /f

#base# rem ####### Enabling Remote Desktop Access with Network Level Authentication
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v UserAuthentication /t REG_DWORD /d 1 /f

#base# rem ####### Disabling Admin Shares
#base# reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v AutoShareServer /t REG_DWORD /d 0 /f

#base# rem ####### Microsoft Group Policy Remote Code Execution Vulnerability
#base# reg add "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" /v "\\*\NETLOGON" /t REG_SZ /d "RequireMutualAuthentication=1, RequireIntegrity=1" /f
#base# reg add "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" /v "\\*\SYSVOL" /t REG_SZ /d "RequireMutualAuthentication=1, RequireIntegrity=1" /f

#Windows Baseline fixes



#Opening Log Folder

$lastpatchcsv | Export-Csv $Logpath\$computername.Hotfix_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).csv -NoTypeInformation
$lastpatchcsv | Export-Csv $Logpath2\$computername.Hotfix_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).csv -NoTypeInformation
$lastpatchcsv | Export-Csv $Logpathaws\$computername.Hotfix_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).csv -NoTypeInformation
$lastpatchcsv | Export-Csv $Logpathaz\$computername.Hotfix_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).csv -NoTypeInformation

$Outputreport | out-file "$Logpath\$computername.RTP_Health_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).htm"
$Outputreport | out-file "$Logpath2\$computername.RTP_Health_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).htm"
$Outputreport | out-file "$Logpathaws\$computername.RTP_Health_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).htm"
$Outputreport | out-file "$Logpathaz\$computername.RTP_Health_Report-$(Get-Date -Format dd-MMM-yyyy-hhmm).htm"


#Write-Host "Process Complete Please Check Logs"
$filter="$computername.RTP*.htm"
$latest = Get-ChildItem -Path $Logpath -Filter $filter | Sort-Object LastAccessTime -Descending | Select-Object -First 1
$latestfile = $latest.name
#& 'C:\Windows\System32\notepad.exe' $Logpath\$latestfile
& start $Logpath\$latestfile
#write-host ""
#write-host ""
#write-host "$computername - RTP Review Report Successful" -ForegroundColor Green

#$Error >>$PSScriptRoot\Error.txt
#}
#If ((Get-ComputerInfo).CsManufacturer -eq "VMware, Inc.") {logoff}else{cls}
If ([System.Security.Principal.WindowsIdentity]::GetCurrent().Name -eq "HO\b025023265") {cls}else{cls}



    ### End Script

    $listBox1.Items.Add( "Pre Check Complete ---- Check Logs"  )
    }
    

    
    if ($checkBox1.Checked){
    $listBox1.Items.Add( ".")
    $listBox1.Items.Add( "Setting up Orion Requirements....")  

    Start-Sleep 2
    clear 
    Write-host "====================================================" -ForegroundColor Green
    Write-host "" -ForegroundColor Green
    Write-host "Setting UP Orion Requirements for $env:COMPUTERNAME....." -ForegroundColor Green
    Write-host "" -ForegroundColor Green
    Write-host "====================================================" -ForegroundColor Green

    ### Start Script
    
    #Set Firewall Rule for 49154 WMIPort
    netsh firewall add portopening TCP 49154 WMIFixedPort -ErrorAction SilentlyContinue -ErrorVariable ProcessError;
    If ($ProcessError) {
    ### If there is error
    Write-Host "FAILED: Firewall Rule set for 49154 WMIPort" -ForegroundColor Red
    Write-Output "FAILED: Firewall Rule set for 49154 WMIPort" | Out-File -FilePath "$LocalLogpath\FAILED_Orion_$env:COMPUTERNAME.txt"
    }
    ### If there is NO error
    Write-Host "COMPLETED: Firewall Rule set for 49154 WMIPort" -ForegroundColor Green
    Write-Output "COMPLETED: Firewall Rule set for 49154 WMIPort" | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt"


# Registry 49154 Endpoint Setting
### Command
Set-ItemProperty "Registry::HKEY_CLASSES_ROOT\AppID\{8BC3F05E-D86B-11D0-A075-00C04FB68820}"-name "EndPoints" -value "ncacn_ip_tcp,0,49154" -ErrorAction SilentlyContinue -ErrorVariable ProcessError;
If ($ProcessError) {
### If there is error
Write-Host "FAILED: Registry Classes Root Endpoints TCP 49154" -ForegroundColor Red
Write-Output "FAILED: Registry Classes Root Endpoints TCP 49154" | Out-File -FilePath "$LocalLogpath\FAILED_Orion_$env:COMPUTERNAME.txt" -Append
}
### If there is NO error
Write-Host "COMPLETED: Registry Classes Root Endpoints TCP 49154" -ForegroundColor Green
Write-Output "COMPLETED: Registry Classes Root Endpoints TCP 49154" | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt" -Append


### Command
Set-ItemProperty "Registry::HKEY_LOCAL_MACHINE\Software\Classes\AppID\{8BC3F05E-D86B-11D0-A075-00C04FB68820}"-name "EndPoints" -value "ncacn_ip_tcp,0,49154" -ErrorAction SilentlyContinue -ErrorVariable ProcessError;
If ($ProcessError) {
### If there is error
Write-Host "FAILED: Registry AppID Endpoints TCP 49154" -ForegroundColor Red
Write-Output "FAILED: Registry AppID Endpoints TCP 49154" | Out-File -FilePath "$LocalLogpath\FAILED_Orion_$env:COMPUTERNAME.txt" -Append
}
### If there is NO error
Write-Host "COMPLETED: Registry AppID Endpoints TCP 49154" -ForegroundColor Green
Write-Output "COMPLETED: Registry AppID Endpoints TCP 49154" | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt" -Append


##### Setting WinMGT Service Config to StandAlone #####
##### COMMAND
winmgmt -standalonehost -ErrorAction SilentlyContinue -ErrorVariable ProcessError;
If ($ProcessError) {
### If there is error
Write-Host "FAILED: Setting WinMGT Service Config to StandAlone" -ForegroundColor Red
Write-Output "FAILED: Setting WinMGT Service Config to StandAlone" | Out-File -FilePath "$LocalLogpath\FAILED_Orion_$env:COMPUTERNAME.txt" -Append
}
### If there is NO error
Write-Host "COMPLETED: Setting WinMGT Service Config to StandAlone" -ForegroundColor Green
Write-Output "COMPLETED: Setting WinMGT Service Config to StandAlone" | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt" -Append
##### TEMPLATE END #####


##### Registry - Setting EnableDCOM on Registry to YES #####
##### COMMAND
Set-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Ole" -Name "EnableDCOM" -Value ”Y” -ErrorAction SilentlyContinue -ErrorVariable ProcessError;
If ($ProcessError) {
### If there is error
Write-Host "FAILED: Registry - Setting EnableDCOM on Registry to YES" -ForegroundColor Red
Write-Output "FAILED: Registry - Setting EnableDCOM on Registry to YES" | Out-File -FilePath "$LocalLogpath\FAILED_Orion_$env:COMPUTERNAME.txt" -Append
}
### If there is NO error
Write-Host "COMPLETED: Registry - Setting EnableDCOM on Registry to YES" -ForegroundColor Green
Write-Output "COMPLETED: Registry - Setting EnableDCOM on Registry to YES" | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt" -Append
##### TEMPLATE END #####

Start-Sleep -Seconds 2

##### Users - Adding Poller Account #####
##### COMMAND
Add-LocalGroupMember -Group "Administrators" -Member "ho\p_solw_poller" -ErrorAction SilentlyContinue -ErrorVariable ProcessError;
If ($ProcessError) {
### If there is error
Write-Host "FAILED: Check if ho\p_solw_poller is already added to the local admin group" -ForegroundColor Red
Write-Output "FAILED: Check if ho\p_solw_poller is already added to the local admin group" | Out-File -FilePath "$LocalLogpath\FAILED_Orion_$env:COMPUTERNAME.txt" -Append
}
### If there is NO error
Write-Host "COMPLETED: Adding ho\p_solw_poller to local admin group" -ForegroundColor Green
Write-Output "COMPLETED: Adding ho\p_solw_poller to local admin group " | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt" -Append
##### TEMPLATE END #####


##### Registry - Additional DWORD LocalAccountTokenFilterPolicy #####
##### COMMAND
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System" -Name "LocalAccountTokenFilterPolicy" -Value 1 -PropertyType "DWord" -ErrorAction SilentlyContinue
Write-Host "COMPLETED: Registry - Additional DWORD LocalAccountTokenFilterPolicy" -ForegroundColor Green
Write-Output "COMPLETED: Registry - Additional DWORD LocalAccountTokenFilterPolicy" | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt" -Append
##### TEMPLATE END #####


##### Set Service Config for WinMGt to QuickConfig #####
##### COMMAND


$ServiceName = 'WinRM'
$arrService = Get-Service -Name $ServiceName

    if ($arrService.Status -eq 'Running')
    {
        Write-Host "COMPLETED: Service WinMGt to QuickConfig Completed" -ForegroundColor Green
        Write-Output "COMPLETED: Service WinMGt to QuickConfig Completed" | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt" -Append
    }
    else{
    #winrm quickconfig -quiet
    Start-Service $ServiceName
    write-host $arrService.status
    write-host 'Service starting'
    Start-Sleep -seconds 10
    $arrService.Refresh()
    }

#Restart WinManagement Service
Restart-Service -Name winmgmt -Force -ErrorAction SilentlyContinue -ErrorVariable ProcessError;
If ($ProcessError) {
Write-Output "FAILED: WinManagement Service Restart" | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt" -Append
####### Something went wrong
}

Start-Sleep -Seconds 10


$ServiceName = 'winmgmt'
$arrService = Get-Service -Name $ServiceName

    if ($arrService.Status -eq 'Running')
    {
        Write-Host "COMPLETED: Service WinManagement Restart Completed" -ForegroundColor Green
        Write-Output "COMPLETED: Service WinManagement Restart Completed" | Out-File -FilePath "$LocalLogpath\COMPLETED_Orion_$env:COMPUTERNAME.txt" -Append
    }
    else{
    #winrm quickconfig -quiet
    Start-Service $ServiceName
    write-host $arrService.status
    write-host 'Service starting'
    Start-Sleep -seconds 10
    $arrService.Refresh()
    }

    Write-host ""
    ### End Script

    #Write-host "COMPLETED: Adding ho\UP-BTPAM-ITIO-SRE-Windows to local admin group" -ForegroundColor Green
    #C:\Users\a025023265\Documents\MyScripts\Powershell\Baseline\Test\Check1.ps1


    $listBox1.Items.Add( "Setup Complete ---- Check Logs"  )
    }
    


    if ($checkBox2.Checked){
    $listBox1.Items.Add( "."  )
    $listBox1.Items.Add( "Setting up PAM Requirements") 
    Start-Sleep 3
    #Call Script
    #C:\Users\a025023265\Documents\MyScripts\Powershell\Baseline\Test\Check2.ps1

    #PAM Accounts and Groups:
    Write-host "====================================================" -ForegroundColor Green
    Write-host "" -ForegroundColor Green
    Write-host "Setting UP PAM for $env:COMPUTERNAME....." -ForegroundColor Green
    Write-host "" -ForegroundColor Green
    Write-host "====================================================" -ForegroundColor Green
    
#$pbrTest.Maximum = 100
#$pbrTest.Minimum = 0
#$i = 0

$dbservice = 'SQLSERVERAGENT'
$service = Get-Service -Name $dbservice -ErrorAction SilentlyContinue
if($service -eq $null)
{
   # Service does not exist
   #$dbstatus = "No"

      # Cleanup
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-BTPAM-SI-DBASVR-F" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SPB-Windows1-admins" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SPB-Windows2-admins" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SPB-Windows3-admins" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SPB-Windows4-admins" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-WINDOWS1_SVR-OS-F" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-WINDOWS2_SVR-OS-F" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-WINDOWS3_SVR-OS-F" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-WINDOWS4_SVR-OS-F" -ErrorAction SilentlyContinue               

      Write-host "COMPLETED: Cleanup Process to local admin group" -ForegroundColor Green
      Write-Output "COMPLETED: Cleanup Process to local admin group" | Out-File -FilePath "$LocalLogpath\COMPLETED_PAM_$env:COMPUTERNAME.txt"

      # Adding accounts
      Add-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SM-Windows-admin" -ErrorAction SilentlyContinue
      Write-host "COMPLETED: Adding ho\ITIO-SM-Windows-admin to local admin group" -ForegroundColor Green
      Write-Output "COMPLETED: Adding ho\ITIO-SM-Windows-admin to local admin group" | Out-File -FilePath "$LocalLogpath\COMPLETED_PAM_$env:COMPUTERNAME.txt" -Append

      Add-LocalGroupMember -Group "Administrators" -Member "ho\UP-BTPAM-ITIO-SRE-Windows" -ErrorAction SilentlyContinue
      Write-host "COMPLETED: Adding ho\UP-BTPAM-ITIO-SRE-Windows to local admin group" -ForegroundColor Green
      Write-Output "COMPLETED: Adding ho\UP-BTPAM-ITIO-SRE-Windows to local admin group" | Out-File -FilePath "$LocalLogpath\COMPLETED_PAM_$env:COMPUTERNAME.txt" -Append
      

} else {
    # Service does exist
   #$dbstatus2 = "Yes"

      # Cleanup
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-BTPAM-SI-DBASVR-F" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SPB-Windows1-admins" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SPB-Windows2-admins" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SPB-Windows3-admins" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SPB-Windows4-admins" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-WINDOWS1_SVR-OS-F" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-WINDOWS2_SVR-OS-F" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-WINDOWS3_SVR-OS-F" -ErrorAction SilentlyContinue
      Remove-LocalGroupMember -Group "Administrators" -Member "ho\UP-WINDOWS4_SVR-OS-F" -ErrorAction SilentlyContinue

      Write-host "COMPLETED: Cleanup Process to local admin group" -ForegroundColor Green
      Write-Output "COMPLETED: Cleanup Process to local admin group" | Out-File -FilePath "$LocalLogpath\COMPLETED_PAM_$env:COMPUTERNAME.txt"

      # Adding accounts

      Add-LocalGroupMember -Group "Administrators" -Member "ho\ITIO-SM-Windows-admin" -ErrorAction SilentlyContinue
      Write-host "COMPLETED: Adding ho\ITIO-SM-Windows-admin to local admin group" -ForegroundColor Green
      Write-Output "COMPLETED: Adding ho\ITIO-SM-Windows-admin to local admin group" | Out-File -FilePath "$LocalLogpath\COMPLETED_PAM_$env:COMPUTERNAME.txt" -Append

      Add-LocalGroupMember -Group "Administrators" -Member "ho\itio-sm-db-admin" -ErrorAction SilentlyContinue      
      Write-host "COMPLETED: Adding ho\itio-sm-db-admin to local admin group" -ForegroundColor Green
      Write-Output "COMPLETED: Adding ho\itio-sm-db-admin to local admin group" | Out-File -FilePath "$LocalLogpath\COMPLETED_PAM_$env:COMPUTERNAME.txt" -Append
      
      Add-LocalGroupMember -Group "Administrators" -Member "ho\ITO-WUDA-DBA-b Accounts" -ErrorAction SilentlyContinue      
      Write-host "COMPLETED: Adding ho\ITO-WUDA-DBA-b Accounts to local admin group" -ForegroundColor Green
      Write-Output "COMPLETED: Adding ho\ITO-WUDA-DBA-b Accounts to local admin group" | Out-File -FilePath "$LocalLogpath\COMPLETED_PAM_$env:COMPUTERNAME.txt" -Append
      
      Add-LocalGroupMember -Group "Administrators" -Member "ho\UP-BTPAM-ITIO-SRE-Windows" -ErrorAction SilentlyContinue      
      Write-host "COMPLETED: Adding ho\UP-BTPAM-ITIO-SRE-Windows to local admin group" -ForegroundColor Green
      Write-Output "COMPLETED: Adding ho\UP-BTPAM-ITIO-SRE-Windows to local admin group" | Out-File -FilePath "$LocalLogpath\COMPLETED_PAM_$env:COMPUTERNAME.txt" -Append
      
      Add-LocalGroupMember -Group "Administrators" -Member "ho\UP-BTPAM-SI-DBASVR-F" -ErrorAction SilentlyContinue
      Write-host "COMPLETED: Adding ho\UP-BTPAM-SI-DBASVR-F to local admin group" -ForegroundColor Green
      Write-Output "COMPLETED: Adding ho\UP-BTPAM-SI-DBASVR-F to local admin group" | Out-File -FilePath "$LocalLogpath\COMPLETED_PAM_$env:COMPUTERNAME.txt" -Append
      
}
Write-host ""
    #End Script
    $listBox1.Items.Add( "Setup Complete ---- Check Logs"  )
    }
    


    if ($checkBox3.Checked){
    
    $listBox1.Items.Add( "."  )
    $listBox1.Items.Add( "Setting up PSSession")
    Start-Sleep 3
    Write-host "====================================================" -ForegroundColor Green
    Write-host "" -ForegroundColor Green
    Write-host "Setting UP PSSEssion on $env:COMPUTERNAME....." -ForegroundColor Green
    Write-host "" -ForegroundColor Green
    Write-host "====================================================" -ForegroundColor Green
    
New-NetFirewallRule -DisplayName "WinRM Connection" -Direction Inbound -LocalPort 5985, 5986 -Protocol TCP -Action Allow
enable-psremoting -force
#winrm quickconfig -quiet
Restart-Service -Name winRM
Start-Sleep -s 10

If ((Get-Service winRM).Status -eq 'Running') {
Write-host "winRM service is RUNNING" -ForegroundColor Green
Write-Output "winRM service is RUNNING" | Out-File -FilePath "C:\sretools\BaselineLogs\COMPLETED_PSSESSION_$ENV:COMPUTERNAME.txt" -Encoding Ascii
} Else {
Write-host "winRM service is STOPPED" -ForegroundColor Red
Write-Output "winRM service is STOPPED" | Out-File -FilePath "C:\sretools\BaselineLogs\FAILED_PSSESSION_$ENV:COMPUTERNAME.txt" -Encoding Ascii
}

    $listBox1.Items.Add( "Setup Complete ---- Check Logs")
    }

    if ($checkBox4.Checked){
    Start-Sleep -seconds 3
    $listBox1.Items.Add( "."  )
    $listBox1.Items.Add( "Setting up Baseline Fixes")


    Write-host "====================================================" -ForegroundColor Green
    Write-host "" -ForegroundColor Green
    Write-host "Setting UP Baseline Fixed on $env:COMPUTERNAME....." -ForegroundColor Green
    Write-host "" -ForegroundColor Green
    Write-host "====================================================" -ForegroundColor Green


#Baseline Fixes:
#$pbrTest.Maximum = 100
#$pbrTest.Minimum = 0
#$i = 0


## If Server is VMWare
##### COMMAND
If ((Get-ComputerInfo).CsManufacturer -eq "VMware, Inc.") {
Write-Host "Mapping drive, please wait..." -ForegroundColor Yellow 

$Cred = Get-Credential -Message "Enter username/password :"
$USER = $Cred.UserName
$Passwd = $Cred.GetNetworkCredential().password

#$user5 = "ho\p_task_t4s"
#$Password = "sch3dmgR"

net use T: /delete
net use T: \\fs10.cfs.bdo.com.ph\PUBLIC4\ITSC-Standards\NextGenIT\RTP /user:$USER  $Passwd
Start-Sleep -seconds 3
Copy-Item -Path "T:\baseline\*" -Destination "C:\Program Files" -Recurse -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Force -Path "C:\sretools\Tools"
Copy-Item -Path "T:\Tools\*" -Destination "C:\sretools\Tools" -Recurse -ErrorAction SilentlyContinue
Write-Host "COMPLETED: Copying Windirstat and SysinternalsSuite Folders to $env:COMPUTERNAME" -ForegroundColor Green
Write-Output "COMPLETED: Copying Windirstat and SysinternalsSuite Folders to $env:COMPUTERNAME" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt"
}
######### TEMPLATE END #########


## If Server is AWS
##### COMMAND
If ((Get-ComputerInfo).CsManufacturer -eq "Amazon EC2") {
Copy-Item -Path "\\tsclient\C\temp\D3_RTP\Scripts\baseline\*" -Destination "C:\Program Files" -Recurse -ErrorAction SilentlyContinue
Write-Host "COMPLETED: Copying Windirstat and SysinternalsSuite Folders to $env:COMPUTERNAME" -ForegroundColor Green
Write-Output "COMPLETED: Copying Windirstat and SysinternalsSuite Folders to $env:COMPUTERNAME" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt"
}
######### TEMPLATE END #########


## If Server is AZURE
##### COMMAND
If ((Get-ComputerInfo).CsManufacturer -eq "Microsoft Corporation") {
Copy-Item -Path "\\SW40046004\rtp$\baseline\*" -Destination "C:\Program Files" -Recurse -ErrorAction SilentlyContinue
Write-Host "COMPLETED: Copying Windirstat and SysinternalsSuite Folders to $env:COMPUTERNAME" -ForegroundColor Green
Write-Output "COMPLETED: Copying Windirstat and SysinternalsSuite Folders to $env:COMPUTERNAME" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt"
}
######### TEMPLATE END #########

########################################################################

## Create folders

$dbservice = 'SQLSERVERAGENT'
$service = Get-Service -Name $dbservice -ErrorAction SilentlyContinue
if($service -eq $null)
{
   #DB Service does not exist
New-Item "F:\interfaces\inbox" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\interfaces\outbox" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\interfaces\reports" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\interfaces\archive" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\interfaces\extract" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\deployments\dsc" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\tools" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\Program Files" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "G:\log" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "H:\backup" -ItemType "directory" -Force -ErrorAction SilentlyContinue

Write-host "COMPLETED: Configuration of Folders on Drive F Interface | Inbox | Outbox | Reports | Archive | Extract | Deployments | Tools" -ForegroundColor Green
Write-Output "COMPLETED: Configuration of Folders on Drive F Interface | Inbox | Outbox | Reports | Archive | Extract | Deployments | Tools" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append
   
} else {
   #db Service does exist

New-Item "F:\interfaces" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\interfaces\inbox" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\interfaces\outbox" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\interfaces\reports" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\interfaces\archive" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\interfaces\extract" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\deployments" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\deployments\dsc" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\tools" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\Program Files" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "F:\MSSQL_MDF" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "G:\log" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "G:\log\MSSQL_LOG" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "H:\backup" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "H:\backup\database" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "H:\backup\translog" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "I:\MSSQL_TEMP" -ItemType "directory" -Force -ErrorAction SilentlyContinue
New-Item "J:\MSSQL_LDF" -ItemType "directory" -Force -ErrorAction SilentlyContinue


Write-host "COMPLETED: Configuration of Database Folders on Drive F,G,H,I,J" -ForegroundColor Green
Write-Output "COMPLETED: Configuration of Database Folders on Drive F,G,H,I,J" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append
      
}


Write-host "Disabling Unrequired Services" -ForegroundColor Green

####### Disabling Unrequired Services
Set-Service -Name "TrkWks" -StartupType "Disabled"
Get-Service -Name "TrkWks" | Stop-Service
Write-host "COMPLETED: Stopping and Disable of TrkWks" -ForegroundColor Green
Write-Output "COMPLETED: Stopping and Disable of TrkWks" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

Set-Service -Name "RasMan" -StartupType "Disabled"
Get-Service -Name "RasMan" | Stop-Service
Write-host "COMPLETED: Stopping and Disable of RasMan" -ForegroundColor Green
Write-Output "COMPLETED: Stopping and Disable of RasMan" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

Set-Service -Name "ShellHWDetection" -StartupType "Disabled"
Get-Service -Name "ShellHWDetection" | Stop-Service
Write-host "COMPLETED: Stopping and Disable of ShellHWDetection" -ForegroundColor Green
Write-Output "COMPLETED: Stopping and Disable of ShellHWDetection" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

Set-Service -Name "TapiSrv" -StartupType "Disabled"
Get-Service -Name "TapiSrv" | Stop-Service
Write-host "COMPLETED: Stopping and Disable of TapiSrv" -ForegroundColor Green
Write-Output "COMPLETED: Stopping and Disable of TapiSrv" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

Set-Service -Name "AudioEndpointBuilder" -StartupType "Disabled"
Get-Service -Name "AudioEndpointBuilder" | Stop-Service
Write-host "COMPLETED: Stopping and Disable of AudioEndpointBuilder" -ForegroundColor Green
Write-Output "COMPLETED: Stopping and Disable of AudioEndpointBuilder" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

Set-Service -Name "AudioSrv" -StartupType "Disabled"
Get-Service -Name "AudioSrv" | Stop-Service
Write-host "COMPLETED: Stopping and Disable of AudioSrv" -ForegroundColor Green
Write-Output "COMPLETED: Stopping and Disable of AudioSrv" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

Set-Service -Name "dot3svc" -StartupType "Disabled"
Get-Service -Name "dot3svc" | Stop-Service
Write-host "COMPLETED: Stopping and Disable of dot3svc" -ForegroundColor Green
Write-Output "COMPLETED: Stopping and Disable of dot3svc" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

Set-Service -Name "hidserv" -StartupType "Disabled"
Get-Service -Name "hidserv" | Stop-Service
Write-host "COMPLETED: Stopping and Disable of hidserv" -ForegroundColor Green
Write-Output "COMPLETED: Stopping and Disable of hidserv" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append



######### Registry Setup Triple DES #########
##### COMMAND
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Ciphers\Triple DES 168" /v Enabled /t REG_DWORD /d 0 /f
Write-host "COMPLETED: Registry Setup Triple DES" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup Triple DES" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Cache logon
####### Null Session Key
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" /v CachedLogonsCount /t REG_DWORD /d 0 /f
Write-host "COMPLETED: Registry: Setting Null Session Key" -ForegroundColor Green
Write-host "COMPLETED: Registry Setup CachedLogonsCount" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup CachedLogonsCount" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v RestrictAnonymous /t REG_DWORD /d 1 /f
Write-host "COMPLETED: Registry Setup RestrictAnonymous" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup RestrictAnonymous" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Lsa" /v LMCompatibilityLevel /t REG_DWORD /d 3 /f
Write-host "COMPLETED: Registry Setup LMCompatibilityLevel" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup LMCompatibilityLevel" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

####### FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX Key
####### WOW6432Node Key
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX" /v iexplore.exe /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\WOW6432Node\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_ENABLE_PRINT_INFO_DISCLOSURE_FIX" /v iexplore.exe /t REG_DWORD /d 1 /f
Write-host "COMPLETED: Registry Setup iexplore.exe" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup iexplore.exe" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Lanman
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanWorkstation\Parameters" /v RequireSecuritySignature /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v enablesecuritysignature /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v requiresecuritysignature /t REG_DWORD /d 1 /f
Write-host "COMPLETED: Registry Setup Lanman" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup Lanman" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Disabling Admin Shares
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v AutoShareServer /t REG_DWORD /d 0 /f
Write-host "COMPLETED: Registry Setup Disabling Admin Shares" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup Disabling Admin Shares" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Set DNS Cache TTL to 15 minutes
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Dnscache\Parameters" /v MaxCacheEntryTtlLimit /t REG_DWORD /d 900 /f
Write-host "COMPLETED: Registry Setup DNS Cache TTL to 15 minutes" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup DNS Cache TTL to 15 minutes" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Disabling SSL/TLS 1.0/TLS 1.1
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 2.0\Server" /v Enabled /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\SSL 3.0\Server" /v Enabled /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.0\Server" /v Enabled /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\TLS 1.1\Server" /v Enabled /t REG_DWORD /d 0 /f
Write-host "COMPLETED: Registry Setup Disabling SSL/TLS 1.0/TLS 1.1" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup Disabling SSL/TLS 1.0/TLS 1.1" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Disabling IPSourceRouting
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" /v DisableIPSourceRouting /t REG_DWORD /d 2 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Tcpip6\Parameters" /v DisableIPSourceRouting /t REG_DWORD /d 2 /f
Write-host "COMPLETED: Registry Setup Disabling IPSourceRouting" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup Disabling IPSourceRouting" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Disabling StrictNameChecking and LoopbackCheck Registry Settings
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" /v DisableStrictNameChecking /t REG_DWORD /d 1 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\LSA" /v DisableLoopbackCheck /t REG_DWORD /d 1 /f
Write-host "COMPLETED: Registry Setup Disabling StrictNameChecking and LoopbackCheck" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup Disabling StrictNameChecking and LoopbackCheck" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Disable LanMan/NTLMv1 Authentication method
reg add "HKEY_LOCAL_MACHINE\System\CurrentControlSet\Control\Lsa" /v LMCompatibilityLevel /t REG_DWORD /d 3 /f
Write-host "COMPLETED: Registry Setup Disable LanMan/NTLMv1 Authentication method" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup Disable LanMan/NTLMv1 Authentication method" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Fix to Spectre/Meltdown
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v FeatureSettingsOverride /t REG_DWORD /d 72 /f
#reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v FeatureSettingsOverride /t REG_DWORD /d 0 /f
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management" /v FeatureSettingsOverrideMask /t REG_DWORD /d 3 /f
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization" /v MinVmVersionForCpuBasedMitigations /t REG_SZ /d 1.0 /f
Write-host "COMPLETED: Registry Setup Fix to Spectre/Meltdown" -ForegroundColor Green
Write-Output "COMPLETED: Registry Setup Fix to Spectre/Meltdown" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


##### Fix to Windows Registry Setting To Globally Prevent Socket Hijacking Missing
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\Afd\Parameters" /v DisableAddressSharing /t REG_DWORD /d 1 /f
Write-host "COMPLETED: Registry Prevent Socket Hijacking Missing" -ForegroundColor Green
Write-Output "COMPLETED: Registry Prevent Socket Hijacking Missing" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Setting Session Time for Idle Remote Desktop Connections
reg add "HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services" /v MaxIdleTime /t REG_DWORD /d 900000 /f
Write-host "COMPLETED: Registry Session Time for Idle Remote Desktop Connections" -ForegroundColor Green
Write-Output "COMPLETED: Registry Session Time for Idle Remote Desktop Connections" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### Enabling Remote Desktop Access with Network Level Authentication
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server" /v fDenyTSConnections /t REG_DWORD /d 0 /f
Write-host "COMPLETED: Registry Enabling Remote Desktop Access with Network Level Authentication" -ForegroundColor Green
Write-Output "COMPLETED: Registry Enabling Remote Desktop Access with Network Level Authentication" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


## If Server is AWS
If ((Get-ComputerInfo).CsManufacturer -eq "Amazon EC2") {
#reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v UserAuthentication /t REG_DWORD /d 0 /f
}Else{
reg add "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" /v UserAuthentication /t REG_DWORD /d 1 /f
Write-host "COMPLETED: Registry Enabling Setting RDP-TCP Disabled" -ForegroundColor Green
Write-Output "COMPLETED: Registry Enabling Setting RDP-TCP Disabled" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append
}


####### Microsoft Group Policy Remote Code Execution Vulnerability
reg add "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" /v "\\*\NETLOGON" /t REG_SZ /d "RequireMutualAuthentication=1, RequireIntegrity=1" /f
reg add "HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Windows\NetworkProvider\HardenedPaths" /v "\\*\SYSVOL" /t REG_SZ /d "RequireMutualAuthentication=1, RequireIntegrity=1" /f
Write-host "COMPLETED: Registry Group Policy Remote Code Execution Vulnerability" -ForegroundColor Green
Write-Output "COMPLETED: Registry Group Policy Remote Code Execution Vulnerability" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### FSUTIL
fsutil behavior set disablelastaccess 0
Write-host "COMPLETED: FSUTIL Enabled Last Accessed Date" -ForegroundColor Green
Write-Output "COMPLETED: FSUTIL Enabled Last Accessed Date" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

####### ELK
C:\windows\system32\WindowsPowerShell\v1.0\powershell.exe -NoProfile -ExecutionPolicy Bypass -File "C:\sretools\Tools\ELK\winlogbeat-7.8.1-windows-x86_64\install-service-winlogbeat.ps1"
Get-Service -Name "winlogbeat" | Start-Service
Write-host "COMPLETED: ELK Installation and Service Start" -ForegroundColor Green
Write-Output "COMPLETED: ELK Installation and Service Start" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append

####### LAPS
msiexec.exe /i "C:\sretools\Tools\LAPS\Files\LAPS.x64.msi" /qn
Write-host "COMPLETED: LAPS Installation and Service Start" -ForegroundColor Green
Write-Output "COMPLETED: LAPS Installation and Service Start" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### SPLUNK
Get-Service -Name "SplunkForwarder" | Start-Service
Write-host "COMPLETED: Splunk Service ReStarted" -ForegroundColor Green
Write-Output "COMPLETED: Splunk Service ReStarted" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append


####### DISABLE NETBIOS (AWS AND VPC only)

If ((Get-ComputerInfo).CsManufacturer -eq "Microsoft Corporation") {

##Manual Disable for Azure Servers

}Else{

$i = 'HKLM:\SYSTEM\CurrentControlSet\Services\netbt\Parameters\interfaces'  
Get-ChildItem $i | ForEach-Object {  
    Set-ItemProperty -Path "$i\$($_.pschildname)" -name NetBiosOptions -value 2

Write-host "COMPLETED: NetBIOS on all NIC Adapters is Disabled" -ForegroundColor Green
Write-Output "COMPLETED: NetBIOS on all NIC Adapters is Disabled" | Out-File -FilePath "$LocalLogpath\COMPLETED_BASELINE_FIX_$env:COMPUTERNAME.txt" -Append
}

}


Write-host ""

    $listBox1.Items.Add( "Setup Complete ---- Check Logs")
    }

    
    if ( !$checkBox0.Checked -and !$checkBox1.Checked -and !$checkBox2.Checked -and !$checkBox3.Checked -and !$checkBox4.Checked ) {   $listBox1.Items.Add("No CheckBox selected....")} 

Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.MessageBox]::Show("Process Complete")

}


$handler_button2_Click= 
{
ii "C:\sretools\"
}

$OnLoadForm_StateCorrection=
{#Correct the initial state of the form to prevent the .Net maximized form issue
    $form1.WindowState = $InitialFormWindowState
}

#----------------------------------------------
#region Generated Form Code
$form1.Text = "Windows Baseline v2.0 - LocalHost"
$form1.Name = "form1"
$form1.DataBindings.DefaultDataSourceUpdateMode = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 450
$System_Drawing_Size.Height = 250
$form1.ClientSize = $System_Drawing_Size

$button2.TabIndex = 5
$button2.Name = "button2"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 120
$System_Drawing_Size.Height = 23
$button2.Size = $System_Drawing_Size
$button2.UseVisualStyleBackColor = $True
$button2.Text = "Check Logs"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 27
$System_Drawing_Point.Y = 195
$button2.Location = $System_Drawing_Point
$button2.DataBindings.DefaultDataSourceUpdateMode = 0
$button2.add_Click($handler_button2_Click)

$form1.Controls.Add($button2)

$button1.TabIndex = 4
$button1.Name = "button1"
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 120
$System_Drawing_Size.Height = 23
$button1.Size = $System_Drawing_Size
$button1.UseVisualStyleBackColor = $True
$button1.Text = "Execute"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 27
$System_Drawing_Point.Y = 165
$button1.Location = $System_Drawing_Point
$button1.DataBindings.DefaultDataSourceUpdateMode = 0
$button1.add_Click($handler_button1_Click)

$form1.Controls.Add($button1)

$listBox1.FormattingEnabled = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 225
$System_Drawing_Size.Height = 212
$listBox1.Size = $System_Drawing_Size
$listBox1.DataBindings.DefaultDataSourceUpdateMode = 0
$listBox1.Name = "listBox1"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 200
$System_Drawing_Point.Y = 13
$listBox1.Location = $System_Drawing_Point
$listBox1.TabIndex = 3

$form1.Controls.Add($listBox1)


$checkBox4.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 24
$checkBox4.Size = $System_Drawing_Size
$checkBox4.TabIndex = 3
$checkBox4.Text = "Setup Baseline Fix"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 27
$System_Drawing_Point.Y = 130
$checkBox4.Location = $System_Drawing_Point
$checkBox4.DataBindings.DefaultDataSourceUpdateMode = 0
$checkBox4.Name = "checkBox4"

$form1.Controls.Add($checkBox4)

$checkBox3.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 24
$checkBox3.Size = $System_Drawing_Size
$checkBox3.TabIndex = 2
$checkBox3.Text = "Setup PSSession Enable"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 27
$System_Drawing_Point.Y = 100
$checkBox3.Location = $System_Drawing_Point
$checkBox3.DataBindings.DefaultDataSourceUpdateMode = 0
$checkBox3.Name = "checkBox3"

$form1.Controls.Add($checkBox3)


$checkBox2.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 24
$checkBox2.Size = $System_Drawing_Size
$checkBox2.TabIndex = 1
$checkBox2.Text = "Setup PAM Requirements"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 27
$System_Drawing_Point.Y = 70
$checkBox2.Location = $System_Drawing_Point
$checkBox2.DataBindings.DefaultDataSourceUpdateMode = 0
$checkBox2.Name = "checkBox2"

$form1.Controls.Add($checkBox2)



$checkBox1.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 24
$checkBox1.Size = $System_Drawing_Size
$checkBox1.TabIndex = 0
$checkBox1.Text = "Setup Orion Requirements"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 27
$System_Drawing_Point.Y = 40
$checkBox1.Location = $System_Drawing_Point
$checkBox1.DataBindings.DefaultDataSourceUpdateMode = 0
$checkBox1.Name = "checkBox1"

$form1.Controls.Add($checkBox1)


$checkBox0.UseVisualStyleBackColor = $True
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 180
$System_Drawing_Size.Height = 25
$checkBox0.Size = $System_Drawing_Size
$checkBox0.TabIndex = 0
$checkBox0.Text = "Perform RTP Pre-Check"
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 27
$System_Drawing_Point.Y = 13
$checkBox0.Location = $System_Drawing_Point
$checkBox0.DataBindings.DefaultDataSourceUpdateMode = 0
$checkBox0.Name = "checkBox0"

$form1.Controls.Add($checkBox0)





#Save the initial state of the form
$InitialFormWindowState = $form1.WindowState
#Init the OnLoad event to correct the initial state of the form
$form1.add_Load($OnLoadForm_StateCorrection)
#Show the Form

$form1.ShowDialog()| Out-Null

} #End Function

#Call the Function
GenerateForm