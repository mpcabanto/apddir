############################################################################
#This should be the ip address of the targer host to be patch and mbss     #
#You may add multiple of unix environment for any multiple processes       #
# Only for Images Platform                                                 #
############################################################################
#Do not modify this part as this is the authentication method for any connectivity and process to sucessfully run the script.
# If you want to update the credentials. Please do read the IG or README File.

[win]
#VPC ip

#AZURE ip

#AWS IP



[win:vars]
ansible_connection=winrm
ansible_winrm_server_cert_validation=ignore
ansible_winrm_port=5985
ansible_winrm_transport=ntlm
ansible_user="{{windows_admin_username}}"
ansible_password="{{windows_admin_password}}"
