/bin/cat <<EOF > /etc/mod/probe.d/CIS.conf
install cramsfs /bin/true
install freevxfs /bin/true
EOF 
