###############################################################
# Variable and Parameters                                     #
# You may modify this part based on the requirements needed   #
# Created By: Michael Cabanto                                 #
###############################################################
dynamicDate=$(date +%m%Y)
reposip="repo01.csinfra.cs.bdo.com.ph"
reposport="8080"
reposdir="ubuntu"

/bin/cat  <<EOF > /etc/apt/sources.list
deb http://$reposip:$reposport/$reposdir/$dynamicDate bionic-security main
deb http://$reposip:$reposport/$reposdir/$dynamicDate bionic-current main
deb http://$reposip:$reposport/$reposdir/$dynamicDate bionic-updates main
EOF
