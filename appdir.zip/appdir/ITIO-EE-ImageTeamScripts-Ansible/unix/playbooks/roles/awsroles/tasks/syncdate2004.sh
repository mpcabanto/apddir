###############################################################
# Variable and Parameters                                     #
# You may modify this part based on the requirements needed   #
# Created By: Michael Cabanto                                 #
###############################################################
dynamicDate=$(date +%m%Y)
reposip="10.60.3.124"
reposport="8080"
reposdir="ubuntu"

/bin/cat  <<EOF > /etc/apt/sources.list
deb http://$reposip:$reposport/$reposdir/$dynamicDate focal-current main
deb http://$reposip:$reposport/$reposdir/$dynamicDate focal-updates main
deb http://$reposip:$reposport/$reposdir/$dynamicDate focal-security main
EOF

