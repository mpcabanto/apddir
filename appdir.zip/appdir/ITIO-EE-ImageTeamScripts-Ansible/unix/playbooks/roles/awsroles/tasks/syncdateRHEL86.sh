###############################################################
# Variable and Parameters                                     #
# You may modify this part based on the requirements needed   #
# Created By: Michael Cabanto                                 #
###############################################################
dynamicDate=$(date +%m%Y)
reposip="10.60.4.100"
reposdir="repo"
reposOS="rhel"
reposversion="8"
reposverid="6"

/bin/cat  <<EOF > /etc/yum.repos.d/rhel-8-server-internal.repo
[rhel-8-appstream-rhui-rpms]
name=Red Hat Enterprise Linux 8 for x86_64 - AppStream from RHUI (RPMs)
baseurl = http://10.60.4.100/repo/$reposOS/$reposversion/$reposverid/$dynamicDate/rhel-8-appstream-rhui-rpms
metadata_expire = 86400
enabled=1
gpgcheck=0
sslverify=0


[ansible-2-for-rhel-8-rhui-rpms]
name=Red Hat Ansible Engine 2 for RHEL 8 (RPMs) from RHUI
baseurl = http://10.60.4.100/repo/$reposOS/$reposversion/$reposverid/$dynamicDate/ansible-2-for-rhel-8-rhui-rpms
metadata_expire = 86400
enabled=1
gpgcheck=0
sslverify=0


[rhel-8-baseos-rhui-rpms]
name=Red Hat Enterprise Linux 8 for x86_64 - BaseOS from RHUI (RPMs)
baseurl = http://10.60.4.100/repo/$reposOS/$reposversion/$reposverid/$dynamicDate/rhel-8-baseos-rhui-rpms
metadata_expire = 86400
enabled=1
gpgcheck=0
sslverify=0

[rhui-client-config-server-8]
name=RHUI Client Configuration Server 8
baseurl = http://10.60.4.100/repo/$reposOS/$reposversion/$reposverid/$dynamicDate/rhui-client-config-server-8
metadata_expire = 86400
enabled=1
gpgcheck=0
sslverify=0
EOF
