

################################
# 8.1 Ensure to backup rsyslog #
################################
cp -p /etc/rsyslog.conf /etc/rsyslog.conf.backup.`date +"%d%m%Y"`

#########################################
# 8.2 Add authpriv.* to the end of line #
#########################################
/bin/cat <<EOF >> /etc/rsyslog.conf
authpriv.*         /var/log/secure
EOF

#########################################################
# 8.3 Ensure to change the ownership permission to root #
#########################################################
/bin/chown root:root /etc/rsyslog.conf

#####################################################
# 8.4 Ensure that the mod permission is set to 0600 #
#####################################################
/bin/chmod 0600 /etc/rsyslog.conf

