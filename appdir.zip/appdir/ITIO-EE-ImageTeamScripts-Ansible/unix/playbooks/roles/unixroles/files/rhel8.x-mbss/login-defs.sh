
echo "Set login.defs..."
for i in \
	"PASS_MAX_DAYS 90" \
	"PASS_MIN_DAYS 7" \
	"PASS_WARN_AGE 7" \
	; do
  [[ `egrep "^${i}" /etc/login.defs` ]] && continue
    option=${i%% *}
      grep -q ${option} /etc/login.defs && sed -i "s/.*${option}.*/$i/g" /etc/login.defs || echo "$i" >> /etc/login.defs
done
