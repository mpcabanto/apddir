################################
# RHEL8.x Policy Configureation#
# Created by: MPCabanto        #
# ITIO-EE-Platform-Image       #
# For internal used only       #
################################

echo "Configuring SSH..."
cp -p /etc/ssh/sshd_config /etc/ssh/sshd_config.backup.`date +"%d%m%Y"`
for i in \
	"#Harden by Mike Cabanto" \
	"Protocol 2" \
	"X11Forwarding no" \
	"IgnoreRhosts yes" \
	"HostbasedAuthentication no" \
	"PermitRootLogin no" \
	"PermitEmptyPasswords no" \
	"Banner /etc/issue" \
	"AllowGroups ec2-user infra-admin HO\itio-es-platforms AD-BDO\itio-es-platforms AD-BDO\p_ansible_deploy_g AD-BDO\p_vascan_group AD-BDO\p_snow_sshdiscovery_g p_pamuser_group" \
	"ciphers aes128-ctr,aes192-ctr,aes256-ctr
kexalgorithms curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group-exchange-sha256,diffie-hellman-group16-sha512,diffie-hellman-group18-sha512,diffie-hellman-group-exchange-sha1,diffie-hellman-group14-sha256,diffie-hellman-group14-sha1" \
	"KbdInteractiveAuthentication yes" \
	"GSSAPIAuthentication yes" 
	; do
  [[ `egrep -q "^${i}" /etc/ssh/sshd_config` ]] && continue
    option=${i%% *}
      grep -q ${option} /etc/ssh/sshd_config && sed -i "s/.*${option}.*/$i/g" /etc/ssh/sshd_config || echo "$i" >> /etc/ssh/sshd_config
done
sleep 0;

service sshd reload
echo "Secure SSH configuration has been completed"

