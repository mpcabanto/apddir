wget -o /tmp/http://repo03.csinfra.cs.bdo.com.ph/repos/Softwares/Software_Download/Disk1/CrowdStrike/CrowdStrike/falcon-sensor-6.22.0-11906.el7.x86_64.rpm

######################
# Installation of CS #
######################
yum install libnl-genl-3-200
rpm -ivh /tmp/falcon-sensor-5.31.0-9606.el7.x86_64.rpm 



#################################
# CS File directory check of CS #
#################################
sudo /opt/CrowdStrike/falconctl –s --cid=C541502D26AD42F891C3316EE2544A08-F5
opt/CrowdStrike/falconctl -s --aph=www.external.proxy.cs.bdo.com.ph --app="50443"
/opt/CrowdStrike/falconctl -s --apd=FALSE

#######################
# Service start of CS #
#######################
service falcon-sensor start


#############
# Checklist #
#############
ps -e | grep falcon-sensor

#################################
# Verify the sensor file on disk#
#################################
sudo ls -al /opt/CrowdStrike /opt/CrowdStrike/falcon-sensor

####################################################
# Verify that the sensor is Connected to the Cloud #
####################################################
sudo netstat -tapn | grep falcon


################################
# Remove the installer to /tmp #
################################
rm -rf /tmp/falcon-sensor-5.31.0-9606.el7.x86_64.rpm
