
######################################
# 3.1 Configure Ubuntu Repo Template #
######################################
/bin/cat <<EOF > /etc/apt/source.list
deb http://repo03.csinfra.cs.bdo.com.ph:8080 bionic-current main
deb http://repo03.csinfra.cs.bdo.com.ph:8080 bionic-stable main
deb http://repo03.csinfra.cs.bdo.com.ph:8080 bionic-security main
deb http://repo03.csinfra.cs.bdo.com.ph:8080 bionic-updates main
EOF


