
###################################################
# Ensure that Permission Log File is properly set #
# 9.0 to 9.14					  #
# Set Permission Log File			  #
###################################################
chmod go-rwx boot* cron* maillog* messages* pgsql* messages* secure* spoolers*
chmod o-rwx boot.log* cron* dmesg ksyms* httpd/* maillog* messages* news/* pgsql rpmpkgs* samba/* sa/* scrollkeeper.log secure* spooler* squid/* vbox/* wtmp
chmod o-rx boot.log* cron* maillog* messages* pgsql secure* spooler* squid/* sa/*
chmod g-w boot.log* cron* dmesg httpd/* ksyms* maillog* messages* pgsql rpmpkgs* samba/* sa/* scrollkeeper.log secure* spooler*
chmod g-rx boot.log* cron* maillog* messages* pgsql secure* spooler*
chmod o-w gdm/ httpd/ news/ samba/ squid/ sa/ vbox/
chmod o-rx httpd/ samba/ squid/ sa/
chmod g-w gdm/ httpd/ news/ samba/ squid/ sa/ vbox/
chmod g-rx httpd/ samba/ sa/
chmod u-x kernel syslog loginlog
chgrp utmp wtmp
[ -e news ] && chown -R news:news news
[ -e pgsql ] && chown postgres:postgres pgsql
chown -r squid:squid squid

