
###############################
# 1.4 Ensure to coy /etc/issu #
###############################
/bin/cp -p /etc/issue /etc/issue.backup.`date +"%d%m%Y"`

###############################################
# 1.5 Ensure to plae BDO policy in /etc/issue #
###############################################
/bin/cat <<EOF > /etc/issue 
"***************************************************************************
                            NOTICE TO USERS


This computer system is the property of Banco De Oro.  It is for
authorized use only.

Any or all uses of this system and all files on this system may be
monitored, recorded, audited, inspected, and disclosed to authorized
Banco De Oro, government, and law enforcement personnel, as well as
authorized officials of government agencies.

By using this system, the user consents to such monitoring, recording,
auditing, inspection, and disclosure at the discretion of such
personnel or officials. Unauthorized or improper use of this system
may result in civil and criminal penalties and administrative or
disciplinary action, as appropriate. By continuing to use this system
you indicate your awareness of and consent to these terms and
conditions of use. LOG OFF IMMEDIATELY if you do not agree to the
conditions stated in this warning.

***************************************************************************"
EOF

