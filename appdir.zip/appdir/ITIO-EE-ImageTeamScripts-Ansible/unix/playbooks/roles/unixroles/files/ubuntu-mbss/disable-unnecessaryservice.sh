#
#
#!/bin/sh
######################################
# 4.1 - Disable unnecessary services #
######################################
services=(telnet
ftp/tftp
rlogin/rsh/rcp
imap
pop
ident
smb
nfs
nis
rpc
portmap
cups
postgresql/mysql
dns
snmp
squid
nfs-common
rsh
rexec
finger)

for i in $services;
	dpkg -l | grep $services;
if $services == true then
	apt purge -y $services
fi

#####################################
# 4.2 - Ensure to backup initd.conf #
#####################################
/bin/cp -p /etc/inetd.conf /etc/inetd.conf.`date +"%d%m%Y"`

##################################
# 4.3 Ensure to configure init.d #
##################################

