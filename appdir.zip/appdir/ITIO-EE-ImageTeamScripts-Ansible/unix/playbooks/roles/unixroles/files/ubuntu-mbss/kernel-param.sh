
################################################
# Ensure that kernle parameter is properly set #
################################################

#########################################
# 6.1 - Ensure to backup sysctl config  #
#########################################
cp -p /etc/sysctl.conf /etc/sysctl.conf.backup.`date +"%d%m%Y"`

#############################################
# 6.2 - Ensure to set the kernel parameters #
#############################################
/bin/cat <<EOF > /etc/sysctl.conf
net.ipv4.tcp_max_syn_backlog = 4096
net.ipv4.tcp_syncookies = 1
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.secure_redirects = 0
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.default.secure_redirects = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.ip_forward = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.tcp_max_syn_backlog = 10500
net.core.somaxconn = 10240
net.core.netdev_max_backlog = 10500
net.ipv4.ip_local_port_range = 1024 65535
# Uncomment for kernel version less than or equal to 4.12
#net.ipv4.tcp_tw_recycle = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_mem = 4096 16777216 16777216
net.ipv4.tcp_wmem = 4096 16777216 16777216
net.ipv4.tcp_rmem = 4096 16777216 16777216
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.core.rmem_default = 16777216
net.core.wmem_default = 16777216
net.ipv4.tcp_fin_timeout = 30
net.core.optmem_max = 25165824
vm.swappiness = 10
# Uncomment for Database Servers
#kernel.sem = 250 64000 250 256
EOF

############################################################
# 6.3 - Ensure to restart system control after change made #
############################################################
sysctl -p

##########################################################
# 6.4 - Ensure that sysctl.conf owner is root permission #
##########################################################
/bin/chown root:root /etc/sysctl.conf

##############################################################
# 6.5 - Ensure that sysctl.conf mod permission is set to 600 #
##############################################################
/bin/chmod 600 /etc/sysctl.conf

########################################
# 6.6 - Ensure to add security limists #
########################################
/bin/cat <<EOF > /etc/security/limits.conf

# Kernel Parameter Tuning
*  soft nproc  120832
*  hard nproc  120832
*  soft nofile 120832
EOF

