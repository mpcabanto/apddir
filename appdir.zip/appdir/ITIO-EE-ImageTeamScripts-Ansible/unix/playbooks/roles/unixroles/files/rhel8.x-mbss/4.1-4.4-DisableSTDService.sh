
##############################################################
# 4.1 Ensure to disable all unnecessary services and daemons #
##############################################################

#!/bin/bash

for serviceName in `cat StandardService.txt`
do
        sout=`cat /etc/services | grep  $serviceName`
	#echo $sout 
	if  [[ $sout > 1 ]]; then
  		echo "service is running"
	else
  		echo "service not running"
	fi
done

###############################################################################
# 4.1 Check /etc/xinet.d/ folder for services configured and remove necessary #
###############################################################################
xinetd=ls -lrth /etc/xinet.d/
echo $xinetd

##############################
# 4.2 Service restart xinetd #
##############################

#Check if xinetd install
xinetinstall="yum -y install xinetd"
if [ $xinetd  -eq "not found" ]; then
	echo "No xinetd service installed"
else
	echo $xinetdinstall
fi

