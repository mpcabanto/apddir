

#######################################
# 6.1 Ensure to backup inittab config #
#######################################
/bin/cp -p /etc/inittab /etc/inittab.backup.`date +"%d%m%Y"`

##############################################
# 6.2 SED id from 3 to id 5 to /etc/initttab #
##############################################
sed -e 's/id:5:initdefault:/id:3:initdefault:/' > /etc/inittab

###################################################
# 6.3 Ensure that permission owner is set to root #
###################################################
/bin/chown root:root /etc/inittab

#################################################
# 6.4 Ensure that permission mod is set to 0600 #
#################################################
/bin/chmod 0600 /etc/inittab




