################################
# Ubuntu Policy Configureation #
# Created by: MPCabanto        #
# ITIO-EE-Platform-Image       #
# For internal used only       #
################################
#!/bin/sh
#
#
#########################
# Enable System Account #
#########################
#
#########################
# 2.1 - Install sysstat #
#########################
apt-get -y install sysstat

#############################
# 2.2 Backup sysconfig file #
#############################
cp -p /etc/sysconfig/sysstat /etc/sysconfig/sysstat.backup.`date +"%d%m%Y"`

#############################
# 2.3 Start service sysstat #
#############################
service sysstat start

#################################################
# 2.4 Ensure the "change ENABLE is set to true" #
#################################################
egrep -q "^(\s*)ENABLED\s+\S+(\s*#.*)?\s*$" /etc/default/sysstat && sed -ri "s/^(\s*)ENABLED\s+\S+(\s*#.*)?\s*$/\1ENABLED="false"\2/" /etc/default/sysstat || echo "ENABLED="true"" >> /etc/default/sysstat

###############################
# 2.5 Restart sysstat service #
###############################
service sysstat restart

############################################
# 2.6 - Ensure that utilization is created #
############################################
/bin/cat <<EOF > /usr/local/tools/utilization.sh
#!/bin/sh

dte=`date +%b%Y`
dd=`date +%d`

yesterday() {
dd=`expr "$dd" - 1`
case "$dd" in
0)      mm=`expr "$mm" - 1`
        case "$mm" in
        0)      mm=12
                yr=`expr "$yr" - 1`
                if [ $yr -lt 10 ]; then
                        yr=`echo "0"$yr`
                fi
                ;;
        esac
        dd=`cal $mm $yr | grep . | fmt -1 | tail -2 | head -1`

        if [ $mm -lt 10 ]; then
                mm=`echo "0"$mm`
        fi
esac
if [ $dd -lt 10 ]; then
        dd=`echo "0"$dd`
fi
}

yesterday
#dd=09
calc()
{
   awk 'BEGIN {print '"$dd,$*"'; exit}'
}

#Memory
#mem=`grep Average /var/log/sysstat/sar$dd | head -n43 | tail -n1 | awk '{printf $3}'`
mem=`sar -f /var/log/sysstat/sa$dd -r | tail -n1 | awk '{print $3}'`
#cache=`grep Average /var/log/sysstat/sar$dd | head -n43 | tail -n1 | awk '{printf $6}'`
cache=`sar -f /var/log/sysstat/sa$dd -r | tail -n1 | awk '{print $6}'`
memused=`expr $mem - $cache`
echo $dd $memused >> /var/log/sysstat/memory/mem$dte

#CPU
#idle=`grep Average /var/log/sysstat/sar$dd | head -n3 | tail -n1 | awk '{printf $8}'`
idle=`sar -f /var/log/sysstat/sa$dd | tail -n1 | awk '{print $8}'`
calc "100.00 - $idle" >> /var/log/sysstat/cpu/cpu$dte

#HDD
date +%b%d%Y >> /var/log/sysstat/hdd/hdd$dte
df -h| awk '{print $3"\t"$5"\t"$6}' |tail -n5 >> /var/log/sysstat/hdd/hdd$dte
EOF

##############################################
# 2.7 - Ensure that permission is set to 755 #
##############################################
/bin/chmod 755 /usr/local/tools/utilization.sh

