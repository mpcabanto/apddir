

###########################
# 7.1 Backup sysctl.confg #
###########################
/bin/cp -p /etc/sysctl.conf /etc/sysctl.conf.backup.`date +"%d%m%Y"`

#######################################################################
# 7.2 Ensure to set the kernel parameter based on the policy approved #
#######################################################################
/bin/cat <<EOF > /etc/sysctl.conf
net.ipv4.tcp_max_syn_backlog = 4096
net.ipv4.tcp_syncookies = 1
net.ipv4.conf.all.rp_filter = 1
net.ipv4.conf.all.accept_source_route = 0
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.secure_redirects = 0
net.ipv4.conf.default.rp_filter = 1
net.ipv4.conf.default.accept_source_route = 0
net.ipv4.conf.default.accept_redirects = 0
net.ipv4.conf.default.secure_redirects = 0
net.ipv4.icmp_echo_ignore_broadcasts = 1
net.ipv4.ip_forward = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv4.tcp_max_syn_backlog = 10500
net.core.somaxconn = 10240
net.core.netdev_max_backlog = 10500
net.ipv4.ip_local_port_range = 1024 65535
# Uncomment for kernel version less than or equal to 4.12
#net.ipv4.tcp_tw_recycle = 1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.tcp_mem = 4096 16777216 16777216
net.ipv4.tcp_wmem = 4096 16777216 16777216
net.ipv4.tcp_rmem = 4096 16777216 16777216
net.core.rmem_max = 16777216
net.core.wmem_max = 16777216
net.core.rmem_default = 16777216
net.core.wmem_default = 16777216
net.ipv4.tcp_fin_timeout = 30
net.core.optmem_max = 25165824
vm.swappiness = 10
# Uncomment for Database Servers
#kernel.sem = 250 64000 250 256
EOF

#########################################################
# 7.4 Restart system control to take effect the changes #
#########################################################
sysctl -p

##########################################
# 7.5 Ensure to change ownership to root #
##########################################
/bin/chown root:root /etc/sysctl.conf

################################################
# 7.6 Ensure that mod permission is set to 600 #
################################################
/bin/chmod 600 /etc/sysctl.conf

######################################################
# 7.7 Ensure to add proc profile to kernel parameter #
######################################################
cp -p /etc/security/limist.conf /etc/security/limist.conf.backup.`date +"%d%m%Y"`


/bin/cat <<EOF >> /etc/security/limist.conf
# Kernel Parameter Tuning
*  soft nproc  120832
*  hard nproc  120832
*  soft nofile 120832
EOF

