################################
# RHEL8.x Policy Configureation#
# Created by: MPCabanto        #
# ITIO-EE-Platform-Image       #
# For internal used only       #
################################

echo "Configuring SSH..."
cp -p /etc/ssh/sshd_config /etc/ssh/sshd_config.backup.`date +"%d%m%Y"`

sed -i 's/X11Forwarding yes/X11Forwarding no/g' /etc/ssh/sshd_config
sed -i 's/#IgnoreRhosts yes/IgnoreRhosts yes/g' /etc/ssh/sshd_config
sed -i 's/#HostbasedAuthentication no/HostbasedAuthentication no/g' /etc/ssh/sshd_config
sed -i 's/PermitRootLogin yes/PermitRootLogin no/g' /etc/ssh/sshd_config
sed -i 's/#PermitEmptyPasswords no/PermitEmptyPasswords no/g' /etc/ssh/sshd_config
 

ssh='/etc/ssh/sshd_config'
grep -q "^Banner[[:space:]]2" "${ssh}"
if [[ "$?" -eq 0 ]]; then
echo "Banner configured in ${ssh}"
else
echo "Banner /etc/issue" >> "${ssh}"
fi

grep -q "^Protocol[[:space:]]2" "${ssh}"
if [[ "$?" -eq 0 ]]; then
echo "Protocol configured in ${ssh}"
else
echo "Protocol 2" >> "${ssh}"
fi

grep -q "^AllowGroups[[:space:]]2" "${ssh}"
if [[ "$?" -eq 0 ]]; then
echo "Allow Groups configured in ${ssh}"
else
echo "AllowGroups ec2-user infra-admin HO\itio-es-platforms AD-BDO\itio-es-platforms AD-BDO\p_ansible_deploy_g AD-BDO\p_vascan_group AD-BDO\p_snow_sshdiscovery_g p_pamuser_group" >> "${ssh}"
fi

grep -q "^ciphers[[:space:]]2" "${ssh}"
if [[ "$?" -eq 0 ]]; then
echo "cipher configred in ${ssh}"
else
echo "ciphers aes128-ctr,aes192-ctr,aes256-ctr
kexalgorithms curve25519-sha256,curve25519-sha256@libssh.org,ecdh-sha2-nistp256,ecdh-sha2-nistp384,ecdh-sha2-nistp521,diffie-hellman-group-exchange-sha256,diffie-hellman-group16-sha512,diffie-hellman-group18-sha512,diffie-hellman-group-exchange-sha1,diffie-hellman-group14-sha256,diffie-hellman-group14-sha1" >> "${ssh}"
fi

grep -q "^KbdInteractiveAuthentication[[:space:]]2" "${ssh}"
if [[ "$?" -eq 0 ]]; then
echo "KbdInteractiveAuthentication configured in ${ssh}"
else
echo "KbdInteractiveAuthentication yes" >> "${ssh}"
fi

grep -q "^GSSAPIAuthentication[[:space:]]2" "${ssh}"
if [[ "$?" -eq 0 ]]; then
echo "GSSAPIAuthentication configured in ${ssh}"
else
echo "GSSAPIAuthentication yes" >> "${ssh}"
fi



service sshd reload
echo "Secure SSH configuration has been completed"


