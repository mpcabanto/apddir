###############################################################
# Variable and Parameters                                     #
# You may modify this part based on the requirements needed   #
# Created By: Michael Cabanto                                 #
###############################################################
dynamicDate=$(date +%b-%Y)
reposip="www.rhel.bdo.com.ph"
reposdir="repos"
reposOS="rhel"
reposversion="7"
reposverid="9"

/bin/cat  <<EOF > /etc/yum.repos.d/local.repo
[rhel-7-server-internal-repo]
metadata_expire = 86400
baseurl = https://$reposip/$reposdir/$reposOS/$reposversion/$reposverid/$dynamicDate
ui_repoid_vars = releasever basearch
sslverify = 0
name = Red Hat Enterprise Linux 7.9 Server - Internal Repository
#sslclientkey = /etc/pki/entitlement/7982189681505492723-key.pem
gpgkey = file:///etc/pki/rpm-gpg/RPM-GPG-KEY-redhat-release
enabled = 1
gpgcheck = 0
proxy=_none_

EOF
