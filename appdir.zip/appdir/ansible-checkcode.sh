##############################
# Ansible COde validation    #
##############################
#!/bin/sh

cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/unix
/usr/bin/ansible-playbook playbooks/pre-check.yml --check
/usr/bin/ansible-playbook playbooks/site.yml --check
/usr/bin/ansible-playbook playbooks/pre-checkreport.yml --check

