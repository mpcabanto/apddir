cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/unix
/usr/bin/ansible-playbook  playbooks/provision-ec2.yml -vvv
