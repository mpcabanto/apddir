##############################
# Ansible COde validation    #
##############################
#!/bin/sh

cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/winpatch
/usr/bin/ansible-playbook playbooks/site.yml --check
