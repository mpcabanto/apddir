##############################
# Ansible COde validation    #
##############################
#!/bin/sh

cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/unix
/usr/bin/ansible-playbook playbooks/azmain.yml --check
