####################################################
# Ansible Code Validation for AWS Windows Patching #
####################################################
cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/winpatch/

/usr/bin/ansible-playbook playbooks/site.yml --check

