##############################
# Ansible COde validation    #
##############################
#!/bin/sh

cd /appdir/ITIO-EE-ImageTeamScripts-Ansible/winpatch
/usr/bin/ansible-playbook playbooks/winmbss.yml --check
