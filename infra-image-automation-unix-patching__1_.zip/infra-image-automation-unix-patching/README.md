# AUTOMATED PATCHING AND BASELINE CONFIGURATION
**`ITIO-EE-Platforms Automation Initiative for Infra-Image (Automated Patching and Baseline Configuration).`**

- Allow engineer to add single or multiple IPs in the inventory file.
- Allow engineer to modify or enhance Ansible Playbook.
- Allow engineer to push / pull updated source code.
**- Pre Check Configuration and Generate Pre Check Configuration**
  - Allow the automation to check/validate the system for any update/configiration needed to update.
- **Generate Report from Pre-Check Config**
  - This is to allow the engineer's to view the pre/post configuration of the server. It is enable also to use for audit purposes
- **Apply OS Patch Update**
  - This functionlity is to apply the latest patch update based on the parameters "OS_FAMILY". Engineer's allow to modify   this parameters based on thier needs.
- **Vulnerability Patching Scan and Report**
  - Automation is also allow the engineer's to eliminated the manual process to scan the OS server after patch. It will redirect/hook to the scanning tool that will automatically create an instance to scan the OS based on the details provided in the scripts. Also, it will generate the report and send it back to the respective team to review the result. 
  1. VA (Vulnerability Assessment)
  2. PC (Policy Compliance known as baseline security policy)
- **Apply Baseline OS Security Policy**
  - This automation allow the engineer's to modify and apply the approved policy.
- **Convert Image to Template**
  - This is to automate the convertion of image to template and generating report once done

</details>
<img src="infra-initiative.jpg" width="80%">

**`Instruction Guide on how to use GIT Command to update the host file.`**

1. GIT CLONE THE BRANCH THAT YOU ARE WORKING ON
  - git clone -b <branch_name> url
  This will ask you to login using your own account and access token

2. Once your successfully login and clone the project. you will see it by following the command below
   - ls
   - cd <project_name>

3. from the project name, just edit the hosts file and add the IP Address you want to update.
   - vi hosts
   (Note: Just comment the ip if you wish to do not use it. )
   For the single IP Address, just only add the target IP

4. Once you are done on the editing of the host file. You need to run below command to automatically run the pipeline withour accessing the gitlab portal
   - git add .
   - git commit -m "<This is the updated host file>. If your have RT just add the RT Numnber"
   - git push.

5. Once all is good and no error, go to gitlab portal and see the progress of the pipeline
   - MENU > CI/CD > Pipelines

**`INSTRUCTION GUIDELINES`**
1. Ansible File Location
  - /appdir/ITIO-EE-ImageScripts-Ansible/
2. Check the ansible if installed in the server
  - rpm -qa | grep ansible or ansible --version
3. To write/create new file in the playbook, you much have basic knowledge on the unix and scripting side. But for this guidelines, see example command.
  - cd /app/ITIO-EE-ImageScripts-Ansible/
  - mkdir -p ansibletutorials
  - cd ansibletutorials
  - mkdir -p playbooks/roles
  - cd playbooks/roles
  - run ansible-galaxy init ansitutorials (This will create role name "ansitutorials"
  - inside of the roles you will see the standard role structures
    - templates, vars, tests, meta, handlers, defaults, files and tasks (It depends on you how to use this structure. But for this tutorials only tasks we will use)
  - cd create roles (ansitutorials)
  - cd tasks
    - inside tasks you will see main.yml file. by default its was created but no code yet. 
  - To create yml file
    - vi ansitutorials.yml
    - then place the code you want.
      - ex. 
        - name: Ansible tutorials
	  hosts: localhost
	  connection: local
	  tasks:
	  - name: Tutorials
	    shell: "uname -a"
   - Now to test your script
     - ansible-playbook ansitutorials.yml (This is run the script and see how the script works fine or encounter any issue)

