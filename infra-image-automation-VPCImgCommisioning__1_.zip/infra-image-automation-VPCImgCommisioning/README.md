# Infra-Image Automation (IaC) Infrastructure as Code)
**`ITIO-EE-PLATFORMS-INFRA-IMAGE AUTOMATION INITIATIVES`**

- This branch is use for automated cloning of images from VPC environment.
- This is also use for automated creation of Virtual Machine from vSphere / VMWare.
- To use this pipeline, you need to have knowledge in powershell, ansible and other scripting language to aviod issues. 

- The following files needed to update are as follows:
  - Variable files located in roles/iacvpc/vars/all.yml
    - all required fileds must be indicated in this file. 
      - Note: ansible / unix is a case sensitive. 
             You need to be careful to modify the files and others that you need to modify or else project is not work properly.


<img src="iacvpc.jpg" width="80%">


**`Infrastructure as Code process`**

- Ingress Data from CSV File

**Cloning the template**
1. Clone template from content library
2. Create clone VM
3. Execute Patch
4. Scan using Qualys for security packages
5. Generate Report (Security Vulnerability Patch)
6. Scan for baseline policy
7. Generate Report (Policy Compliance) using open source tool
8. Clone the VM to template
9. Release new template

**Deploy New Virtual Machine**
1. Deploy new VM
2. Execute Patch
3. Scan using Qualys for security packages
4. Generate Report (Security Vulnerability Patch)
5. Scan for baseline policy
6. Generate Report (Policy Compliance) using open source tool
7. Clone the VM to template
8. Release new template
